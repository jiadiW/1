""" expression parser
Xs_Norm()
Xs_HHI()
Clip()
Ts_KalmanFilter()
Uncor()
Delay()
Mix_Min_Booksize()
"""

import os, time, math
import pandas as pd
import numpy as np
import scipy
import collections
import logging
from pdb import set_trace
# import osqp

def group2list(group):
    if len(group) == 0:
        return []
    if isinstance(group, str):
        groups = [x for x in group.split("|") if len(x) > 0]
        return groups
    else:
        return group

def check_group(group):
    glist = ["compo", "country", "sector", "group", "industry", "sid"]
    for g in group2list(group):
        if not g in glist:
            logging.info(f"error group: {g}")

def hhi(x):
    if not any(x):
        return 0
    return sum(map(lambda  y: y**2, x)  ) / sum(x)**2

def kalmanfilter(x, result="vector"):
    from filterpy.kalman import KalmanFilter
    y = x
    kf = KalmanFilter(dim_x = 1, dim_z = 1)
    kf.x = np.array( [x.iloc[0]] )
    kf.F = np.array( [[1.0]] )
    kf.H = np.array( [[1.0]] )
    kf.P = 10000.0
    kf.R = 5.0
    kf.Q = 10000.0
    for i in range(0, len(y)):
        kf.update(x.iloc[i])
        kf.predict()
        y.iloc[i] = kf.x[0]
    if result == "vector":
        return y
    elif len(y) > 0:
        return y[-1]
    else:
        return np.nan

def bf(x, result = "vector"):
    from filterpy.kalman import KalmanFilter

    y = x
    kf = KalmanFilter(dim_x = 1, dim_z = 1)
    kf.x = np.array([x.iloc[0]])
    kf.F = np.array([[1.0]])
    kf.H = np.array([[1.0]])
    kf.P = 10000.0
    kf.R = 5.0
    kf.Q = 10000.0

    kf2 = KalmanFilter(dim_x = 1, dim_z = 1)
    kf2.alpha = 1.02
    kf2.x = np.array([x.iloc[0]])
    kf2.F = np.array([[1.0]])
    kf2.H = np.array([[1.0]])
    kf2.P = 10000.0
    kf2.R = 5.0
    kf2.Q = 10000.0
    for i in range(0, len(x)):
        kf.update(x.iloc[i])
        kf.predict()
        kf2.update(x.iloc[i])
        kf2.predict()
        std = np.sqrt(kf2.R)
        if abs(kf2.y[0]) < 2 * std:
            y.iloc[i] = kf2.x[0]
        else:
            y.iloc[i] = kf.x[0]
    if result == "vector":
        return y
    elif len(y) > 0:
        return y[-1]
    else:
        return np.nan


class SlidingWindowLinearRegressor(object):
    def __init__(self, dt, time_constant):
        self.dots = np.zeros(5)
        self.intercept = 0
        self.forgetting_factor = np.exp(-dt / time_constant)
        self.slope = 0
    
    def update(self, x: float, y: float):
        self.dots *= self.forgetting_factor
        self.dots += np.array([1, x, y, x*x, x*y])
        dot_11, dot_1x, dot_1y, dot_xx, dot_xy = self.dots
        det = dot_11 * dot_xx - dot_1x ** 2
        if det > 1e-10:
            self.intercept = (dot_xx * dot_1y - dot_xy * dot_1x) / det
            self.slope = (dot_xy * dot_11 - dot_1x * dot_1y) / det
    
    def predict(self, x: float) -> float:
        return self.intercept + self.slope * x

def lr(x, result = "vector"):
    # Recursive_least_square_filter
    y = x
    lr = SlidingWindowLinearRegressor(dt = 1, time_constant = 21)
    for i in range(1, len(x)):
        lr.update(x.iloc[i-1], x.iloc[i] )
        y.iloc[i] = lr.predict(x.iloc[i-1])
    if result == "vector":
        return y
    elif len(y) > 0:
        return y[-1]
    else:
        return np.nan

def ts_svd(colmat, length, n_mask = 10):
    cols = colmat.columns
    l = len(cols)
    # print("l is ", l)
    # print("w is ", len(colmat))
    for i in range(l-1, -1, -1):
        if i < length / 2:
            colmat[cols[i]] = np.nan
        else:
            try:
                x = colmat[cols[i - length + 1: i + 1]].replace([np.nan, np.inf], 0, inplace=False)
                U, S, Vh = np.linalg.svd(x, full_matrices=False)
                S[:n_mask] = 0
                x_re = np.dot(U * S, Vh)
                colmat[cols[i]] = x_re[:, -1]
            except:
                colmat[cols[i]] = np.nan

def ph(x, ndays_ignore=1, result="vector"):
    from prophet import Prophet
    import logging
    logger = logging.getLogger("cmdstanpy")
    logger.addHandler(logging.NullHandler())
    logger.propagate = False
    logger.setLevel(logging.CRITICAL)
    df = x.to_frame().reset_index()
    df.columns = ["dt", "y"]
    x = df.y
    y = x.copy()
    # for name in [col for col in df.columns if "lag" in col]:
    #     ph.add_regressor(name)
    for i in range(len(x) - 2, len(x)):
        try:
            ph = Prophet(yearly_seasonality=True, weekly_seasonality=True, daily_seasonality=False, seasonality_mode = "additive")
            ph.fit(df.iloc[:(i+1) - ndays_ignore])
            y.iloc[i] = ph.predict(df.iloc[:(i+1)].yhat.values[-1] )
        except:
            y.iloc[i] = np.nan
    df["date"] = df.ds
    y.index = df.date
    if result == "vector":
        return y
    elif len(y) > 0:
        return y[-1]
    else:
        return np.nan

def ts_uncor(colmat, length, fit_intercept = False):
    from sklearn import linear_model
    clf = linear_model.LinearRegression(fit_intercept = fit_intercept)
    cols = colmat.columns
    l = len(cols)
    for i in range(l - 1, -1, -1):
        if i < length / 2:
            colmat[cols[i]] = np.nan
        else:
            Y = colmat[cols[i]].replace([np.nan, np.inf, -np.inf], 0)
            X = colmat[cols[i - length : i -1]].replace([np.nan, np.inf, -np.inf], 0)
            try:
                clf.fit(X, Y)
                colmat[cols[i]] -= clf.predict(X)
            except:
                colmat[cols[i]] = np.nan
def ts_uncor_slope(colmat, length, fit_intercept = False):
    from sklearn import linear_model
    clf = linear_model.LinearRegression(fit_intercept = fit_intercept)
    cols = colmat.columns
    n = len(colmat)
    l = len(cols)
    for i in range(l - 1, -1, -1):
        if i < length / 2:
            colmat[cols[i]] = np.nan
        else:
            # Y = colmat[cols[i]].replace([np.nan, np.inf, -np.inf], 0)
            # X = colmat[cols[i - length : i -1]].replace([np.nan, np.inf, -np.inf], 0)

            for j in range(n):
                Y = colmat[cols[i-length+1:i]].iloc[j, :].replace([np.nan, np.inf, -np.inf], 0)
                X = colmat[cols[i - length : i -1]].iloc[j, :].replace([np.nan, np.inf, -np.inf], 0)
                try:
                    clf.fit(X, Y)
                    colmat[cols[i]] = clf.coef_[0]
                except:
                    colmat[cols[i]] = np.nan
    

def uncor(colmat1, colmat2, length, fit_intercept = False):
    from sklearn import linear_model
    clf = linear_model.LinearRegression(fit_intercept = fit_intercept)
    cols = colmat1.columns
    l = len(cols)
    for i in range(l - 1, -1, -1):
        if i < length / 2:
            colmat1[cols[i]] = np.nan
        else:
            Y = colmat1[cols[i]].replace([np.nan, np.inf, -np.inf], 0)
            xcols = [xc for xc in cols[i - length + 1 : i + 1] if xc in colmat2.columns]
            X = colmat2[xcols].replace([np.nan, np.inf, -np.inf], 0)
            try:
                clf.fit(X, Y)
                colmat1[cols[i]] -= clf.predict(X)
            except:
                colmat1[cols[i]] = np.nan
def uncor_slope(colmat1, colmat2, length, fit_intercept = False):
    from sklearn import linear_model
    clf = linear_model.LinearRegression(fit_intercept = fit_intercept)
    cols = colmat1.columns
    l = len(cols)
    for i in range(l - 1, -1, -1):
        if i < length / 2:
            colmat1[cols[i]] = np.nan
        else:
            Y = colmat1[cols[i]].replace([np.nan, np.inf, -np.inf], 0)
            xcols = [xc for xc in cols[i - length + 1 : i + 1] if xc in colmat2.columns]
            X = colmat2[xcols].replace([np.nan, np.inf, -np.inf], 0)
            try:
                clf.fit(X, Y)
                colmat1[cols[i]] = clf.coef_[0]
            except:
                colmat1[cols[i]] = np.nan

def col2mat(mat, col, return_idxmat = False, unique_id = "sid", date_id = "date"):
    df = mat[[date_id, unique_id, col]].replace([np.inf, -np.inf], np.nan)
    colmat = df.pivot_table(
        columns=date_id, index = unique_id, values = col, dropna=False
    )
    if return_idxmat:
        df["index1"] = df.index
        idxmat = df.pivot_table(
            columns = date_id, index = unique_id, values = "index1", dropna=False
        )
        return col2mat, idxmat
    return colmat

def mat2col(mat, colmat, unique_id = "sid", date_id = "date"):
    matsub = mat[[date_id, unique_id]]
    colmat[unique_id] = colmat.index
    matsub2 = pd.melt(colmat, id_vars = unique_id)
    matsub = (
        matsub.reset_index()
        .merge(matsub2, on = [date_id, unique_id], how = "left")
        .set_index("index")
    )
    return matsub["value"]

def compute_mix_min_booksize_osqp(
    alphas_in,
    cols = [],
    display_detail = False,
    out_weights = True,
    out_mix = True,
    lower_bound = None,
    upper_bound = None,
    max_iter = 1000,
    adj_bound_according_to_coverage = False,
    weight = None,
    verbose = False,
):
    import scipy.sparse as sparse
    import osqp
    if len(cols) != 0:
        alphas = alphas_in[cols]
        if weight:
            for col in cols:
                alphas[col] *= alphas_in[weight]
                if alphas[col].std() > 0:
                    alphas[col] /= alphas[col].std()
    else:
        return None
    alphas = alphas.astype(float)
    l = len(alphas)
    n = len(alphas.columns)
    m = n + 1
    if verbose:
        print("ticker number: %d, alpha number: %d, constraint number: %d" % (l, n, m))
    p = sparse.csc_matrix(alphas.T @ alphas)
    q = np.array([0] * n)
    ones = [1] * n
    A = np.diag(ones)
    A = np.vstack([A, ones])
    A = sparse.csc_matrix(A)
    l = np.array([1/n/10] * n + [n])
    if lower_bound is not None:
        if lower_bound > 0 and lower_bound < 1:
            l = np.array([lower_bound] * n + [n])
        else:
            pass
    u = np.array([min(n ** 0.5, 0.99 * n)] * n + [n])
    if upper_bound is not None:
        if upper_bound > 1 and upper_bound < n:
            u = np.array([upper_bound] * n + [n])
        else:
            pass
    if adj_bound_according_to_coverage:
        averagesum = alphas.abs().sum().sum() / n
        for i in range(n):
            isum = alphas.iloc[:, i].abs().sum()
            adj = isum / averagesum
            l[i] *= adj
            u[i] *= adj
    prob = osqp.OSQP()
    # prob.update_settings(verbose=verbose)
    prob.setup(p, q, A, l, u, alpha = 1.0, max_iter = max_iter)
    res = prob.solve()
    weights = res.x
    alphas = alphas_in[cols]
    combo = alphas @ weights
    combo = round(combo, 6)
    if verbose:
        print(f"lb: {l}")
        print(f"ub: {u}")
        print(f"weights: {weights}")
    if out_weights and out_combo:
        return weights, combo
    if out_mix:
        return combo
    if out_weights:
        return weights
    return None

def Xs_Norm(mat, col, option = "abssum1"):
    """ Xs Normalization
    """
    cols = ["date"]
    df = mat[cols + [col]].replace([-np.inf, np.inf], np.nan)
    df = pd.merge(
        df,
        df.groupby("date")[col]
        .mean()
        .reset_index()
        .rename(columns = {col: f"{col}_mean"}),
        on = cols,
        how = "left"
    )
    df[col] = df[col] - df[f"{col}_mean"]
    df = df.replace([-np.inf, np.inf, np.nan], 0)
    df = df.set_axis(mat.index, copy = False)
    if option == "abssum1":
        df[f"{col}_abs"] = df[col].abs()
        df = pd.merge(
            df,
            df.groupby("date")[f"{col}_abs"]
            .sum()
            .reset_index()
            .rename(columns = {f"{col}_abs": f"{col}_abssum"}),
            on = cols,
            how = "left"
        )
        df[col] = df[col] / df[f"{col}_abssum"]
    df = df.replace([-np.inf, np.inf, np.nan], 0)
    df = df.set_axis(mat.index, copy = False)
    return df[col]

def Xs_Group_Mean(mat, col, group = "compo"):
    """ Xs group mean
    """
    cols = ["date"] + group2list(group)
    df = mat[cols + [col]].replace([-np.inf, np.inf], np.nan)
    df = pd.merge(
        df,
        df.groupby(cols, group_keys = False)[col]
        .mean()
        .reset_index()
        .rename(columns = {col: f"{col}_mean"}),
        on = cols,
        how = "left"
    )
    # df[col] = df[col] - df[f"{col}_mean"]
    # df = df.replace([-np.inf, np.inf, np.nan], 0)
    df = df.set_axis(mat.index, copy = False)
    return df[f"{col}_mean"]  

def Xs_Group_Neu(mat, col, group = "compo"):
    """ Xs group neutralization
    """
    df = mat[["date"]+group2list(group)+[col]].replace([np.inf, -np.inf], np.nan)
    df[f"{col}_mean"] = Xs_Group_Mean(df, col, group = group)
    df[f"{col}_neu"] = df[col] - df[f"{col}_mean"]
    return df[col] - df[f"{col}_mean"]


def Xs_HHI(mat, col, group = "sid"):
    """ Xs HHI
    Paramsters
    ----------
    mat: pandas.DataFrame with columns date,col,group
    col: str of the column in mat
    group: str, column name, default compo
    Returns
    -------
    v: pandas.Series, with col values
    """
    cols = ["date"] + group2list(group)
    df = mat[cols + [col]].replace([np.inf, -np.inf], np.nan)
    v = df.groupby(cols, group_keys = False)[col].transform(lambda x: hhi(x))
    return v

def Clip(mat, col, lower_bound = None, upper_bound = None, ):
    """ Clip
    Parameters
    ----------
    mat: pandas.DataFrame, with columns date,col,group
    col: str, name of the column in mat to be used in input
    upper_bound: float, default None
    lower_bound: float, default None
    Returns
    -------
    v: pandas.Series, with col values
    """
    r = mat[col].clip(lower=lower_bound, upper = upper_bound)
    mat[col] = r
    return mat[col]


def Lag(mat, col, ndays, unique_id = "sid"):
    """ Lag
    """
    mat = mat.sort_values(by = "date")
    df = mat[["date", unique_id, col]].replace([np.inf, -np.inf], np.nan)
    df[f"{col}_value"] = df.groupby(unique_id, group_keys=False)[col].shift(ndays)
    return df[f"{col}_value"]

def Delta(mat, col, ndays, unique_id = "sid"):
    """ Delta
    """
    df = mat[["date", unique_id, col]].replace([-np.inf, np.inf], np.nan)
    df[f"{col}_lag"] = Lag(mat, col, ndays, unique_id)
    return df[col] - df[f"{col}_lag"]

def Ts_Mean(mat, col, length, unique_id = "sid"):
    """ Ts_Mean
    """
    df = mat[["date", unique_id, col]].replace([-np.inf, np.inf], np.nan)
    df[f"{col}_value"] = (
        df.groupby([unique_id], group_keys = False)[col]
        .rolling(window = length, min_periods = math.ceil(length / 2))
        .mean()
        .reset_index(0, drop=True)
    )
    return df[f"{col}_value"]

def Ts_Med(mat, col, length, unique_id = "sid"):
    """ Ts_Mean
    """
    df = mat[["date", unique_id, col]].replace([-np.inf, np.inf], np.nan)
    df[f"{col}_value"] = (
        df.groupby([unique_id], group_keys = False)[col]
        .rolling(window = length, min_periods = math.ceil(length / 2))
        .median()
        .reset_index(0, drop=True)
    )
    return df[f"{col}_value"]

def Ts_Std(mat, col, length, unique_id = "sid"):
    """ Ts_Mean
    """
    df = mat[["date", unique_id, col]].replace([-np.inf, np.inf], np.nan)
    df[f"{col}_value"] = (
        df.groupby([unique_id], group_keys = False)[col]
        .rolling(window = length, min_periods = math.ceil(length / 2))
        .std()
        .reset_index(0, drop=True)
    )
    return df[f"{col}_value"]

def Ts_Mean_Linear(mat, col, length,  nanto0=False, unique_id = "sid"):
    """ Ts Mean Linear
    """
    min_length = math.ceil(length / 2)
    df = mat[["date", unique_id, col]].replace([-np.inf, np.inf], np.nan)
    df[f"{col}_value"] = df.groupby([unique_id], group_keys=False)[col].transform(
        lambda x: ts_mean_linear_series(x, length, min_length)
    )
    return df[f"{col}_value"]

def Ts_Mean_Exp(mat, col, exp, unique_id = "sid", date_id = "date"):
    """ Ts_Mean_Exp
    """
    df = mat[[date_id, unique_id, col]].replace([-np.inf, np.inf], np.nan)
    df[f"{col}_value"] = df.groupby([unique_id], group_keys = False)[col].transform(
        lambda x: ts_mean_exp_series(x, exp)
    )
    return df[f"{col}_value"]

def Ts_Mean_Exp_Diff(mat, col, exp1, exp2, unique_id = "sid", date_id = "date"):
    df = mat[[date_id, unique_id, col]].replace([-np.inf, np.inf], np.nan)
    df1 = Ts_Mean_Exp(mat, col, exp1, unique_id = unique_id, date_id = date_id) # short
    df2 = Ts_Mean_Exp(mat, col, exp2, unique_id = unique_id, date_id = date_id) # long
    df[f"{col}_value"] = df1 - df2
    return df[f"{col}_value"]

def isgood(x):
    if x is None:
        return False
    if np.isnan(x) or np.isinf(x):
        return False
    return True

def ts_mean_linear(x, length, min_length, nanto0=False):
    out = []
    equal_sum = 0
    equal_weight = 0
    linear_sum = 0
    linear_weight = 0
    for i in range(0, len(x)):
        if nanto0 and not isgood(x[i]):
            x[i] = 0
        linear_sum -= equal_sum
        linear_weight -= equal_weight
        if isgood(x[i]):
            equal_sum += x[i]
            equal_weight += 1
            linear_sum += x[i] * length 
            linear_weight += length
        if i >= length:
            if isgood(x[i - length]):
                equal_weight -= 1
                equal_sum -= x[i - length]
        if i + 1 >= min_length and linear_weight > 0:
            out.append( linear_sum / linear_weight )
        else:
            out.append( np.nan )
    return out

def ts_mean_linear_series(x, length, min_length, nanto0=False):
    out = ts_mean_linear(list(x), length, min_length, nanto0 = nanto0)
    y = pd.Series(data = out, index = x.index)
    return y

def ts_mean_exp_series(x, exp):
    nums = list(x)
    out = []
    adddirectly = True
    for num in nums:
        if adddirectly:
            out.append(num)
        else:
            out.append( out[-1] * (1 - exp) + num * exp )
        adddirectly = not isgood(num)
    y = pd.Series(data = out, index = x.index)
    return y

def Ts_BayesianFilter(mat, col, code, unique_id = "sid"):
    code2model = [bf, lr]
    model = code2model[code]

def Ts_KalmanFilter(mat, col, unique_id = "sid"):
    """ KalmanFilter
    """
    mat = mat.sort_values(by = "date")
    df = mat[["date", unique_id, col]].replace([np.inf, -np.inf], np.nan)
    df[f"{col}_value"] = df.groupby(unique_id, group_keys=False)[col].transform(lambda x: kalmanfilter(x))
    return df[f"{col}_value"]

def Ts_Svd(mat, col_in, length, n_mask = 10, unique_id = "sid", date_id = "date"):
    colmat = col2mat(mat, col_in, unique_id = unique_id, date_id = date_id)
    ts_svd(colmat, length = length, n_mask = n_mask)
    x = mat2col(mat, colmat, unique_id = unique_id, date_id = date_id)
    return x

def Ts_Prophet(mat, col_in, ndays_ignore, unique_id = "sid"):
    df = mat[["date", unique_id, col_in]].replace([-np.inf, np.inf], np.nan)
    df = df.set_index("date")
    df[col_in + "_value"] = df.groupby([unique_id], group_keys = False)[col_in].transform(lambda x: ph(x, ndays_ignore=ndays_ignore))
    df.index = mat.index
    df = df.set_axis(mat.index, copy=False, axis = 0)
    return df[col_in + "_value"]

def Ts_Uncor(mat, col, length, unique_id = "sid"):
    """ get resid of col from reg using xprev[1:length;] col
    """
    mat = mat.sort_values(by = "date")
    colmat = col2mat(mat, col, unique_id = unique_id)
    ts_uncor(colmat, length = length)
    v = mat2col(mat, colmat, unique_id = unique_id)
    return v
def Ts_Uncor_Slope(mat, col, length, unique_id = "sid"):
    """ get resid of col from reg using xprev[1:length;] col
    """
    mat = mat.sort_values(by = "date")
    colmat = col2mat(mat, col, unique_id = unique_id)
    ts_uncor_slope(colmat, length = length)
    v = mat2col(mat, colmat, unique_id = unique_id)
    return v

def Uncor(mat, col1, col2, length, unique_id = "sid"):
    """ Uncor
    get resid of col1 from reg using xprev[0:length;] col2
    """
    mat = mat.sort_values(by = "date")
    colmat1 = col2mat(mat, col1, unique_id = unique_id)
    colmat2 = col2mat(mat, col2, unique_id = unique_id)
    uncor(colmat1, colmat2, length = length)
    v = mat2col(mat, colmat1, unique_id=unique_id)
    return v


def Uncor_Slope(mat, col1, col2, length, unique_id = "sid"):
    """ Uncor
    get resid of col1 from reg using xprev[0:length;] col2
    """
    mat = mat.sort_values(by = "date")
    colmat1 = col2mat(mat, col1, unique_id = unique_id)
    colmat2 = col2mat(mat, col2, unique_id = unique_id)
    uncor_slope(colmat1, colmat2, length = length)
    v = mat2col(mat, colmat1, unique_id=unique_id)
    return v

def Mix_Min_Booksize(mat, cols, lower_bound = None, upper_bound = None):
    """ Minimize booksize
    Mix alphas by day
    cols can be a list or a str seperated by '|'
    """
    cols = group2list(cols)
    df = mat[["date"] + cols].replace([np.inf, -np.inf], 0)
    name = "|".join(cols)
    name += "_mix"
    r = (
        df.groupby(["date"], group_keys=False)
        .apply(
            lambda x: compute_mix_min_booksize_osqp(
                x,
                cols,
                display_detail = False,
                out_weights = False,
                out_mix=True,
                lower_bound = lower_bound,
                upper_bound = upper_bound,
            )
        )
        .reset_index(0, drop=True)
    )
    df[name] = r
    return df[name]

def clean(x):
    return x.replace(" ", "")
def any_of_in(l, x):
    for l0 in l:
        if l0 in x:
            return True
    return False
def find_pos(c, x):
    if len(c) != 1:
        logging.error(f"error input {c}")
    out = []
    i = 0
    for x0 in x:
        if x0 == c:
            out.append(i)
        i += 1
    return out
def find_brackets(x):
    bl = []
    br = []
    q = collections.deque()
    for i in range(0, len(x)):
        c = x[i]
        if c == "(":
            bl.append(i)
            br.append(None)
            q.append(i)
        if c == ")":
            if not q:
                return None, None
            else:
                br[bl.index(q[-1])] = i
                q.pop()
    if len(br) > 0:
        if None in br:
            return None, None
    return bl, br
def judge_kind(x):
    x = clean(x)
    if any_of_in(" ", x):
        logging.error(f"{x} still have space inside")
        return "error"
    if x.replace(".", "").replace("-", "").isdigit():
        return "number"
    if any_of_in("(),+-*/%=?:;^", x):
        return "expression"
    if any_of_in("|", x):
        return "group"
    if x.replace("_", "").isalnum():
        return "variable"
    return "unidentified"
def simplify_brackets_once(x):
    x = clean(x)
    bl, br = find_brackets(x)
    if len(bl) > 0:
        if bl[0] == 0 and br[0] == len(x) - 1:
            x = x[1: len(x) - 1]
    return x
def simplify_brackets(x):
    x1 = simplify_brackets_once(x)
    while x1 != x:
        x = x1
        x1 = simplify_brackets_once(x)
    return x
def split_with_brackets(x, sep):
    parts = x.split(sep)
    out = []
    for p in parts:
        if len(out) == 0:
            out.append(p)
        else:
            bl, br = find_brackets(out[-1])
            if bl is not None:
                out.append(p)
            else:
                out[-1] += sep + p
    return out
def split_expression_once(x, print_details=False):
    if print_details:
        logging.info(f"checking {x}")
    x = clean(x)
    kind = judge_kind(x)
    if kind in ["number", "group", "variable"]:
        return {kind: x}
    elif kind != "expression":
        logging.info(f"{x} is not an expression, please check")
        return {"error": x}
    if x[0] == "-":
        x = "0" + x
    bl, br = find_brackets(x)
    if print_details:
        logging.info(f"find brackets {bl} {br}")
    if bl is None:
        return {"error": x}
    operators = "+-*/^"
    for f in operators:
        parts = split_with_brackets(x, f)
        if len(parts) > 1:
            return {"function": f, "elements": parts}
    
    if len(br) == 0:
        logging.info(f"error: {x} cannot be identified")
        return {"error": x}
    else:
        if bl[0] == 0 and br[0] == len(x) - 1:
            return split_expression_once(simplify_brackets(x))
        if br[0] < len(x) - 1:
            logging.info(f"error: {x} cannot be identified")
            return {"error": x}
        if bl[0] > 0:
            part = x[0: bl[0]]
            remaining = x[bl[0]: len(x)]
            if judge_kind(part) == "expression":
                logging.info(f"error: {x} cannot be identified")
                return {"error": x}
            else:
                parts = split_with_brackets(simplify_brackets(remaining), ",")
                parts = [simplify_brackets(x) for x in parts]
                return {"function": part, "elements": parts}

def split_expressions(x, layer = 0):
    result = split_expression_once(x)
    pre = "-" * layer
    if "elements" in result:
        logging.info(f"{pre}split {x}, layer {layer}")
        logging.info(f"{pre} {result}")
        for element in result["elements"]:
            split_expressions(element, layer=layer+1)
    else:
        logging.info(f"{pre} {result}")
def get_sequenced_key(keys_existing, keys_new):
    for key in keys_new:
        if key not in keys_existing:
            keys_existing.append(key)
    return keys_existing
def parse_expression_tree(x, tree={}, layer=0, output_details=False):
    if x in tree:
        return
    pre = "-" * layer
    result = split_expression_once(x)
    tree[x] = result
    if "elements" in result:
        if output_details:
            logging.info(f"{pre}split {x}, layer {layer}")
            logging.info(f"{pre} {result}")
        for element in result["elements"]:
            parse_expression_tree(
                element, tree, layer=layer+1, output_details=output_details
            )
    else:
        if output_details:
            logging.info(f"{pre} {result}")
    
    if layer == 0 and output_details:
        logging.info("===" * 10)
        logging.info(f"input: {x}")
        logging.info(f"output:")
        for key in tree:
            logging.info(f"{key} : {tree[key]}")
        logging.info("===" * 10)
    keys = list(tree.keys())
    sorted_keys = sorted(keys, key = len)
    return tree, sorted_keys

def get_inputs(x):
    x = group2list(x)
    x = ";".join(x)
    x = x.split(";")
    x = [clean(x0) for x0 in x if len(clean(x0)) > 0]

    y = {}
    for x0 in x:
        parts = x0.split("=")
        if len(parts) == 1:
            y[x0] = x0
        elif len(parts) == 2:
            y[parts[0]] = parts[1]
        else:
            logging.info(f"{x0} not identified")
    return y

def function_list():
    functions = [
        Xs_Norm,
        Xs_Group_Mean,
        Xs_Group_Neu,
        Xs_HHI,
        Clip,
        Lag,
        Delta,
        Uncor,
        Ts_Mean,
        Ts_Med,
        Ts_Std,
        Ts_Mean_Linear,
        Ts_Mean_Exp,
        Ts_Uncor,
        Ts_KalmanFilter,
        Ts_BayesianFilter,
        Ts_Svd,
        Ts_Prophet,
        Mix_Min_Booksize
    ]
    return functions

def generate_one_step(mat, fullexpression, tree, regen_existing=False):
    if fullexpression in mat.columns:
        if not regen_existing:
            logging.info(f"{fullexpression} already existing, skip calculating")
            return
    if fullexpression not in tree:
        logging.info(f"{fullexpression} not found")
        return
    if "function" not in tree[fullexpression]:
        logging.info(f"{fullexpression} with no function: {tree[fullexpression]}")
        return
    function = tree[fullexpression]["function"]
    elements = tree[fullexpression]["elements"]
    for i in range(0, len(elements)):
        e = elements[i]
        if "number" in tree[e]:
            if "." in e:
                elements[i] = float(e)
            else:
                elements[i] = int(e)
        elif e == "True":
            elements[i] = True
        elif e == "False":
            elements[i] = True
        elif e == "" or "group" in tree[e]:
            elements[i] = e # do nothing
        elif e not in mat.columns:
            logging.info(f"error: element {e} not found in input, please check")
            return
    t = time.time()
    if function in "+-*/^":
        for i in range(0, len(elements)):
            if isinstance(elements[i], str):
                temp = mat[elements[i]].replace([np.nan, -np.inf, np.inf], 0)
            else:
                temp = elements[i]
            if i == 0:
                mat[fullexpression] = temp
            else:
                if function == "+":
                    mat[fullexpression] += temp
                if function == "-":
                    mat[fullexpression] -= temp
                if function == "*":
                    mat[fullexpression] *= temp
                if function == "/":
                    mat[fullexpression] /= temp
                if function == "^":
                    mat[fullexpression] = mat[fullexpression] ** temp
    else:
        func = None
        for f in function_list():
            if f.__name__ == function:
                func = f
        if func is None:
            logging.info(f"error: function {function} not found in input, please check")
            return
        logging.info(f"generating {func.__name__} {elements}")
        ### no kwargs parsing
        if len(elements) == 1:
            mat[fullexpression] = func(mat, elements[0])
        elif len(elements) == 2:
            mat[fullexpression] = func(mat, elements[0], elements[1])
        elif len(elements) == 3:
            mat[fullexpression] = func(mat, elements[0], elements[1], elements[2])
        elif len(elements) == 4:
            mat[fullexpression] = func(mat, elements[0], elements[1], elements[2], elements[3])
        else:
            logging.info(f"error elements too much {elements}")
    logging.info(f"{fullexpression} : {time.time() - t} seconds")
    return


def generate_several_steps(mat, tree, sorted_keys):
    for key in sorted_keys:
        if "function" in tree[key]:
            generate_one_step(mat, key, tree, regen_existing=False)
def generate_long_expression(mat, long_expression, nickname=None, output_details=False):
    long_expression = clean(long_expression)
    tree, sorted_keys = parse_expression_tree(long_expression, {}, output_details=False)
    if output_details:
        logging.info(long_expression)
        logging.info(tree)
        logging.info(sorted_keys)
    generate_several_steps(mat, tree, sorted_keys)
    if nickname is not None and nickname != long_expression:
        mat[nickname] = mat[long_expression]

def addlist(list1, list2):
    return list1 + [x for x in list2 if not x in list1]

def quick_grammar(df, expressions, alphalist = [], prefix = "alpha_"):
    inputs = get_inputs(expressions)
    logging.info(f"grammar inputs {inputs}")
    for nickname, long_expression in inputs.items():
        generate_long_expression(df, long_expression, nickname = nickname, output_details = False)
    alphalist = addlist(alphalist, [x for x in list(inputs.keys()) if judge_kind(x) == "variable" and (prefix in x)])
    logging.info(f"grammar alphalist: {alphalist}")
    return df, alphalist

def quick_clean(df):
    for col in df.columns:
        if "(" in col:
            del df[col]
    return df