import pandas as pd
import numpy as np
import lightgbm as lgb  #3.3.3
import gc
import joblib  #1.3.1
import os
import time
import traceback
import multiprocessing
import scipy as sp

from joblib import Parallel, delayed
from grammar import quick_grammar
from numba import njit, prange
from contextlib import contextmanager
from itertools import combinations
from collections import defaultdict
from sklearn.metrics import mean_absolute_error
from lightgbm import log_evaluation, early_stopping
# from bayes_opt import BayesianOptimization
from warnings import simplefilter
from sklearn.base import BaseEstimator, TransformerMixin
from numpy import abs
from numpy import log
from numpy import sign
from scipy.stats import rankdata
from matplotlib import pyplot as plt

simplefilter(action="ignore", category=pd.errors.PerformanceWarning)

class FEATURIZER_CFG:
    """
    Configuration class for feature engineering
    """
    target = 'target'
    Is_Offline = False
    Is_Train = True
    Is_Infer = True
    N_Folds = 5
    USE_PRECOMPUTE_FEATURES = False
    USE_PRECOMPUTE_VARS_DICT = True
    MY_Path = r'D:\jiadi\optiver-trading-at-the-close'
    N_Jobs = min(multiprocessing.cpu_count(), 32)
    split_day = 435  # Split day for time series data
    DEBUG = True


def reduce_mem_usage(df, verbose=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64', 'int64[pyarrow]', 'double[pyarrow]',
                'Int16', 'Int32', 'Int64', 'Float16', 'Float32', 'Float64']
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtypes
        if col_type in numerics:
            try:
                c_min = df[col].min()
                c_max = df[col].max()
                if str(col_type)[:3] in ['int', 'Int']:
                    if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                        df[col] = df[col].astype(np.int8)
                    elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                        df[col] = df[col].astype(np.int16)
                    elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                        df[col] = df[col].astype(np.int32)
                    elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                        df[col] = df[col].astype(np.int64)
                else:
                    if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:   #之前commet
                        df[col] = df[col].astype(np.float32)
                    elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                        df[col] = df[col].astype(np.float32)
                    else:
                        df[col] = df[col].astype(np.float64)
            except: #columns all nan
                df[col] = df[col].astype(np.float32)
    end_mem = df.memory_usage().sum() / 1024**2
    print('Memory usage after optimization is: {:.2f} MB'.format(end_mem))
    print('Decreased by {:.1f}%'.format(100 * (start_mem - end_mem) / start_mem))
    return df


def log_return(series: np.ndarray, window): #TODO:需要加速
    # return np.clip(np.log(series).diff(window), -10, 10)
    return np.log(series).diff(window)

@njit(cache=True)
def realized_volatility(series):
    return np.sqrt(np.nanmean(series**2))


@njit(cache=True)
def compute_triplet_imbalance(df_values, comb_indices):
    '''
    (max-mid)/(mid-min), min/max
    '''
    num_rows = df_values.shape[0]
    num_combinations = len(comb_indices)
    imbalance_features = np.empty((num_rows, 2*num_combinations))

    for i in prange(num_combinations):
        a, b, c = comb_indices[i]
        for j in range(num_rows):
            max_val = max(df_values[j, a], df_values[j, b], df_values[j, c])
            min_val = min(df_values[j, a], df_values[j, b], df_values[j, c])
            mid_val = df_values[j, a] + df_values[j, b] + df_values[j, c] - min_val - max_val

            if mid_val == min_val:
                imbalance_features[j, 2*i] = np.nan
            else:
                imbalance_features[j, 2*i] = (max_val - mid_val) / (mid_val - min_val)
            imbalance_features[j, 2*i+1] = min_val/max_val
    return imbalance_features


def calculate_triplet_imbalance_numba(price, df):

    df_values = df[price].values
    comb_indices = [(price.index(a), price.index(b), price.index(c)) for a, b, c in combinations(price, 3)]
    features_array = compute_triplet_imbalance(df_values, comb_indices)
    temp = [[f"{a}_{b}_{c}_imb2", f"{a}_{b}_{c}_imb3"] for a, b, c in combinations(price, 3)]
    columns = sum(temp, [])
    features = pd.DataFrame(features_array, columns=columns)
    return features


def write_rolling_features(roll_cols, group, rolling_window):
    df = pd.DataFrame()
    new_cols = []
    for col in roll_cols:
        for window in rolling_window:
            df[f'{col}_rmean_{window}'] = group[col].rolling(window, 1).mean(engine='numba', engine_kwargs={'nopython': True})
            df[f'{col}_rnanstd_{window}'] = group[col].rolling(window, 1).std(engine='numba',engine_kwargs={'nopython': True})
            df[f'{col}_rrvol_{window}'] = group[col].rolling(window, 1).apply(realized_volatility,engine='numba', raw=True).droplevel(level=[0, 1])
            new_cols+=[f'{col}_rmean_{window}', f'{col}_rnanstd_{window}', f'{col}_rrvol_{window}']
    return df, new_cols


from typing import List, Union, Dict, Any

def RANK(data: pd.DataFrame):
    return data.rank(axis=1, pct=True)

def IFELSE(condition: pd.DataFrame, A: Union[pd.DataFrame, Any], B: Union[pd.DataFrame, Any]):
    """
    条件选择
    """
    if isinstance(A, pd.DataFrame):
        na_map = A.isna().astype(float).replace(1., np.nan)
        return A.where(condition, B) + na_map
    elif isinstance(B, pd.DataFrame):
        na_map = B.isna().astype(float).replace(1., np.nan)
        return B.where(~condition, A) + na_map
    else:
        raise ValueError("A, B 必须有一个是DataFrame")

def COUNT(condition: pd.DataFrame, n: int, na_map: pd.DataFrame = None):
    """
    滚动计数
    """
    condition = condition.astype(int)
    if na_map is not None:
        condition = condition + na_map
    return condition.rolling(n).sum()

def SMA(data: pd.DataFrame, n: int, m: int, ignore_nan=True):
    assert n > m
    na_map = data.isna().astype(float).replace(1., np.nan)
    return data.ewm(alpha=m / n, ignore_na=ignore_nan).mean() + na_map

def WMA(data: pd.DataFrame, n: int):
    weight = np.arange(n) + 1
    weight = weight / weight.sum()
    idx = data.index
    col = data.columns
    return pd.DataFrame(_wma(data.values, weight), index=idx, columns=col)

def DECAYLINEAR(data: pd.DataFrame, n: int):
    """
    线性衰减移动平均加权
    """
    weight = np.array([2 * i / (n * (n + 1)) for i in range(1, n + 1)])
    idx = data.index
    col = data.columns
    return pd.DataFrame(_wma(data.values, weight), index=idx, columns=col)

def DELTA(A: pd.DataFrame, n: int):
    return A.diff(n)

def DELAY(A: pd.DataFrame, n: int):
    return A.shift(n)

def SUM(A: pd.DataFrame, n: int):
    return A.rolling(n).sum()

def MEAN(price: pd.DataFrame, N: int):
    """
    滚动平均
    """
    return price.rolling(N, min_periods=1).mean()

def CORR(A: pd.DataFrame, B: pd.DataFrame, n: int):
    return A.rolling(n, min_periods=2).corr(B)

def COVARIANCE(A: pd.DataFrame, B: pd.DataFrame, n: int, sign=False):
    """
    滚动协方差
    """
    if sign:
        return np.sign(A.rolling(n).cov(B))
    else:
        return A.rolling(n).cov(B)

def MAX(A: pd.DataFrame, B):
    """
    两个序列的最大值
    """
    return np.maximum(A, B)

def MIN(A: pd.DataFrame, B: pd.DataFrame):
    """
    两个序列的最大值
    """
    return np.minimum(A, B)

def TS_MAX(A: pd.DataFrame, N: int):
    """
    N日内最大值
    """
    return A.rolling(N, min_periods=1).max()

def TS_MIN(A: pd.DataFrame, N: int):
    """
    N日内最小值
    """
    return A.rolling(N, min_periods=1).min()

def TS_RANK(data: pd.DataFrame, N: int):
    """
    滚动排名
    """
    return data.rolling(N, min_periods=1).rank(pct=True)

def _wma(A_arr: np.ndarray, weight: np.ndarray):
    """
    其中A的每一列对应B的每一列
    A_arr: (N, L)
    B_arr: (N, L)
    """
    N, L = A_arr.shape
    n = weight.shape[0]
    result = np.zeros((N, L))
    result[:n] = np.nan
    for rolling_ind in range(n - 1, A_arr.shape[0]):
        bch_x = A_arr[rolling_ind - n + 1: rolling_ind + 1, :]
        for col_ind in range(L):
            x = bch_x[:, col_ind]
            if np.all(np.isnan(x)):
                result[rolling_ind, col_ind] = np.nan
            else:
                result[rolling_ind, col_ind] = np.nansum(x * weight)
    return result

max_lookback_window = 6

def calc_open(x, n=max_lookback_window):
  ret = x.shift(n-1)
  ret[:n] = x.iloc[0]
  return ret.values

def calc_close(x):
  return x

def calc_high(x, n=max_lookback_window):
  return x.rolling(n, min_periods=1).max().values

def calc_low(x, n=max_lookback_window):
  return x.rolling(n, min_periods=1).min().values

def calc_matched_size(x, n=max_lookback_window):
  ret = x.diff(n)
  ret[:n] = x[:n] - x.iloc[0]
  ret = np.maximum(ret, 0) * 100 + 1
  return ret.values

def calc_volume_weight(x):
    matched_size = x.diff().values
    matched_size[0] = 0
    matched_size = np.maximum(matched_size, 0) * 100 + 1
    return matched_size

def calc_avg_wap(x):
    avg_wap = (x + x.shift(1)) / 2
    avg_wap[0] = x.iloc[0]
    return avg_wap

def calc_return(x, n=max_lookback_window):
  ret = x / x.shift(n)
  ret[:n] = x[:n] / x.iloc[0]
  return ret.values

def calc_prev_close(x, n=max_lookback_window):
    ret = x.shift(n)
    ret[:n] = x.iloc[0]
    return ret

max_lookback_window_101 = 6

def calc_open_101(x, n=max_lookback_window_101):
  ret = x.shift(n-1)
  ret[:n] = x.iloc[0]
  return ret.values

def calc_close_101(x):
  return x

def calc_high_101(x, n=max_lookback_window_101):
  return x.rolling(n, min_periods=1).max().values

def calc_low_101(x, n=max_lookback_window_101):
  return x.rolling(n, min_periods=1).min().values

def calc_return_101(x, n=max_lookback_window_101):
  ret = x / x.shift(n)
  ret[:n] = x[:n] / x.iloc[0]
  return ret.values

def calc_matched_size_101(x, n=max_lookback_window_101):
  ret = x.diff(n)
  ret[:n] = x[:n] - x.iloc[0]
  ret = np.maximum(ret, 0) * 100 + 1
  return ret.values

def calc_volume_weight_101(x):
    matched_size = x.diff()
    matched_size[0] = 0
    matched_size = np.maximum(matched_size, 0) * 100 + 1
    return matched_size

def calc_avg_wap_101(x):
    avg_wap = (x + x.shift(1)) / 2
    avg_wap[0] = x.iloc[0]
    return avg_wap

def ts_sum(df, window=10):
    """
    Wrapper function to estimate rolling sum.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series min over the past 'window' days.
    """
    return df.rolling(window).sum()

def sma(df, window=10):
    """
    Wrapper function to estimate SMA.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series min over the past 'window' days.
    """
    return df.rolling(window).mean()

def stddev(df, window=10):
    """
    Wrapper function to estimate rolling standard deviation.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series min over the past 'window' days.
    """
    return df.rolling(window).std()

def correlation(x, y, window=10):
    """
    Wrapper function to estimate rolling corelations.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series min over the past 'window' days.
    """
    return x.rolling(window).corr(y)

def covariance(x, y, window=10):
    """
    Wrapper function to estimate rolling covariance.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series min over the past 'window' days.
    """
    return x.rolling(window).cov(y)

def rolling_rank(na):
    """
    Auxiliary function to be used in pd.rolling_apply
    :param na: numpy array.
    :return: The rank of the last value in the array.
    """
    return rankdata(na)[-1]

def ts_rank(df, window=10):
    """
    Wrapper function to estimate rolling rank.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series rank over the past window days.
    """
    return df.rolling(window).apply(rolling_rank)

def rolling_prod(na):
    """
    Auxiliary function to be used in pd.rolling_apply
    :param na: numpy array.
    :return: The product of the values in the array.
    """
    return np.prod(na)

def product(df, window=10):
    """
    Wrapper function to estimate rolling product.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series product over the past 'window' days.
    """
    return df.rolling(window).apply(rolling_prod)

def ts_min(df, window=10):
    """
    Wrapper function to estimate rolling min.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series min over the past 'window' days.
    """
    return df.rolling(window).min()

def ts_max(df, window=10):
    """
    Wrapper function to estimate rolling min.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series max over the past 'window' days.
    """
    return df.rolling(window).max()

def delta(df, period=1):
    """
    Wrapper function to estimate difference.
    :param df: a pandas DataFrame.
    :param period: the difference grade.
    :return: a pandas DataFrame with today’s value minus the value 'period' days ago.
    """
    return df.diff(period)

def delay(df, period=1):
    """
    Wrapper function to estimate lag.
    :param df: a pandas DataFrame.
    :param period: the lag grade.
    :return: a pandas DataFrame with lagged time series
    """
    return df.shift(period)

def rank(df):
    """
    Cross sectional rank
    :param df: a pandas DataFrame.
    :return: a pandas DataFrame with rank along columns.
    """
    #return df.rank(axis=1, pct=True)
    return df.rank(pct=True)

def scale(df, k=1):
    """
    Scaling time serie.
    :param df: a pandas DataFrame.
    :param k: scaling factor.
    :return: a pandas DataFrame rescaled df such that sum(abs(df)) = k
    """
    return df.mul(k).div(np.abs(df).sum())

def ts_argmax(df, window=10):
    """
    Wrapper function to estimate which day ts_max(df, window) occurred on
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: well.. that :)
    """
    return df.rolling(window).apply(np.argmax) + 1

def ts_argmin(df, window=10):
    """
    Wrapper function to estimate which day ts_min(df, window) occurred on
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: well.. that :)
    """
    return df.rolling(window).apply(np.argmin) + 1

def decay_linear(df, period=10):
    """
    Linear weighted moving average implementation.
    :param df: a pandas DataFrame.
    :param period: the LWMA period
    :return: a pandas DataFrame with the LWMA.
    """
    # Clean data
    if df.isnull().values.any():
        df.fillna(method='ffill', inplace=True)
        df.fillna(method='bfill', inplace=True)
        df.fillna(value=0, inplace=True)
    na_lwma = np.zeros_like(df)
    na_lwma[:period, :] = df.iloc[:period, :]
    na_series = df.to_numpy()

    divisor = period * (period + 1) / 2
    y = (np.arange(period) + 1) * 1.0 / divisor
    # Estimate the actual lwma with the actual close.
    # The backtest engine should assure to be snooping bias free.
    for row in range(period - 1, df.shape[0]):
        x = na_series[row - period + 1: row + 1, :]
        na_lwma[row, :] = (np.dot(x.T, y))
    return pd.DataFrame(na_lwma, index=df.index, columns=['CLOSE'])


class GTJA_191:
    def __init__(self, dfs):
        stocks = dfs.keys()
        self.open_price = pd.concat([df['open_price'] for df in dfs.values()], axis=1)
        self.open_price.columns = dfs.keys()
        self.close      = pd.concat([df['close'] for df in dfs.values()], axis=1)
        self.close.columns = dfs.keys()
        self.low        = pd.concat([df['low'] for df in dfs.values()], axis=1)
        self.low.columns = dfs.keys()
        self.high       = pd.concat([df['high'] for df in dfs.values()], axis=1)
        self.high.columns = dfs.keys()
        self.vwap  = pd.concat([df['avg_price'] for df in dfs.values()], axis=1)
        self.vwap.columns = dfs.keys()
        self.prev_close = pd.concat([df['prev_close'] for df in dfs.values()], axis=1)
        self.prev_close.columns = dfs.keys()
        self.volume     = pd.concat([df['volume'] for df in dfs.values()], axis=1)
        self.volume.columns = dfs.keys()
        self.amount     = pd.concat([df['amount'] for df in dfs.values()], axis=1)
        self.amount.columns = dfs.keys()
        self.benchmark_open_price = self.open_price.mean(axis=1)
        self.benchmark_close_price = self.close.mean(axis=1)
        #########################################################################


    def alpha191_007(self, period=3):
        """
        ((RANK(MAX((VWAP - CLOSE), 3)) + RANK(MIN((VWAP - CLOSE), 3))) * RANK(DELTA(VOLUME, 3)))
        -->
        [RANK(MAX(VWAP - CLOSE, 3)) + RANK(MIN(VWAP - CLOSE, 3))] * RANK(DELTA(VOLUME, 3))
        """
        rkmax = (self.vwap - self.close).rolling(period, min_periods=1).max().rank(axis=1, pct=True)
        rkmin = (self.vwap - self.close).rolling(period, min_periods=1).min().rank(axis=1, pct=True)
        rkdelta = self.volume.diff(periods=period).rank(axis=1, pct=True)
        alpha = (rkmax + rkmin) * rkdelta
        return alpha

    def alpha191_039(self):
        """
        (
            RANK(DECAYLINEAR(DELTA((CLOSE), 2), 8)) - RANK(DECAYLINEAR(CORR(((VWAP * 0.3) + (OPEN * 0.7)), SUM(MEAN(VOLUME, 180), 37), 14), 12))
        ) * -1
        @res:
        """
        alpha = RANK(DECAYLINEAR(DELTA(self.close, 2), 8))
        alpha -= RANK(DECAYLINEAR(CORR((self.vwap * 0.3 + self.open_price * 0.7),
                                       SUM(MEAN(self.volume, 180), 37), 14), 12))
        return -1 * alpha

    def alpha191_048(self, use_vwap=False):
        """
        -1 * (
            (
                RANK(
                    (
                        SIGN((CLOSE - DELAY(CLOSE, 1))) + SIGN((DELAY(CLOSE, 1) - DELAY(CLOSE, 2))) + SIGN((DELAY(CLOSE, 2) - DELAY(CLOSE, 3)))
                    )
                )
            ) * SUM(VOLUME, 5)
        ) / SUM(VOLUME, 20)
        @res:
        """
        _p = self.vwap if use_vwap else self.close
        alpha = np.sign(_p.diff(1)) + \
                np.sign(_p.shift(1).diff(1)) + \
                np.sign(_p.shift(2).diff(1))
        alpha = alpha.rank(axis=1, pct=True) * self.volume.rolling(5, min_periods=1).sum() / self.volume.rolling(20, min_periods=1).sum()
        return alpha

    def alpha191_065(self, period=6, use_vwap=False):
        """
        MEAN(CLOSE,6)/CLOSE
        @res:
        """
        _p = self.vwap if use_vwap else self.close
        alpha = MEAN(_p, period) / _p
        return alpha

    def alpha191_066(self, period=6, use_vwap=False):
        """
        (CLOSE-MEAN(CLOSE,6))/MEAN(CLOSE,6)*100
        @res:
        """
        _p = self.vwap if use_vwap else self.close
        alpha = (_p - MEAN(_p, period)) / MEAN(_p, period) * 100
        return alpha

    def alpha191_091(self, vol_period=40, corr_period=5, use_vwap=False):
        """
        (
            RANK((CLOSE - MAX(CLOSE, 5))) *
            RANK(CORR(MEAN(VOLUME, 40), LOW, 5))
        ) * -1
        @res:
        @NOTE:
            MAX(CLOSE, 5) ???
        """
        _p = self.vwap if use_vwap else self.close
        alpha = RANK(_p - TS_MAX(_p, 5)) * \
                RANK(CORR(MEAN(self.volume, vol_period), self.low, corr_period)) * -1
        return alpha

    def alpha191_092(self, decay_period1=3, decay_period2=5, rank_period=15):
        """
        MAX(
            RANK(DECAYLINEAR(DELTA(((CLOSE * 0.35) + (VWAP * 0.65)), 2), 3)),
            TSRANK(DECAYLINEAR(ABS(CORR((MEAN(VOLUME, 180)), CLOSE, 13)), 5), 15)
        ) * -1
        @res:
        """
        alpha = MAX(
            RANK(DECAYLINEAR(DELTA((self.close * 0.35 + self.vwap * 0.65), 2), decay_period1)),
            TS_RANK(DECAYLINEAR(np.abs(CORR(MEAN(self.volume, 180), self.close, 13)), decay_period2), rank_period)
        ) * -1
        return alpha

    def alpha191_120(self):
        """
        (RANK((VWAP - CLOSE)) / RANK((VWAP + CLOSE)))
        @res:
        """
        alpha = RANK(self.vwap - self.close) / RANK(self.vwap + self.close)
        return alpha

    def alpha191_137(self, use_vwap=False):
        """
        condition1 = abshc > abslc;
        condition2 = abshc > abshl;
        condition3 = abslc > abshc;
        abshc = ABS(HIGH - DELAY(CLOSE, 1));
        abslc = ABS(LOW - DELAY(CLOSE, 1));
        absco = ABS(DELAY(CLOSE, 1) - DELAY(OPEN, 1));
        abshl = ABS(HIGH - DELAY(LOW, 1));
        16 * (CLOSE - DELAY(CLOSE, 1) + (CLOSE - OPEN) / 2 + DELAY(CLOSE, 1) - DELAY(OPEN, 1)) /
        ((condition1 & condition2 ? abshc + abslc / 2 + absco / 4 : (abslc > abshl & condition3 ? abslc + abshc / 2 + absco / 4 : abshl + absco / 4)))
        * MAX(abshc, abslc)
        @res:
        """
        _p = self.vwap if use_vwap else self.close
        abshc = np.abs(self.high - DELAY(_p, 1))
        abslc = np.abs(self.low - DELAY(_p, 1))
        absco = np.abs(DELAY(_p, 1) - DELAY(self.open_price, 1))
        abshl = np.abs(self.high - DELAY(self.low, 1))
        alpha = 16 * (_p - DELAY(_p, 1) + (_p - self.open_price) / 2 +
                      DELAY(_p, 1) - DELAY(self.open_price, 1))
        alpha = alpha / (IFELSE((abshc > abslc) * (abshc > abshl), abshc + abslc / 2 + absco / 4,
                                IFELSE((abslc > abshl) * (abslc > abshc),
                                       abslc + abshc / 2 + absco / 4, abshl + absco / 4)) + 1e-7)
        alpha = alpha * MAX(abshc, abslc)
        return alpha

    def alpha191_142(self):
        """
        (((-1 * RANK(TSRANK(CLOSE, 10))) * RANK(DELTA(DELTA(CLOSE, 1), 1))) * RANK(TSRANK((VOLUME
        /MEAN(VOLUME,20)), 5)))
        @res:
        """
        alpha = (((-1 * RANK(TS_RANK(self.close, 10))) * RANK(DELTA(DELTA(self.close, 1), 1))) *
                 RANK(TS_RANK((self.volume / MEAN(self.volume, 20)), 5)))
        return alpha

    def alpha191_163(self, period=20):
        """
        RANK(((((-1 * RET) * MEAN(VOLUME,20)) * VWAP) * (HIGH - CLOSE)))
        @res:
        """
        ret = self.close / self.close.shift(1) - 1
        alpha = RANK(((((-1 * ret) * MEAN(self.volume, period)) * self.vwap) * (self.high - self.close)))
        return alpha

    def alpha191_171(self):
        """
        ((-1 * ((LOW - CLOSE) * (OPEN^5))) / ((CLOSE - HIGH) * (CLOSE^5)))
        @res:
        """
        alpha = (-1 * ((self.low - self.close) * (self.open_price ** 5))) / \
                ((self.close - self.high + 1e-7) * (self.close ** 5))
        return alpha

    def alpha191_184(self):
        """
        (RANK(CORR(DELAY((OPEN - CLOSE), 1), CLOSE, 200)) + RANK((OPEN - CLOSE)))
        @res:
        """
        alpha = RANK(CORR(DELAY((self.open_price - self.close), 1), self.close, 200)) + \
                RANK((self.open_price - self.close))
        return alpha


class Alphas(object):
    def __init__(self, df_data):

        self.open = df_data.groupby("date_id")["wap"].transform(calc_open_101)
        self.close = df_data.groupby("date_id")["wap"].transform(calc_close_101)
        self.high = df_data.groupby("date_id")["wap"].transform(calc_high_101)
        self.low = df_data.groupby("date_id")["wap"].transform(calc_low_101)
        self.returns = df_data.groupby("date_id")["wap"].transform(calc_return_101)
        df_data['volume_wgt'] = df_data.groupby("date_id")["matched_size"].transform(calc_volume_weight_101)
        df_data['avg_wap'] = df_data.groupby("date_id")["wap"].transform(calc_avg_wap_101)
        df_data['product'] = df_data['volume_wgt'] * df_data['avg_wap']
        df_data['vwap'] = df_data.groupby("date_id")['product'].transform(lambda x: x.rolling(max_lookback_window_101, min_periods=1).sum()) / \
                            df_data.groupby("date_id")['volume_wgt'].transform(lambda x: x.rolling(max_lookback_window_101, min_periods=1).sum())
        self.vwap = df_data['vwap']
        self.volume = df_data.groupby("date_id")["matched_size"].transform(calc_matched_size_101) / self.vwap

    # Alpha#9	 ((0 < ts_min(delta(close, 1), 5)) ? delta(close, 1) : ((ts_max(delta(close, 1), 5) < 0) ?delta(close, 1) : (-1 * delta(close, 1))))
    def alpha009(self):
        delta_close = delta(self.close, 1)
        cond_1 = ts_min(delta_close, 5) > 0
        cond_2 = ts_max(delta_close, 5) < 0
        alpha = -1 * delta_close
        alpha[cond_1 | cond_2] = delta_close
        return alpha

    # Alpha#33	 rank((-1 * ((1 - (open / close))^1)))
    def alpha033(self):
        return rank(-1 + (self.open / self.close))

    # Alpha#42	 (rank((vwap - close)) / rank((vwap + close)))
    def alpha042(self):
        return rank((self.vwap - self.close)) / rank((self.vwap + self.close))

    # Alpha#49	 (((((delay(close, 20) - delay(close, 10)) / 10) - ((delay(close, 10) - close) / 10)) < (-1 *0.1)) ? 1 : ((-1 * 1) * (close - delay(close, 1))))
    def alpha049(self):
        inner = (((delay(self.close, 20) - delay(self.close, 10)) / 10) - ((delay(self.close, 10) - self.close) / 10))
        alpha = (-1 * delta(self.close))
        alpha[inner < -0.1] = 1
        return alpha

    # Alpha#51	 (((((delay(close, 20) - delay(close, 10)) / 10) - ((delay(close, 10) - close) / 10)) < (-1 *0.05)) ? 1 : ((-1 * 1) * (close - delay(close, 1))))
    def alpha051(self):
        inner = (((delay(self.close, 20) - delay(self.close, 10)) / 10) - ((delay(self.close, 10) - self.close) / 10))
        alpha = (-1 * delta(self.close))
        alpha[inner < -0.05] = 1
        return alpha

    # Alpha#54	 ((-1 * ((low - close) * (open^5))) / ((low - high) * (close^5)))
    def alpha054(self):
        inner = (self.low - self.high).replace(0, -0.0001)
        return -1 * (self.low - self.close) * (self.open ** 5) / (inner * (self.close ** 5))

   # Alpha#57	 (0 - (1 * ((close - vwap) / decay_linear(rank(ts_argmax(close, 30)), 2))))
    def alpha057(self):
        return (0 - (1 * ((self.close - self.vwap) / decay_linear(rank(ts_argmax(self.close, 30)).to_frame(), 2).CLOSE)))

    # Alpha#101	 ((close - open) / ((high - low) + .001))
    def alpha101(self):
        return (self.close - self.open) /((self.high - self.low) + 0.001)


def get_alpha(df):
    stock=Alphas(df)
    df['alpha009']=stock.alpha009()
    df['alpha033']=stock.alpha033()
    df['alpha042']=stock.alpha042()
    df['alpha049']=stock.alpha049()
    df['alpha051']=stock.alpha051()
    df['alpha054']=stock.alpha054()
    df['alpha057']=stock.alpha057()
    df['alpha101']=stock.alpha101()
    return df

def calc_alpha101_feats(dfs):
  for k, df in dfs.items():
    df = get_alpha(df)




def preproc(train, min_date_id = 0):
    # min_date_id = 470
    erd = train.query(f"date_id > {min_date_id}")
    ref_adv = erd.groupby(["date_id", "stock_id"])["matched_size"].first().reset_index().rename(columns = {"matched_size": "ref_adv"})

    COLS_PX = [
        "bid_price",
        "ask_price",
        "wap",
        "far_price",
        "reference_price",
        "near_price",
    ]
    COLS_QTY = [
        "bid_size",
        "ask_size",
        "imbalance_size",
        "matched_size",
    ]
    erd["ref_px"] = 1.0
    # erd["ref_adv"] = 1.0
    if not "ref_adv" in erd.columns:
        erd = erd.merge(ref_adv, on = ["date_id", "stock_id"], how = "left")
    erd = sv_px(erd, COLS_PX)
    erd = sv_qty(erd, COLS_QTY)

    erd["sid"] = erd["stock_id"]
    erd["sid_did"] = erd.apply(lambda x: f"{x['stock_id']:06d}{x['date_id']:06d}", axis = 1)
    erd["date"] = erd.apply(lambda x: f"{x['date_id']:06d}{x['seconds_in_bucket']:06d}", axis = 1)
    erd["compo"] = "OVKG"
    erd["country"] = "US"
    erd["sid_tid"] = erd.apply(lambda x: f"{x['sid']:06d}{x['seconds_in_bucket']:06d}", axis = 1)

    map = pd.read_csv("./OVKG_map.csv")
    map["gics4"] = map["gics8"].apply(lambda x: str(x)[:4] )
    map["sid"] = map["stock_id"]
    erd = erd.merge(map[["sid", "gics4"]], on = ["sid"], how = "left")
    return erd



class OptiverFeaturizer(BaseEstimator, TransformerMixin):
    def __init__(self, config):
        # configurations
        self.config = config
        self.target = self.config.target
        temp = ['dispersion_diff', 'slope_ask', 'reference_price_bid_price_wap_imb7',
                'reference_price_ask_price_wap_imb7', 'reference_price_bid_price_wap_imb9',
                'reference_price_wap_imb']
        orig_price_vol_num_vars = ['reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price',
                                   'bid_price', 'bid_size', 'ask_price', 'ask_size', 'wap']
        additial_columns = orig_price_vol_num_vars + ['mid_price', 'swap_price', 'total_volume1', 'total_volume2',
                                                      'flow']
        self.roll_cols = list(set(temp + additial_columns))

        openfe_df = pd.read_excel(f'{self.config.MY_Path}/params/openfe_features_selected.xlsx',
                                  sheet_name='merged').sort_values(by='score', ascending=False)
        self.openfe_col_list = openfe_df.features.to_list()

        if self.config.USE_PRECOMPUTE_VARS_DICT:
            self.vars_dict = joblib.load(f'{self.config.MY_Path}/feature/vars_dict1.pkl')

    def basic_feat_eng(self, df):
        # import cudf
        # df = cudf.from_pandas(df)
        df = df.sort_values(by=['date_id', 'seconds_in_bucket', 'stock_id']).reset_index(drop=True)
        sizes = ["matched_size", "bid_size", "ask_size", "imbalance_size"]

        df['tick_diff'] = df.groupby(['date_id', 'stock_id'])['wap'].diff()
        df['mid_price'] = (df['ask_price'] + df['bid_price']) / 2
        df['swap_price'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / (
                    df['bid_size'] + df['ask_size'])

        df['total_volume1'] = df['ask_size'] + df['bid_size']
        df['total_volume2'] = df['matched_size'] + df['imbalance_size']
        df['imb_s1'] = (df['bid_size'] - df['ask_size']) / (df['bid_size'] + df['ask_size'])
        df['imb_s2'] = (df['imbalance_size'] - df['matched_size']) / (df['matched_size'] + df['imbalance_size'])
        df['imb_s3'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / (
                df['bid_price'] * df['bid_size'] - df['ask_price'] * df['ask_size'])
        df['imbalance_ratio'] = df['imbalance_size'] / df['matched_size']
        df['slope_bid'] = df['bid_size'] / ((df['bid_size'] + df['ask_size']) / 2 + 1)
        df['slope_ask'] = df['ask_size'] / ((df['bid_size'] + df['ask_size']) / 2 + 1)

        prices = ['reference_price', 'far_price', 'near_price', 'ask_price', 'bid_price', 'wap']
        interactive_num_vars = []

        # all prices pairs filter correlation > 0.9

        # (x-y)
        df['near_price_minus_wap'] = df['near_price'] - df['wap']
        df['near_price_minus_ask_price'] = df['near_price'] - df['ask_price']
        df['far_price_minus_near_price'] = df['far_price'] - df['near_price']

        # (x-y)/(x+y)
        df['ask_price_wap_imb'] = (df['ask_price'] - df['wap']) / (df['ask_price'] + df['wap'])
        df['reference_price_wap_imb'] = (df['reference_price'] - df['wap']) / (df['reference_price'] + df['wap'])
        df['reference_price_bid_price_imb'] = (df['reference_price'] - df['bid_price']) / (
                df['reference_price'] + df['bid_price'])

        # 1/(1/x+1/y)
        df['far_price_bid_price_imb4'] = 1 / (1 / df['far_price'] + 1 / df['bid_price'])
        df['reference_price_near_price_imb4'] = 1 / (1 / df['reference_price'] + 1 / df['near_price'])
        interactive_num_vars += ['near_price_minus_wap', 'near_price_minus_ask_price', 'far_price_minus_near_price',
                                 'ask_price_wap_imb',
                                 'reference_price_wap_imb', 'reference_price_bid_price_imb', 'far_price_bid_price_imb4',
                                 'reference_price_near_price_imb4']

        # z/(x+y), (x-y)/z
        for c in [
            ('reference_price', 'bid_price', 'wap'), ('reference_price', 'ask_price', 'wap'),
            ('far_price', 'near_price', 'bid_price'),
            ('reference_price', 'ask_price', 'bid_price'), ('ask_price', 'bid_price', 'wap'),
            ('reference_price', 'near_price', 'bid_price'),
            ('reference_price', 'near_price', 'ask_price'), ('reference_price', 'far_price', 'bid_price'),
            ('reference_price', 'near_price', 'wap')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb5'] = 2 * df[c[0]] / (df[c[1]] + df[c[2]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb5']

        for c in [
            ('far_price', 'near_price', 'wap'), ('near_price', 'ask_price', 'bid_price'),
            ('far_price', 'near_price', 'ask_price'),
            ('far_price', 'near_price', 'bid_price'), ('reference_price', 'far_price', 'ask_price'),
            ('far_price', 'ask_price', 'bid_price'),
            ('reference_price', 'ask_price', 'wap'), ('reference_price', 'bid_price', 'wap'),
            ('ask_price', 'bid_price', 'wap'),
            ('reference_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb6'] = 2 * df[c[1]] / (df[c[0]] + df[c[2]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb6']

        for c in [
            ('reference_price', 'ask_price', 'wap'), ('reference_price', 'bid_price', 'wap'),
            ('near_price', 'ask_price', 'wap'),
            ('reference_price', 'near_price', 'wap'), ('far_price', 'bid_price', 'wap'),
            ('far_price', 'ask_price', 'wap'),
            ('reference_price', 'near_price', 'ask_price'), ('reference_price', 'near_price', 'bid_price'),
            ('near_price', 'ask_price', 'bid_price'),
            ('reference_price', 'far_price', 'near_price'), ('far_price', 'ask_price', 'bid_price'),
            ('reference_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb7'] = 2 * df[c[2]] / (df[c[0]] + df[c[1]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb7']

        for c in [
            ('reference_price', 'near_price', 'bid_price'), ('reference_price', 'far_price', 'wap'),
            ('reference_price', 'bid_price', 'wap')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb8'] = (df[c[0]] - df[c[1]]) / df[c[2]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb8']

        for c in [
            ('reference_price', 'bid_price', 'wap'), ('reference_price', 'near_price', 'ask_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb9'] = (df[c[0]] - df[c[2]]) / df[c[1]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb9']

        for c in [
            ('ask_price', 'bid_price', 'wap'), ('far_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb10'] = (df[c[1]] - df[c[2]]) / df[c[0]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb10']

        df['if_last5min'] = df['seconds_in_bucket'].apply(lambda x: 1 if x >= 300 else 0)
        df['if_last2min'] = df['seconds_in_bucket'].apply(lambda x: 1 if x >= 480 else 0)
        df['tick_path'] = np.abs(df['tick_diff'] / df['wap'])

        group = df.groupby(['date_id', 'stock_id'], group_keys=False)
        df['bs_lag1'] = group['bid_size'].shift(1)
        df['as_lag1'] = group['ask_size'].shift(1)
        df['b1p_diff1'] = group['bid_price'].diff()
        df['a1p_diff1'] = group['ask_price'].diff()
        df['bid_wap'] = (df['wap'] - df['bid_price']) / df['wap'].clip(1e-6, )
        df['ask_wap'] = (df['ask_price'] - df['wap']) / df['wap'].clip(1e-6, )
        df['dispersion_diff'] = df['bid_wap'] - df['ask_wap']

        df["imbalance_momentum"] = group['imbalance_size'].diff(periods=1) / df['matched_size']
        df["price_spread"] = df["ask_price"] - df["bid_price"]
        df["spread_intensity"] = group['price_spread'].diff()
        df['price_pressure'] = df['imbalance_size'] * (df['ask_price'] - df['bid_price'])
        df['market_urgency'] = df['price_spread'] * df['imb_s1']
        df['depth_pressure'] = (df['ask_size'] - df['bid_size']) * (df['far_price'] - df['near_price'])

        # Calculate shifted and return features for specific columns
        return_vars, lag_vars, lag_cat_vars, diff_vars, diff_cat_vars = [], [], [], [], []

        group2 = df.groupby(['stock_id'], group_keys=False)
        for col in ['reference_price', 'wap']:
            for window in [1, 2, 3, 10]:
                df[f"{col}_shift_{window}"] = group2[col].shift(window)
                lag_vars.append(f"{col}_shift_{window}")
                df[f'log_return_{col}_{window}'] = group2[col].pct_change(window)  # 没用log_return
                return_vars.append(f'log_return_{col}_{window}')

        df['matched_size_add1'] = 1 + df['matched_size']
        df['imbalance_size_add1'] = 1 + df['imbalance_size']
        for col in ['matched_size', 'imbalance_size']:
            for window in [1, 2, 3, 10]:
                df[f"{col}_shift_{window}"] = group2[col].shift(window)
                lag_vars.append(f"{col}_shift_{window}")
                df[f'log_return_{col}_{window}'] = (group2[f"{col}_add1"]).pct_change(window)  # 没用log_return
                return_vars.append(f'log_return_{col}_{window}')

        df['imbalance_buy_sell_flag'] = df.imbalance_buy_sell_flag.apply(lambda x: 0 if x == -1 else 1)  # 0,1
        for col in ['imbalance_buy_sell_flag']:
            for window in [1, 2, 3, 10]:
                df[f"{col}_shift_{window}"] = group2[col].shift(window)  # 0,1
                lag_cat_vars.append(f"{col}_shift_{window}")
                df[f"{col}_diff_{window}"] = group2[col].diff(window).apply(lambda x: 2 if x == -1 else x)  # 0,1,2
                diff_cat_vars += [f"{col}_diff_{window}"]

        # Calculate diff features for specific columns
        for col in ['ask_price', 'bid_price', 'ask_size', 'bid_size']:
            for window in [1, 2, 3, 10]:
                df[f"{col}_diff_{window}"] = group2[col].diff(window)
                diff_vars += [f"{col}_diff_{window}"]

        df["minute"] = df["seconds_in_bucket"] // 60

        # df = df.to_pandas()

        # back to pandas
        df['tick_up_down'] = np.where(df['tick_diff'] > 0, 2, np.where(df['tick_diff'] < 0, 0, 1))  # 0,1,2
        group2 = df.groupby(['stock_id'], group_keys=False)
        df['flow'] = (
                             df['bid_size'] * np.where(df['b1p_diff1'] >= 0, 1, 0) - df['bs_lag1'] * np.where(
                         df['b1p_diff1'] <= 0, 1, 0)) - (
                             df['ask_size'] * np.where(df['a1p_diff1'] <= 0, 1, 0) - df['as_lag1'] * np.where(
                         df['a1p_diff1'] >= 0, 1, 0)
                     )
        df["global_median_size"] = (
                group2["bid_size"].rolling(1000, 1).median(engine='numba', engine_kwargs={'nopython': True}).droplevel(
                    0)
                + group2["ask_size"].rolling(1000, 1).median(engine='numba',
                                                             engine_kwargs={'nopython': True}).droplevel(0)
        )
        df['global_std_size'] = (
                group2["bid_size"].rolling(1000, 1).std(engine='numba', engine_kwargs={'nopython': True})
                + group2["ask_size"].rolling(1000, 1).std(engine='numba', engine_kwargs={'nopython': True})
        )
        df['global_ptp_size'] = (
                group2["bid_size"].rolling(1000, 1).max(engine='numba', engine_kwargs={'nopython': True})
                - group2["bid_size"].rolling(1000, 1).min(engine='numba', engine_kwargs={'nopython': True})
        )
        df['global_median_price'] = (
                group2["bid_price"].rolling(1000, 1).median(engine='numba', engine_kwargs={'nopython': True}).droplevel(
                    0)
                + group2["ask_price"].rolling(1000, 1).median(engine='numba',
                                                              engine_kwargs={'nopython': True}).droplevel(0)
        )
        df['global_std_price'] = (
                group2["bid_price"].rolling(1000, 1).std(engine='numba', engine_kwargs={'nopython': True})
                + group2["ask_price"].rolling(1000, 1).std(engine='numba', engine_kwargs={'nopython': True})
        )
        df['global_ptp_price'] = (
                group2["bid_price"].rolling(1000, 1).max(engine='numba', engine_kwargs={'nopython': True}) - group2[
            "ask_price"].rolling(1000, 1).min(engine='numba', engine_kwargs={'nopython': True})
        )

        # all triple pairs filter correlation > 0.9
        # min/max, (max-mid)/(mid-min)
        for c in [['ask_price', 'bid_price', 'wap', 'reference_price'], sizes]:  # imb2, imb3
            triplet_feature = calculate_triplet_imbalance_numba(c, df)
            df[triplet_feature.columns] = triplet_feature.values
            interactive_num_vars += list(triplet_feature.columns)

        # Calculate various statistical aggregation features
        reference_global_vars = []
        prices = ["reference_price", "far_price", "near_price", "ask_price", "bid_price", "wap"]
        for func in ["mean", "std", "skew", "kurt"]:
            df[f"all_prices_{func}"] = df[prices].agg(func, axis=1)
            df[f"all_sizes_{func}"] = df[sizes].agg(func, axis=1)
            reference_global_vars += [f"all_prices_{func}", f"all_sizes_{func}"]

        df.drop(columns=[
            'row_id', 'matched_size_add1', 'imbalance_size_add1', 'bs_lag1', 'as_lag1', 'b1p_diff1', 'a1p_diff1'
        ], inplace=True)

        df = df.replace([np.inf, -np.inf], np.nan)  # 正常情况没有np.inf

        orig_price_vol_num_vars = [
            'reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price', 'bid_price', 'bid_size',
            'ask_price', 'ask_size', 'wap']

        global_stock_id_vars = ['global_median_size', 'global_std_size', 'global_ptp_size', 'global_median_price',
                                'global_std_price', 'global_ptp_price']
        # return_vars, lag_vars, diff_vars, lag_cat_vars, diff_cat_vars

        # interactive_num_vars

        derived_price_vol_num_vars = [
            'tick_diff', 'mid_price', 'swap_price', 'total_volume1', 'total_volume2', 'imb_s1', 'imb_s2', 'imb_s3',
            'imbalance_ratio', 'slope_bid', 'slope_ask', 'tick_path', 'flow', 'bid_wap', 'ask_wap', 'dispersion_diff',
            'imbalance_momentum', 'price_spread', 'spread_intensity', 'price_pressure', 'market_urgency',
            'depth_pressure'
        ]

        # reference_global_vars

        price_vol_cat_vars = ['imbalance_buy_sell_flag', 'if_last5min', 'if_last2min', 'tick_up_down']

        stock_cat_vars = ['stock_id']

        date_num_vars = ['date_id', 'seconds_in_bucket', 'minute']

        cat_features = price_vol_cat_vars + stock_cat_vars + lag_cat_vars + diff_cat_vars

        vars_dict = {
            'orig_price_vol_num_vars': orig_price_vol_num_vars,
            'return_vars': return_vars,
            'diff_vars': diff_vars,
            'lag_vars': lag_vars,
            'lag_cat_vars': lag_cat_vars,
            'interactive_num_vars': interactive_num_vars,
            'derived_price_vol_num_vars': derived_price_vol_num_vars,
            'price_vol_cat_vars': price_vol_cat_vars,
            'stock_cat_vars': stock_cat_vars,
            'date_num_vars': date_num_vars,
            'reference_global_vars': reference_global_vars,
            'global_stock_id_vars': global_stock_id_vars,
            'diff_cat_vars': diff_cat_vars,
            'cat_features': cat_features
        }
        gc.collect()
        #         all_features = (
        #                 orig_price_vol_num_vars + return_vars + diff_vars + lag_vars + lag_cat_vars + interactive_num_vars + derived_price_vol_num_vars
        #                 + price_vol_cat_vars + stock_cat_vars + date_num_vars + reference_global_vars + global_stock_id_vars + diff_cat_vars)
        #         [col for col in df.columns if col not in all_features]: ['target', 'time_id']

        return df, vars_dict


    def calc_rolling_features(self, fea_df, roll_cols, rolling_window):

        df_new = fea_df.copy()
        group = df_new.groupby(['stock_id', 'date_id'], group_keys=False)

        with timer('Calculating rolling features with Multiprocessing: '):
            n_job = self.config.N_Jobs
            step = int(len(roll_cols) / n_job) + 1
            params = [roll_cols[i * step:(i + 1) * step] for i in range(n_job)]
            p = Parallel(n_jobs=-1)(delayed(write_rolling_features)(_param, group, rolling_window) for _param in params)
            for res in p:
                df, new_cols = res[0], res[1]
                df_new[new_cols] = df

        rolling_features = [col for col in df_new.columns if col not in fea_df.columns]
        del fea_df
        gc.collect()
        return df_new, rolling_features

    def calc_openFE_features(self, df0, col_list):
        df = df0.copy()
        openfe_num_vars, openfe_cat_vars = [], []
        for fea in col_list:
            try:
                df[fea] = df.eval(fea)
                openfe_num_vars += [fea]
            except:
                pass
        group = df.groupby(['date_id'], group_keys=False)
        df['openfe0'] = df[['matched_size', 'ask_size']].min(axis=1)
        df['openfe1'] = group['wap'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
        df['openfe2'] = df[['wap', 'wap_shift_2']].max(axis=1) - df[['reference_price', 'bid_price']].min(axis=1)
        df['openfe3'] = df['reference_price_shift_1'] - df[['reference_price', 'bid_price']].min(axis=1)
        df['openfe_cat0'] = df['tick_up_down'].astype(str) + df['seconds_in_bucket'].astype(str)
        df['openfe4'] = group['reference_price_shift_3'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
        df['openfe5'] = df[['imbalance_size', 'imbalance_size_shift_3']].min(axis=1)
        df['openfe6'] = group['far_price'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
        df['temp7'] = df[['wap', 'wap_shift_2']].max(axis=1)
        df['openfe7'] = group['temp7'].rolling(1000, 1).std(engine='numba', engine_kwargs={'nopython': True})
        df['openfe8'] = group['reference_price_shift_10'].rolling(1000, 1).min(engine='numba',
                                                                               engine_kwargs={'nopython': True})
        df['openfe9'] = df[['imbalance_size', 'imbalance_size_shift_3']].min(axis=1) / df[
            ['matched_size_shift_1', 'matched_size_shift_10']].max(axis=1)
        df['openfe10'] = np.sqrt(df[['matched_size', 'ask_size']].min(axis=1))
        df['openfe11'] = df[['ask_price', 'wap_shift_3']].max(axis=1)
        df['openfe12'] = np.sqrt(1 / (1 + np.exp(-df['wap_shift_10'])))
        df['openfe13'] = np.square(df['ask_price'])
        df['openfe14'] = df['bid_price_diff_3'] * df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis=1)
        df['openfe15'] = df['matched_size_shift_2'] - df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis=1)
        df['openfe16'] = group['wap'].rolling(1000, 1).mean(engine='numba', engine_kwargs={'nopython': True})
        df['openfe17'] = df[['far_price', 'ask_price_diff_3']].max(axis=1)
        df['openfe18'] = 1 / (1 + np.exp(-df['wap_shift_10']))
        df['openfe19'] = group['far_price'].rolling(1000, 1).median(engine='numba',
                                                                    engine_kwargs={'nopython': True}).droplevel(0)
        df['openfe20'] = group['matched_size_shift_10'].rolling(1000, 1).min(engine='numba',
                                                                             engine_kwargs={'nopython': True})
        df['openfe21'] = group['ask_price_diff_3'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
        df['openfe22'] = df['ask_size_diff_3'] + df[['imbalance_size', 'imbalance_size_shift_3']].min(axis=1)
        df['openfe23'] = df[['wap', 'wap_shift_2']].max(axis=1)
        df['openfe24'] = df[['wap_shift_1', 'wap_shift_2']].max(axis=1)
        df['openfe25'] = df['reference_price_shift_2'] + df[['ask_price', 'wap_shift_3']].max(axis=1)
        df['openfe26'] = df[['matched_size', 'imbalance_size']].max(axis=1)
        df['openfe27'] = df[['reference_price', 'bid_price']].min(axis=1)
        df['openfe28'] = df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis=1)
        df['openfe29'] = df['ask_price'] * df['openfe28']
        df['openfe30'] = 1 / (1 + np.exp(-df['reference_price'] / df['wap_shift_3']))
        df['openfe31'] = df[['ask_size_diff_10', 'bid_size_diff_10']].min(axis=1)
        df.drop(columns=['temp7'], inplace=True)
        openfe_num_vars += [f'openfe{i}' for i in range(32)]
        openfe_cat_vars += [f'openfe_cat{i}' for i in range(1)]
        return df, openfe_num_vars, openfe_cat_vars


    def calc_alpha_101_GTJA(self, df_train, max_lookback_window=6):
        dfs = {}
        for stock in sorted(df_train['stock_id'].unique()):
          df_temp = df_train.loc[df_train['stock_id']==stock].reset_index().drop(columns=['index', 'row_id'])#.set_index('time_id')
          df_temp['mid_price'] = (df_temp['bid_price'] + df_temp['ask_price']) / 2
          df_temp['open_price'] = df_temp.groupby("date_id")["wap"].transform(calc_open)
          df_temp['close'] = df_temp["wap"]
          df_temp['high'] = df_temp.groupby("date_id")["wap"].transform(calc_high)
          df_temp['low'] = df_temp.groupby("date_id")["wap"].transform(calc_low)
          df_temp['prev_close'] = df_temp.groupby("date_id")["wap"].transform(calc_prev_close)
          df_temp['volume_wgt'] = df_temp.groupby("date_id")["matched_size"].transform(calc_volume_weight)
          df_temp['avg_wap'] = df_temp.groupby("date_id")["wap"].transform(calc_avg_wap)
          df_temp['product'] = df_temp['volume_wgt'] * df_temp['avg_wap']
          df_temp['avg_price'] = df_temp.groupby("date_id")['product'].transform(lambda x: x.rolling(max_lookback_window, min_periods=1).sum()) / \
                              df_temp.groupby("date_id")['volume_wgt'].transform(lambda x: x.rolling(max_lookback_window, min_periods=1).sum())
          df_temp['amount'] = df_temp.groupby("date_id")["matched_size"].transform(calc_matched_size)
          df_temp['volume'] = df_temp['amount'] / df_temp['avg_price']
          dfs[stock] = df_temp

        gtja = GTJA_191(dfs)
        class_methods = [attr for attr in dir(GTJA_191) if callable(getattr(GTJA_191, attr)) and attr.startswith("alpha191")]
        features = {}
        for method in class_methods:
            print(method)
            df_temp_2 = getattr(gtja, method)()
            df_temp_2 = df_temp_2.stack().reset_index()
            df_temp_2.columns = ["time_id", "stock_id", method]
            df = df.merge(df_temp_2, on=["time_id", "stock_id"], how="left")
            #print(df.shape)

        calc_alpha101_feats(dfs)
        df_101 = pd.concat(dfs)
        duplicated_cols = list(set(df.columns).intersection(set(df_101.columns)))
        duplicated_cols.remove("time_id")
        duplicated_cols.remove("stock_id")
        df_101 = df_101.drop(columns=duplicated_cols)
        df = df.merge(df_101, on=["time_id", "stock_id"], how="left")
        gc.collect()
        return df


    def calc_other_feature(self, df):  #Ben
        erd = preproc(df, min_date_id=0)
        expressions = [
            "volume_usd = matched_size * wap ",
            "adv = Ts_Mean(volume_usd, 30)",
            "pv_1 = -Ts_Svd(wap, 60, 10, sid_did)",
            "pv_2 = -(wap - Ts_KalmanFilter(wap, sid_did))/ wap",
            "pv_3 = -Xs_Group_Neu(ask_price, gics4)",
            "pv_4 = -Xs_Group_Neu(wap, gics4)",
            "pv_5 = -Ts_Svd(ask_price, 60, 10, sid_did)",
            "pv_6 = -Ts_Svd(bid_price, 60, 10, sid_did)",
            "pv_7 = Xs_Group_Neu(pv_1, gics4)",
            "pv_8 = Delta(pv_4, 1)",
            "pv_9 = Xs_Group_Neu(pv_2, gics4 )",
            "pv_10 = Xs_Group_Neu(pv_3, gics4 )",
            "pv_11 = Delta(pv_1, 1)",
            "pv_12 = Xs_Group_Neu(pv_4, gics4 )",
            "pv_13 = Xs_HHI( -(bid_price - Ts_KalmanFilter(bid_price, sid_did))/ bid_price )",
            "pv_14 = Xs_Group_Neu(pv_5, gics4 )",
            "pv_15 = Xs_Group_Neu(pv_6, gics4 )",
            "pv_16 = Uncor(pv_2, pv_3 )",
            "pv_17 = Xs_Group_Neu(Delta(pv_4, 1), gics4)",
            "pv_18 = Xs_Group_Neu(Delta(pv_1, 1), gics4)",
            "pv_19 = Xs_Group_Neu(pv_13, gics4 ))",
            "pv_20 = Xs_Group_Neu(-Uncor(pv_2, pv_3 ), gics4)",
            "pv_21 = Xs_Group_Neu(Delta(pv_2, 1 ), gics4)",
            "pv_22 = Xs_Group_Neu(-Uncor(-(bid_price - Ts_KalmanFilter(bid_price, sid_did))/ bid_price, Xs_Group_Neu(bid_price, gics4)), gics4)",
        ]
        mrs = [f"pv_{i}" for i in range(1, 23)]
        erd, alphalist = quick_grammar(erd, expressions, [], "mr")

        expressions = [f"{a} = Xs_Norm(Xs_Group_Neu({a}, country))" for a in alphalist if
                       not a.startswith("Xs_Group_Neu")]
        erd, alphalist = quick_grammar(erd, expressions, alphalist, "mr")
        gc.collect()
        return erd


    def calc_other_features2(self, df):

        df['near_price_pred'] = df[['near_price', 'reference_price', 'bid_price', 'ask_price']].apply(
            lambda x: x[0] if ~np.isnan(x[0]) else x[1] if (x[1] > x[2] and x[1] < x[3]) else -99999 if (x[1] <= x[2]) else 99999, axis = 1)
        df['far_price_pred'] = df[['far_price', 'reference_price', 'bid_price', 'ask_price']].apply(
            lambda x: np.nan if ~np.isnan(x[0]) else x[1] if (x[1] > x[2] and x[1] < x[3]) else -99999 if (x[1] <= x[2]) else 99999, axis = 1)
        df['target_quantile'] = df['target'].apply( lambda x: 0 if x <= -100 else 5 - (-x // 20) if x < 0 else 6 + (x // 20) if x <= 100 else 11)
        df['target_remain'] = df[['target', 'target_quantile']].apply( lambda x: (x[1] - 5) * 20 - x[0] if x[1] <= 5 else x[0] - (x[1] - 6) * 20, axis=1)

        return df


    def fit_transform(self, df):

        # Fit transformers that require fitting, e.g. normalizer, one hot encoder etc.
        print('Fitting featurizers...')

        if self.config.USE_PRECOMPUTE_FEATURES:
            self.train_val_data = pd.read_feather(
                f'{self.config.MY_Path}/feature/basic_rolling_openfe_features.feather')  # contains target, time_id

        else:
            with timer('make basic feature'):  # (, 174)
                fea_basic_df, self.vars_dict = self.basic_feat_eng(df)
                fea_basic_df.to_feather(f'{self.config.MY_Path}/feature/basic_features.feather')

            with timer('calculating rollling feature'):  # +126
                temp = ['dispersion_diff', 'slope_ask', 'reference_price_bid_price_wap_imb7',
                        'reference_price_ask_price_wap_imb7', 'reference_price_bid_price_wap_imb9',
                        'reference_price_wap_imb']
                orig_price_vol_num_vars = [
                    'reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price', 'bid_price',
                    'bid_size', 'ask_price', 'ask_size', 'wap']
                additial_columns = orig_price_vol_num_vars + ['mid_price', 'swap_price', 'total_volume1',
                                                              'total_volume2', 'flow']
                roll_cols = list(set(temp + additial_columns))
                fea_rolling_df, rolling_features = self.calc_rolling_features(fea_basic_df, roll_cols, [6, 12])
                self.vars_dict['rolling_vars'] = rolling_features

                fea_rolling_df = reduce_mem_usage(
                    fea_rolling_df.convert_dtypes())  # change each columns from object to Float, Int
                fea_rolling_df.to_feather(f'{self.config.MY_Path}/feature/basic_rolling_features.feather')

            with timer('calculating OpenFE features'):  # +57
                openfe_df = pd.read_excel(f'{self.config.MY_Path}/params/openfe_features_selected.xlsx',
                                          sheet_name='merged').sort_values(by='score', ascending=False)
                col_list = openfe_df.features.to_list()
                fea_openfe_df, openfe_num_vars, openfe_cat_vars = self.calc_openFE_features(fea_rolling_df, col_list)
                self.vars_dict['openfe_num_vars'], self.vars_dict['openfe_cat_vars'] = openfe_num_vars, openfe_cat_vars
                self.vars_dict['cat_features'] += openfe_cat_vars
                fea_openfe_df = reduce_mem_usage(fea_openfe_df)

                del fea_basic_df, fea_rolling_df
                gc.collect()

            # with timer('calculate other features'):
            #     other_df = self.calc_other_feature(fea_openfe_df)
            #     del fea_openfe_df
            #     gc.collect()

            with timer('calculate other features 2'):
                other_df = self.calc_other_features2(fea_openfe_df)
                self.vars_dict['other_features2_num'] = ['near_price_pred', 'far_price_pred', 'target_quantile', 'target_remain']

            with timer('calculate Alpha101&GTJA features'):
                alpha_df = self.calc_alpha_101_GTJA(df)




            for col in self.vars_dict['cat_features']:
                self.train_val_data[col] = self.train_val_data[col].astype('category')
            self.train_val_data.to_feather(f'{self.config.MY_Path}/feature/basic_rolling_openfe_features.feather')

            joblib.dump(self.vars_dict, f'{self.config.MY_Path}/feature/vars_dict1.pkl')

        return self.train_val_data


    def preprocess(self, X, y=None):
        pass

    def transform(self, df):
        # Perform arbitary transformation
        print('Transforming Test Data...')

        with timer('Make Basic Features'):
            fea_basic_df, _ = self.basic_feat_eng(df)

        with timer('Make Rolling Features'):
            fea_rolling_df, _ = self.calc_rolling_features(fea_basic_df, self.roll_cols, [6, 12])

        with timer('make OpenFE Features'):
            fea_openfe_df, openfe_num_vars, openfe_cat_vars = self.calc_openFE_features(fea_rolling_df,
                                                                                        self.openfe_col_list)

        # with timer('Make Other Features'):
        #     other_df = self.calc_other_feature(fea_openfe_df)

        with timer('Make Other Features2'):
            other_df = self.calc_other_features2(fea_openfe_df)




        df = fea_openfe_df.copy()

        for col in self.vars_dict['cat_features']:
            df[col] = df[col].astype('category')

        del fea_basic_df, fea_rolling_df, fea_openfe_df
        gc.collect()
        return df


@contextmanager
def timer(name: str):
    s = time.time()
    yield
    elapsed = time.time() - s
    print(f'[{name}] {elapsed: .3f}sec')


def print_trace(name: str = ''):
    print(f'ERROR RAISED IN {name or "anonymous"}')
    print(traceback.format_exc())

"""
Read Train Data
"""
cfg = FEATURIZER_CFG()
train = pd.read_csv(r'train.csv') #(5237980, 17)
if cfg.DEBUG:
    train = train[train.stock_id<3].copy()
train = train.dropna(subset=['target']).reset_index(drop = True)
train = reduce_mem_usage(train)
train.info()
temp = train.groupby('date_id')['stock_id'].apply(lambda x: len(x.unique()))


"""
Check if the code is running in offline or online mode
"""

if cfg.Is_Offline:
    # In offline mode, split the data into training and validation sets based on the split_day
    df_train = train[train["date_id"] <= cfg.split_day]   #0-435
    df_test = train[train["date_id"] > cfg.split_day]    #436-480
    # Display a message indicating offline mode and the shapes of the training and validation sets
    print("Offline mode")
    print(f"train : {df_train.shape}, valid : {df_test.shape}")
else:
    # In online mode, use the entire dataset for training
    df_train = train
    # Display a message indicating online mode
    print("Online mode")
gc.collect()


featurizer = OptiverFeaturizer(FEATURIZER_CFG)
if cfg.Is_Train:
    if cfg.Is_Offline:
        df_train_feats = featurizer.fit_transform(df_train)
        print("Build Train Features Finished.")
        df_test_feats = featurizer.fit_transform(df_test)
        print("Build Valid Feats Finished.")
        df_valid_feats = reduce_mem_usage(df_test_feats)
    else:
        df_train_feats = featurizer.fit_transform(df_train)
        print("Build Online Train Feats Finished.")
    df_train_feats = reduce_mem_usage(df_train_feats)

"""
Model Build 
full_vars: Test MAE: 5.7251; full_vars+knn_vars+sample_weights: 5.7242, v5: 5.7168, v5 + filtered feature importance: 5.7181,
v7: Test MAE: 5.7073, v7+openfe: 5.7010
"""

"""
Offline mode: five fold CV to find the optimal parameters
"""


model_save_path = 'model'
if not os.path.exists(model_save_path):
    os.makedirs(model_save_path)

if cfg.Is_Offline:
    assert len(df_train_feats.date_id.unique())==436, \
        f"In offline mode, Train/Validation date_id not in [0, 435], max date_id is {max(df_train_feats.date_id)}"
    fold_set = {0: [0, 86], 1: [87, 173], 2: [174, 260], 3: [261, 347], 4: [348, 435]}
else: #online mode
    if not cfg.DEBUG:
        assert len(df_train_feats.date_id.unique()) == 481, \
            f"In Online mode, Train/Validation date_id not in [0, 480], max date_id is {max(df_train_feats.date_id)}"
    fold_set = {0: [0, 96], 1: [97, 193], 2: [194, 290], 3: [291, 387], 4: [388, 480]}

train_idx, validation_idx = [], []
for i in range(5):
    vmin, vmax = fold_set[i][0], fold_set[i][1]
    train_idx.append(df_train_feats.loc[(df_train_feats.date_id<vmin)|(df_train_feats.date_id>vmax)].index.to_list())
    validation_idx.append(df_train_feats.loc[(df_train_feats.date_id>=vmin)&(df_train_feats.date_id<=vmax)].index.to_list())
cv_fold = zip(train_idx, validation_idx)

vars_dict = featurizer.vars_dict
total_vars = (vars_dict['orig_price_vol_num_vars']
              + vars_dict['return_vars']
              + vars_dict['diff_vars']
              + vars_dict['lag_vars']
              + vars_dict['lag_cat_vars']
              + vars_dict['interactive_num_vars']
              + vars_dict['derived_price_vol_num_vars']
              + vars_dict['price_vol_cat_vars']
              + vars_dict['stock_cat_vars']
              + vars_dict['date_num_vars']
              + vars_dict['reference_global_vars']
              + vars_dict['global_stock_id_vars']
              + vars_dict['diff_cat_vars']
              + vars_dict['rolling_vars']
              + vars_dict['openfe_num_vars']
              + vars_dict['openfe_cat_vars'])

hyper_param0 = {'bagging_fraction': 0.98286014592707, 'feature_fraction': 0.444310836387477, 'lambda_l1': 0.0156252302416767,
         'lambda_l2': 0.06077603113532735, 'max_depth': 12, 'min_gain_to_split': 0.006515715387013565,
         'min_sum_hessian_in_leaf': 91.18902125462651, 'num_leaves': 236, 'objective': 'mae', 'learning_rate': 0.01,
         'extra_trees': True, 'metric': 'mae', 'bagging_freq': 1, 'n_estimators': 5000}

models, train_r2_ls, train_mae_ls, valid_mae_ls = [], [], [], []
metric_dict = defaultdict(dict)


if cfg.Is_Offline:
    pass
    #TODO: grid search + bayes opt get a set of hyperparameters, best_iters
else:
    #TODO: 调好参后online train不放validation data
    for model_id in range(5):
        train_indices, valid_indices = train_idx[model_id], validation_idx[model_id]
        df_fold_train = df_train_feats.loc[train_indices, total_vars]
        df_fold_train_target = df_train_feats['target'][train_indices]
        df_fold_valid = df_train_feats.loc[valid_indices, total_vars]
        df_fold_valid_target = df_train_feats['target'][valid_indices]
        train_weight = np.log(df_train_feats.loc[train_indices, 'time_id'] + 2)
        validation_weight = np.log(df_train_feats.loc[valid_indices, 'time_id'] + 2)
        print(f"Fold {model_id + 1} Model Training")
        gbm = lgb.LGBMRegressor(device='cpu', **hyper_param0)
        gbm.fit(df_fold_train, df_fold_train_target, sample_weight=train_weight,
                eval_set=[(df_fold_valid, df_fold_valid_target)], eval_sample_weight=[validation_weight],
                eval_metric='mae', callbacks=[log_evaluation(period=100), early_stopping(stopping_rounds=100)])

        pred_train_y = gbm.predict(df_fold_train)
        assert np.sum(np.isnan(np.array(pred_train_y))) == 0, f"Error: There are some None values in predictions!"
        train_r2 = np.corrcoef(np.array(df_fold_train_target), np.array(pred_train_y))[0][1]
        train_mae = mean_absolute_error(df_fold_train_target, pred_train_y)
        valid_mae = mean_absolute_error(df_fold_valid_target, gbm.predict(df_fold_valid))
        print('Model ID: %d Finished. train r2: %.2f, train MAE: %.2f, valid MAE: %.2f ' % (model_id, train_r2, train_mae, valid_mae))
        metric_dict['fold%d' % (model_id)]['train_r2'] = train_r2
        metric_dict['fold%d' % (model_id)]['train_mae'] = train_mae
        metric_dict['fold%d' % (model_id)]['valid_mae'] = valid_mae
        train_r2_ls.append(train_r2)
        train_mae_ls.append(train_mae)
        valid_mae_ls.append(valid_mae)
        models.append(gbm)
        del df_fold_train, df_fold_train_target, df_fold_valid, df_fold_valid_target
        gc.collect()
    print(f"Average MAE across all folds: {np.mean(valid_mae_ls)}")
    md = {'model': models, 'train_r2': train_r2_ls, 'train_mae': train_mae_ls}
    joblib.dump(md, f"{model_save_path}/lgb_online_5fold")

