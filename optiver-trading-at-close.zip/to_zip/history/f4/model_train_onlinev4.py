import warnings
import pandas as pd
import numpy as np
import lightgbm as lgb  #3.3.3
import gc
import joblib  #1.3.1
import os
import logging
import time
import multiprocessing
import traceback

from typing import Union, Any
from sklearn.metrics import mean_absolute_error
from itertools import combinations
from lightgbm import log_evaluation, early_stopping
from warnings import simplefilter
from joblib import Parallel, delayed
from numba import njit, prange
from contextlib import contextmanager
from sklearn.base import BaseEstimator, TransformerMixin

warnings.filterwarnings("ignore")
simplefilter(action="ignore", category=pd.errors.PerformanceWarning)


is_offline = False
is_train = True
is_infer = True
split_day = 435
debug = False
N_Jobs = min(multiprocessing.cpu_count(), 32)
is_special_purged_cv = False
feature_id = 4
"""
add v4 Alpha 101 & GTJA features, add techinical features. 
"""

df = pd.read_csv("train.csv")
df = df.dropna(subset=["target"])
df.reset_index(drop=True, inplace=True)
df_shape = df.shape


def setup_logger(path,name='logging'):
    path_ = '%s/' %(path)
    if not os.path.exists(path_): os.makedirs(path_)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    fhlr = logging.FileHandler(path_ +f'/{name}.log')
    fhlr.setFormatter(formatter)
    chlr = logging.StreamHandler()
    chlr.setFormatter(formatter)
    logger.addHandler(chlr)
    logger.addHandler(fhlr)
    return logger,path_

logger_path = 'log'
if not os.path.exists(logger_path):
    os.makedirs(logger_path)
logger, logger_path = setup_logger(logger_path, name=f"IsOffline_{is_offline}_FeatureId_{feature_id}")
lgb.register_logger(logger)

@contextmanager
def timer(name: str):
    s = time.time()
    yield
    elapsed = time.time() - s
    print(f'[{name}] {elapsed: .3f}sec')


def reduce_mem_usage(df):

    for col in df.columns:
        col_type = df[col].dtype
        if (col_type != object) and (col_type != 'category'):
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == "int":
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float32)
                elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float32)
    return df


@njit(parallel=True)
def compute_triplet_imbalance(df_values, comb_indices):
    num_rows = df_values.shape[0]
    num_combinations = len(comb_indices)
    imbalance_features = np.empty((num_rows, num_combinations))
    for i in prange(num_combinations):
        a, b, c = comb_indices[i]
        for j in range(num_rows):
            max_val = max(df_values[j, a], df_values[j, b], df_values[j, c])
            min_val = min(df_values[j, a], df_values[j, b], df_values[j, c])
            mid_val = df_values[j, a] + df_values[j, b] + df_values[j, c] - min_val - max_val
            if mid_val == min_val:
                imbalance_features[j, i] = np.nan
            else:
                imbalance_features[j, i] = max(min((max_val - mid_val) / (mid_val - min_val), 1e4), -1e4)   #add clip
    return imbalance_features


@njit
def ma(arr: np.ndarray, window: int, min_periods: int = 1) -> np.ndarray:
    result = np.full(arr.shape, np.nan)  # Fill with nan
    if min_periods is None:
        min_periods = window
    for i in prange(arr.shape[0]):
        windowed_data = arr[max(0, i - window + 1) : i + 1]
        valid_count = np.sum(~np.isnan(windowed_data))
        if valid_count >= min_periods:
            result[i] = np.nanmean(windowed_data)  # Compute mean considering possible NaN values
    return result


def calc_ma(x, lookback=6):
    '''
    已经验证完全一致
    df['temp2'] = df.groupby(['date_id', 'stock_id'], group_keys=False)['wap'].apply(lambda x: calc_ma(x, 10))
    df['temp1'] = df.groupby(['date_id', 'stock_id'], group_keys=False)['wap'].rolling(10, 1).mean().droplevel([0, 1])
    '''
    x2 = x.to_numpy()
    return pd.Series(ma(x2, lookback), index=x.index)


@njit
def nanstd(arr: np.ndarray, window: int, min_periods: int = 1) -> np.ndarray:
    result = np.full(arr.shape, np.nan)  # Fill with nan
    if min_periods is None:
        min_periods = window
    for i in prange(arr.shape[0]):
        windowed_data = arr[max(0, i - window + 1) : i + 1]
        valid_count = np.sum(~np.isnan(windowed_data))
        if valid_count >= min_periods:
            result[i] = np.nanstd(windowed_data)  # Compute mean considering possible NaN values
    return result


def calc_nanstd(x, lookback = 6):
    x2 = x.to_numpy()
    return pd.Series(nanstd(x2, lookback), index=x.index)


@njit
def realized_volatility(arr: np.ndarray, window: int, min_periods: int = 1)-> np.ndarray:
    result = np.full(arr.shape, np.nan)  # Fill with nan
    if min_periods is None:
        min_periods = window
    for i in prange(arr.shape[0]):
        windowed_data = arr[max(0, i - window + 1) : i + 1]
        valid_count = np.sum(~np.isnan(windowed_data))
        if valid_count >= min_periods:
            result[i] = np.sqrt(np.nanmean(windowed_data**2))
    return result


def calc_realized_vol(x, lookback = 6):
    x2 = x.to_numpy()
    return pd.Series(realized_volatility(x2, lookback), index=x.index)


def calculate_triplet_imbalance_numba(price, df):
    df_values = df[price].values
    comb_indices = [(price.index(a), price.index(b), price.index(c)) for a, b, c in combinations(price, 3)]
    features_array = compute_triplet_imbalance(df_values, comb_indices)
    columns = [f"{a}_{b}_{c}_imb2" for a, b, c in combinations(price, 3)]
    features = pd.DataFrame(features_array, columns=columns)
    return features


def imbalance_features(df):
    # Define lists of price and size-related column names
    prices = ["reference_price", "far_price", "near_price", "ask_price", "bid_price", "wap"]
    sizes = ["matched_size", "bid_size", "ask_size", "imbalance_size"]
    df["volume"] = df['ask_size'] + df['bid_size']
    df["matched_imbalance"] = (df['imbalance_size'] - df['matched_size']) / (df['matched_size'] + df['imbalance_size'])
    df["size_imbalance"] = df['bid_size']/df['ask_size']

    for c in combinations(prices, 2):
        if c not in [('near_price', 'ask_price'), ('ask_price', 'bid_price'), ('near_price', 'bid_price'), ('far_price', 'ask_price'),
                     ('far_price', 'bid_price'), ('reference_price', 'near_price'), ('reference_price', 'far_price')]:
            df[f"{c[0]}_{c[1]}_imb"] = df.eval(f"({c[0]} - {c[1]})/({c[0]} + {c[1]})")

    for c in [['ask_price', 'bid_price', 'wap', 'reference_price'], sizes]:
        triplet_feature = calculate_triplet_imbalance_numba(c, df)
        df[triplet_feature.columns] = triplet_feature.values

    #v3 features
    df["stock_weights"] = df["stock_id"].map(weights)
    df["weighted_wap"] = df["stock_weights"] * df["wap"]
    df['wap_momentum'] = df.groupby('stock_id')['weighted_wap'].pct_change(periods=6)

    df["imbalance_momentum"] = df.groupby(['stock_id'])['imbalance_size'].diff(periods=1) / df['matched_size']
    df["price_spread"] = df["ask_price"] - df["bid_price"]
    df["spread_intensity"] = df.groupby(['stock_id'])['price_spread'].diff()
    df['price_pressure'] = df['imbalance_size'] * (df['ask_price'] - df['bid_price'])
    df['market_urgency'] = df['price_spread'] * (df['bid_size'] - df['ask_size']) / (df['bid_size'] + df['ask_size'])
    df['depth_pressure'] = (df['ask_size'] - df['bid_size']) * (df['far_price'] - df['near_price'])
    df['slope_ask'] = df['ask_size'] / (df["volume"] / 2 + 1)
    df['swap_price'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / df["volume"]

    #v3 features
    df['spread_depth_ratio'] = (df['ask_price'] - df['bid_price']) / (df['bid_size'] + df['ask_size'])
    df['mid_price_movement'] = ((df['ask_price'] + df['bid_price']) / 2).diff(periods=5).apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
    df['relative_spread'] = (df['ask_price'] - df['bid_price']) / df['wap']

    # Calculate various statistical aggregation features
    for func in ["std", "skew", "kurt"]:
        if func not in ['std']:
            df[f"all_prices_{func}"] = df[prices].agg(func, axis=1)
        df[f"all_sizes_{func}"] = df[sizes].agg(func, axis=1)

    for col in ['matched_size', 'imbalance_size', 'reference_price']:
        for window in [1, 3, 5, 10]:
            if (col, window) not in [('matched_size', 1)]:
                df[f"{col}_shift_{window}"] = df.groupby('stock_id')[col].shift(window)
            df[f"{col}_ret_{window}"] = df.groupby('stock_id')[col].pct_change(window).clip(-1e4, 1e4)

    # Calculate diff features for specific columns
    for col in ['ask_price', 'bid_price', 'ask_size', 'bid_size', 'market_urgency', 'imbalance_momentum','size_imbalance',
                'weighted_wap', 'price_spread']:
        for window in [1, 3, 5, 10]:
            if (col, window) not in [('price_spread', 1)]:
                df[f"{col}_diff_{window}"] = df.groupby("stock_id")[col].diff(window)


    for col in ['imbalance_buy_sell_flag']:
        for window in [1, 3, 5, 10]:
            df[f"{col}_shift_{window}"] = df.groupby("stock_id")[col].shift(window)  # 0,1
            df[f"{col}_diff_{window}"] = df.groupby("stock_id")[col].diff(window)

    # v3 features
    for window in [3,5,10]:
        df[f'size_change_diff_{window}'] = df[f'bid_size_diff_{window}'] - df[f'ask_size_diff_{window}']
    df['mid_price*volume'] = df['mid_price_movement'] * df['volume']
    df['harmonic_imbalance'] = df.eval('2 / ((1 / bid_size) + (1 / ask_size))')

    df.drop(columns=['stock_weights', 'price_spread'
    ], inplace=True)
    return df


def other_features(df):
    df["seconds"] = df["seconds_in_bucket"] % 60
    df["minute"] = df["seconds_in_bucket"] // 60
    for key, value in global_stock_id_feats.items():
        df[f"global_{key}"] = df["stock_id"].map(value.to_dict())
    return df


def generate_rolling_features(roll_cols, group, rolling_window):
    df = pd.DataFrame()
    new_cols = []
    for col in roll_cols:
        for window in rolling_window:
            print(f"{col}, {window}")
            if (col, window) not in [('wap', 5), ('bid_price', 3), ('bid_price', 5), ('ask_price', 5), ('bid_price', 10), ('ask_price', 3)]:
                df[f"{col}_roll{window}_mean"] = group[col].apply(lambda x: calc_ma(x, window))
                new_cols += [f"{col}_roll{window}_mean"]
            df[f"{col}_roll{window}_nanstd"] = group[col].apply(lambda x: calc_nanstd(x, window))
            new_cols += [ f"{col}_roll{window}_nanstd"]
    return df, new_cols


def generate_rolling_vol_features(roll_cols, group, rolling_window):
    df = pd.DataFrame()
    new_cols = []
    for col in roll_cols:
        for window in rolling_window:
            print(f"{col}, {window}")
            df[f"{col}_roll{window}_realizedvol"] = group[col].apply(lambda x: calc_realized_vol(x, window))
            new_cols += [f"{col}_roll{window}_realizedvol"]
    return df, new_cols


def calc_rolling_features_parallel(df):
    group = df.groupby(['stock_id', 'date_id'], group_keys=False)
    step = int(len(roll_mean_std_cols) / N_Jobs) + 1
    params = [roll_mean_std_cols[i * step:(i + 1) * step] for i in range(N_Jobs)]
    p = Parallel(n_jobs=N_Jobs)(delayed(generate_rolling_features)(_param, group, windows) for _param in params)
    for res in p:
        df_part, new_cols = res[0], res[1]
        df[new_cols] = df_part
    gc.collect()
    step_v = int(len(roll_vol_cols) / N_Jobs) + 1
    params = [roll_vol_cols[i * step_v:(i + 1) * step_v] for i in range(N_Jobs)]
    pv = Parallel(n_jobs=N_Jobs)(delayed(generate_rolling_vol_features)(_param, group, windows) for _param in params)
    for res in pv:
        df_part, new_cols = res[0], res[1]
        df[new_cols] = df_part
    gc.collect()
    return df


def generate_all_features(df):
    # Select relevant columns for feature generation
    cols = [c for c in df.columns if c not in ["row_id", "target", "time_id"]]
    df = df[cols]

    df = imbalance_features(df)
    df = other_features(df)
    df = calc_rolling_features_parallel(df)
    df = alpha101_featurizer.fit_transform(df)

    gc.collect()
    feature_name = [i for i in df.columns if i not in ["row_id", "target", "time_id", "date_id"]]
    cat_features = ['stock_id']
    for col in cat_features:
        df[col] = df[col].astype('category')
    return df[feature_name]


def RANK(data: pd.DataFrame):
    """
    :param data: index : timestamp, columns: stock id
    :return: 所有股票在截面上排序
    """
    return data.rank(axis=1, pct=True)


def IFELSE(condition: pd.DataFrame, A: Union[pd.DataFrame, Any], B: Union[pd.DataFrame, Any]):
    """
    条件选择
    """
    if isinstance(A, pd.DataFrame):
        na_map = A.isna().astype(float).replace(1., np.nan)
        return A.where(condition, B) + na_map
    elif isinstance(B, pd.DataFrame):
        na_map = B.isna().astype(float).replace(1., np.nan)
        return B.where(~condition, A) + na_map
    else:
        raise ValueError("A, B 必须有一个是DataFrame")


def DECAYLINEAR(data: pd.DataFrame, n: int):
    """
    线性衰减移动平均加权
    """
    weight = np.array([2 * i / (n * (n + 1)) for i in range(1, n + 1)])
    idx = data.index
    col = data.columns
    return pd.DataFrame(_wma(data.values, weight), index=idx, columns=col)


def DELTA(A: pd.DataFrame, n: int):
    return A.diff(n)


def DELAY(A: pd.DataFrame, n: int):
    return A.shift(n)


def SUM(A: pd.DataFrame, n: int):
    return A.rolling(n).sum()


def MEAN(price: pd.DataFrame, N: int):
    """
    滚动平均
    """
    return price.rolling(N, min_periods=1).mean()


def CORR(A: pd.DataFrame, B: pd.DataFrame, n: int):
    return A.rolling(n, min_periods=2).corr(B)


def MAX(A: pd.DataFrame, B):
    """
    两个序列的最大值
    """
    return np.maximum(A, B)


def TS_MAX(A: pd.DataFrame, N: int):
    """
    N日内最大值
    """
    return A.rolling(N, min_periods=1).max()


def TS_RANK(data: pd.DataFrame, N: int):
    """
    滚动排名
    """
    return data.rolling(N, min_periods=1).rank(pct=True)


def _wma(A_arr: np.ndarray, weight: np.ndarray):
    """
    其中A的每一列对应B的每一列
    A_arr: (N, L)
    B_arr: (N, L)
    """
    N, L = A_arr.shape
    n = weight.shape[0]
    result = np.zeros((N, L))
    result[:n] = np.nan
    for rolling_ind in range(n - 1, A_arr.shape[0]):
        bch_x = A_arr[rolling_ind - n + 1: rolling_ind + 1, :]
        for col_ind in range(L):
            x = bch_x[:, col_ind]
            if np.all(np.isnan(x)):
                result[rolling_ind, col_ind] = np.nan
            else:
                result[rolling_ind, col_ind] = np.nansum(x * weight)
    return result

max_lookback_window = 6


def calc_open(x, n=max_lookback_window):
  ret = x.shift(n-1)
  ret[:n] = x.iloc[0]
  return ret.values


def calc_close(x):
  return x


def calc_high(x, n=max_lookback_window):
  return x.rolling(n, min_periods=1).max().values


def calc_low(x, n=max_lookback_window):
  return x.rolling(n, min_periods=1).min().values


def calc_matched_size(x, n=max_lookback_window):
  ret = x.diff(n)
  ret[:n] = x[:n] - x.iloc[0]
  ret = np.maximum(ret, 0) * 100 + 1
  return ret.values


def calc_volume_weight(x):
    matched_size = x.diff().values
    matched_size[0] = 0
    matched_size = np.maximum(matched_size, 0) * 100 + 1
    return matched_size


def calc_avg_wap(x):
    avg_wap = (x + x.shift(1)) / 2
    avg_wap.iloc[0] = x.iloc[0]
    return avg_wap


def calc_return(x, n=max_lookback_window):
  ret = x / x.shift(n)
  ret[:n] = x[:n] / x.iloc[0]
  return ret.values


def calc_prev_close(x, n=max_lookback_window):
    ret = x.shift(n)
    ret[:n] = x.iloc[0]
    return ret

max_lookback_window_101 = 6

def calc_open_101(x, n=max_lookback_window_101):
  ret = x.shift(n-1)
  ret[:n] = x.iloc[0]
  return ret.values


def calc_close_101(x):
  return x


def calc_high_101(x, n=max_lookback_window_101):
  return x.rolling(n, min_periods=1).max().values


def calc_low_101(x, n=max_lookback_window_101):
  return x.rolling(n, min_periods=1).min().values


def calc_return_101(x, n=max_lookback_window_101):
  ret = x / x.shift(n)
  ret[:n] = x[:n] / x.iloc[0]
  return ret.values


def calc_matched_size_101(x, n=max_lookback_window_101):
  ret = x.diff(n)
  ret[:n] = x[:n] - x.iloc[0]
  ret = np.maximum(ret, 0) * 100 + 1
  return ret.values


def calc_volume_weight_101(x):
    matched_size = x.diff()
    matched_size.iloc[0] = 0
    matched_size = np.maximum(matched_size, 0) * 100 + 1
    return matched_size


def calc_avg_wap_101(x):
    avg_wap = (x + x.shift(1)) / 2
    avg_wap.iloc[0] = x.iloc[0]
    return avg_wap


def ts_min(df, window=10):
    """
    Wrapper function to estimate rolling min.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series min over the past 'window' days.
    """
    return df.rolling(window).min()


def ts_max(df, window=10):
    """
    Wrapper function to estimate rolling min.
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: a pandas DataFrame with the time-series max over the past 'window' days.
    """
    return df.rolling(window).max()


def delta(df, period=1):
    """
    Wrapper function to estimate difference.
    :param df: a pandas DataFrame.
    :param period: the difference grade.
    :return: a pandas DataFrame with today’s value minus the value 'period' days ago.
    """
    return df.diff(period)


def delay(df, period=1):
    """
    Wrapper function to estimate lag.
    :param df: a pandas DataFrame.
    :param period: the lag grade.
    :return: a pandas DataFrame with lagged time series
    """
    return df.shift(period)



def ts_argmax(df, window=10):
    """
    Wrapper function to estimate which day ts_max(df, window) occurred on
    :param df: a pandas DataFrame.
    :param window: the rolling window.
    :return: well.. that :)
    """
    return df.rolling(window).apply(np.argmax) + 1



def decay_linear(df, period=10):
    """
    Linear weighted moving average implementation.
    :param df: a pandas DataFrame.
    :param period: the LWMA period
    :return: a pandas DataFrame with the LWMA.
    """
    # Clean data
    if df.isnull().values.any():
        df.fillna(method='ffill', inplace=True)
        df.fillna(method='bfill', inplace=True)
        df.fillna(value=0, inplace=True)
    na_lwma = np.zeros_like(df)
    na_lwma[:period, :] = df.iloc[:period, :]
    na_series = df.to_numpy()

    divisor = period * (period + 1) / 2
    y = (np.arange(period) + 1) * 1.0 / divisor
    # Estimate the actual lwma with the actual close.
    # The backtest engine should assure to be snooping bias free.
    for row in range(period - 1, df.shape[0]):
        x = na_series[row - period + 1: row + 1, :]
        na_lwma[row, :] = (np.dot(x.T, y))
    return pd.DataFrame(na_lwma, index=df.index, columns=['CLOSE'])


class GTJA_191:
    def __init__(self, dfs):
        self.open_price = pd.concat([df['open_price'] for df in dfs.values()], axis=1)
        self.open_price.columns = dfs.keys()
        self.close      = pd.concat([df['close'] for df in dfs.values()], axis=1)
        self.close.columns = dfs.keys()
        self.low        = pd.concat([df['low'] for df in dfs.values()], axis=1)
        self.low.columns = dfs.keys()
        self.high       = pd.concat([df['high'] for df in dfs.values()], axis=1)
        self.high.columns = dfs.keys()
        self.vwap  = pd.concat([df['avg_price'] for df in dfs.values()], axis=1)
        self.vwap.columns = dfs.keys()
        self.prev_close = pd.concat([df['prev_close'] for df in dfs.values()], axis=1)
        self.prev_close.columns = dfs.keys()
        self.volume     = pd.concat([df['volume'] for df in dfs.values()], axis=1)
        self.volume.columns = dfs.keys()
        self.amount     = pd.concat([df['amount'] for df in dfs.values()], axis=1)
        self.amount.columns = dfs.keys()
        #########################################################################


    def alpha191_007(self, period=3):
        """
        ((RANK(MAX((VWAP - CLOSE), 3)) + RANK(MIN((VWAP - CLOSE), 3))) * RANK(DELTA(VOLUME, 3)))
        -->
        [RANK(MAX(VWAP - CLOSE, 3)) + RANK(MIN(VWAP - CLOSE, 3))] * RANK(DELTA(VOLUME, 3))
        """
        rkmax = (self.vwap - self.close).rolling(period, min_periods=1).max().rank(axis=1, pct=True)
        rkmin = (self.vwap - self.close).rolling(period, min_periods=1).min().rank(axis=1, pct=True)
        rkdelta = self.volume.diff(periods=period).rank(axis=1, pct=True)
        alpha = (rkmax + rkmin) * rkdelta
        return alpha

    def alpha191_039(self):
        """
        (
            RANK(DECAYLINEAR(DELTA((CLOSE), 2), 8)) - RANK(DECAYLINEAR(CORR(((VWAP * 0.3) + (OPEN * 0.7)), SUM(MEAN(VOLUME, 180), 37), 14), 12))
        ) * -1
        @res:
        """
        alpha = RANK(DECAYLINEAR(DELTA(self.close, 2), 8))
        alpha -= RANK(DECAYLINEAR(CORR((self.vwap * 0.3 + self.open_price * 0.7),
                                       SUM(MEAN(self.volume, 180), 37), 14), 12))
        return -1 * alpha

    def alpha191_048(self, use_vwap=False):
        """
        -1 * (
            (
                RANK(
                    (
                        SIGN((CLOSE - DELAY(CLOSE, 1))) + SIGN((DELAY(CLOSE, 1) - DELAY(CLOSE, 2))) + SIGN((DELAY(CLOSE, 2) - DELAY(CLOSE, 3)))
                    )
                )
            ) * SUM(VOLUME, 5)
        ) / SUM(VOLUME, 20)
        @res:
        """
        _p = self.vwap if use_vwap else self.close
        alpha = np.sign(_p.diff(1)) + \
                np.sign(_p.shift(1).diff(1)) + \
                np.sign(_p.shift(2).diff(1))
        alpha = alpha.rank(axis=1, pct=True) * self.volume.rolling(5, min_periods=1).sum() / self.volume.rolling(20, min_periods=1).sum()
        return alpha


    def alpha191_066(self, period=6, use_vwap=False):
        """
        (CLOSE-MEAN(CLOSE,6))/MEAN(CLOSE,6)*100
        @res:
        """
        _p = self.vwap if use_vwap else self.close
        alpha = (_p - MEAN(_p, period)) / MEAN(_p, period) * 100
        return alpha

    def alpha191_091(self, vol_period=40, corr_period=5, use_vwap=False):
        """
        (
            RANK((CLOSE - MAX(CLOSE, 5))) *
            RANK(CORR(MEAN(VOLUME, 40), LOW, 5))
        ) * -1
        @res:
        @NOTE:
            MAX(CLOSE, 5) ???
        """
        _p = self.vwap if use_vwap else self.close
        alpha = RANK(_p - TS_MAX(_p, 5)) * \
                RANK(CORR(MEAN(self.volume, vol_period), self.low, corr_period)) * -1
        return alpha

    def alpha191_092(self, decay_period1=3, decay_period2=5, rank_period=15):
        """
        MAX(
            RANK(DECAYLINEAR(DELTA(((CLOSE * 0.35) + (VWAP * 0.65)), 2), 3)),
            TSRANK(DECAYLINEAR(ABS(CORR((MEAN(VOLUME, 180)), CLOSE, 13)), 5), 15)
        ) * -1
        @res:
        """
        alpha = MAX(
            RANK(DECAYLINEAR(DELTA((self.close * 0.35 + self.vwap * 0.65), 2), decay_period1)),
            TS_RANK(DECAYLINEAR(np.abs(CORR(MEAN(self.volume, 180), self.close, 13)), decay_period2), rank_period)
        ) * -1
        return alpha

    def alpha191_120(self):
        """
        (RANK((VWAP - CLOSE)) / RANK((VWAP + CLOSE)))
        @res:
        """
        alpha = RANK(self.vwap - self.close) / RANK(self.vwap + self.close)
        return alpha

    def alpha191_137(self, use_vwap=False):
        """
        condition1 = abshc > abslc;
        condition2 = abshc > abshl;
        condition3 = abslc > abshc;
        abshc = ABS(HIGH - DELAY(CLOSE, 1));
        abslc = ABS(LOW - DELAY(CLOSE, 1));
        absco = ABS(DELAY(CLOSE, 1) - DELAY(OPEN, 1));
        abshl = ABS(HIGH - DELAY(LOW, 1));
        16 * (CLOSE - DELAY(CLOSE, 1) + (CLOSE - OPEN) / 2 + DELAY(CLOSE, 1) - DELAY(OPEN, 1)) /
        ((condition1 & condition2 ? abshc + abslc / 2 + absco / 4 : (abslc > abshl & condition3 ? abslc + abshc / 2 + absco / 4 : abshl + absco / 4)))
        * MAX(abshc, abslc)
        @res:
        """
        _p = self.vwap if use_vwap else self.close
        abshc = np.abs(self.high - DELAY(_p, 1))
        abslc = np.abs(self.low - DELAY(_p, 1))
        absco = np.abs(DELAY(_p, 1) - DELAY(self.open_price, 1))
        abshl = np.abs(self.high - DELAY(self.low, 1))
        alpha = 16 * (_p - DELAY(_p, 1) + (_p - self.open_price) / 2 +
                      DELAY(_p, 1) - DELAY(self.open_price, 1))
        alpha = alpha / (IFELSE((abshc > abslc) * (abshc > abshl), abshc + abslc / 2 + absco / 4,
                                IFELSE((abslc > abshl) * (abslc > abshc),
                                       abslc + abshc / 2 + absco / 4, abshl + absco / 4)) + 1e-7)
        alpha = alpha * MAX(abshc, abslc)
        return alpha

    def alpha191_142(self):
        """
        (((-1 * RANK(TSRANK(CLOSE, 10))) * RANK(DELTA(DELTA(CLOSE, 1), 1))) * RANK(TSRANK((VOLUME
        /MEAN(VOLUME,20)), 5)))
        @res:
        """
        alpha = (((-1 * RANK(TS_RANK(self.close, 10))) * RANK(DELTA(DELTA(self.close, 1), 1))) *
                 RANK(TS_RANK((self.volume / MEAN(self.volume, 20)), 5)))
        return alpha

    def alpha191_163(self, period=20):
        """
        RANK(((((-1 * RET) * MEAN(VOLUME,20)) * VWAP) * (HIGH - CLOSE)))
        @res:
        """
        ret = self.close / self.close.shift(1) - 1
        alpha = RANK(((((-1 * ret) * MEAN(self.volume, period)) * self.vwap) * (self.high - self.close)))
        return alpha

    def alpha191_171(self):
        """
        ((-1 * ((LOW - CLOSE) * (OPEN^5))) / ((CLOSE - HIGH) * (CLOSE^5)))
        @res:
        """
        alpha = (-1 * ((self.low - self.close) * (self.open_price ** 5))) / \
                ((self.close - self.high + 1e-7) * (self.close ** 5))
        return alpha

    def alpha191_184(self):
        """
        (RANK(CORR(DELAY((OPEN - CLOSE), 1), CLOSE, 200)) + RANK((OPEN - CLOSE)))
        @res:
        """
        alpha = RANK(CORR(DELAY((self.open_price - self.close), 1), self.close, 200)) + \
                RANK((self.open_price - self.close))
        return alpha


class Alphas(object):
    def __init__(self, df_data):

        self.open = df_data.groupby("date_id")["wap"].transform(calc_open_101)
        self.close = df_data.groupby("date_id")["wap"].transform(calc_close_101)
        self.high = df_data.groupby("date_id")["wap"].transform(calc_high_101)
        self.low = df_data.groupby("date_id")["wap"].transform(calc_low_101)
        self.returns = df_data.groupby("date_id")["wap"].transform(calc_return_101)
        df_data['volume_wgt'] = df_data.groupby("date_id")["matched_size"].transform(calc_volume_weight_101)
        df_data['avg_wap'] = df_data.groupby("date_id")["wap"].transform(calc_avg_wap_101)
        df_data['product'] = df_data['volume_wgt'] * df_data['avg_wap']
        df_data['vwap'] = df_data.groupby("date_id")['product'].transform(lambda x: x.rolling(max_lookback_window_101, min_periods=1).sum()) / \
                            df_data.groupby("date_id")['volume_wgt'].transform(lambda x: x.rolling(max_lookback_window_101, min_periods=1).sum())
        self.vwap = df_data['vwap']
        self.volume = df_data.groupby("date_id")["matched_size"].transform(calc_matched_size_101) / self.vwap

    # Alpha#9	 ((0 < ts_min(delta(close, 1), 5)) ? delta(close, 1) : ((ts_max(delta(close, 1), 5) < 0) ?delta(close, 1) : (-1 * delta(close, 1))))
    def alpha009(self):
        delta_close = delta(self.close, 1)
        cond_1 = ts_min(delta_close, 5) > 0
        cond_2 = ts_max(delta_close, 5) < 0
        alpha = -1 * delta_close
        alpha[cond_1 | cond_2] = delta_close
        return alpha


    # Alpha#49	 (((((delay(close, 20) - delay(close, 10)) / 10) - ((delay(close, 10) - close) / 10)) < (-1 *0.1)) ? 1 : ((-1 * 1) * (close - delay(close, 1))))
    def alpha049(self):
        inner = (((delay(self.close, 20) - delay(self.close, 10)) / 10) - ((delay(self.close, 10) - self.close) / 10))
        alpha = (-1 * delta(self.close))
        alpha[inner < -0.1] = 1
        return alpha


    # Alpha#54	 ((-1 * ((low - close) * (open^5))) / ((low - high) * (close^5)))
    def alpha054(self):
        inner = (self.low - self.high).replace(0, -0.0001)
        return -1 * (self.low - self.close) * (self.open ** 5) / (inner * (self.close ** 5))


    # Alpha#101	 ((close - open) / ((high - low) + .001))
    def alpha101(self):
        return (self.close - self.open) /((self.high - self.low) + 0.001)


def get_alpha(df, stock_id):  #get_alpha每个factor用的都是单只股票时序上的信息，不涉及其他股票

    stock=Alphas(df)
    df['alpha009']=stock.alpha009()
    df['alpha049']=stock.alpha049()
    df['alpha054']=stock.alpha054()
    df['alpha101']=stock.alpha101()
    return df, stock_id

def calc_alpha101_feats(dfs):
    logger.info('Calculate Alpha 101 Features.')
    stock_list = list(dfs.keys())
    p = Parallel(n_jobs=N_Jobs)(delayed(get_alpha)(dfs[k], k) for k in stock_list)
    for res in p:
        dfs[res[1]] = res[0]


class Alpha101_Featurizer(BaseEstimator, TransformerMixin):
    def __init__(self, config=None):
        # configurations
        self.config = config

    def alpha101_feat_eng(self, df):
        dfs = {}
        def prepare_alpha101_data(stock):
            print(f'Stock ID: {stock}')
            df_temp = df.loc[df['stock_id'] == stock].set_index(['date_id', 'seconds_in_bucket'])
            df_temp['mid_price'] = (df_temp['bid_price'] + df_temp['ask_price']) / 2
            df_temp['open_price'] = df_temp.groupby("date_id")["wap"].transform(calc_open)
            df_temp['close'] = df_temp["wap"]
            df_temp['high'] = df_temp.groupby("date_id")["wap"].transform(calc_high)
            df_temp['low'] = df_temp.groupby("date_id")["wap"].transform(calc_low)
            df_temp['prev_close'] = df_temp.groupby("date_id")["wap"].transform(calc_prev_close)
            df_temp['volume_wgt'] = df_temp.groupby("date_id")["matched_size"].transform(calc_volume_weight)
            df_temp['avg_wap'] = df_temp.groupby("date_id")["wap"].transform(calc_avg_wap)
            df_temp['product'] = df_temp['volume_wgt'] * df_temp['avg_wap']
            df_temp['avg_price'] = df_temp.groupby("date_id")['product'].transform(
                lambda x: x.rolling(max_lookback_window, min_periods=1).sum()) / \
                                   df_temp.groupby("date_id")['volume_wgt'].transform(
                                       lambda x: x.rolling(max_lookback_window, min_periods=1).sum())
            df_temp['amount'] = df_temp.groupby("date_id")["matched_size"].transform(calc_matched_size)
            df_temp['volume'] = df_temp['amount'] / df_temp['avg_price']
            return stock, df_temp

        p = Parallel(n_jobs=N_Jobs)(delayed(prepare_alpha101_data)(stock) for stock in sorted(df['stock_id'].unique()))
        for res in p:
            dfs[res[0]] = res[1]

        gtja = GTJA_191(dfs)
        class_methods = [attr for attr in dir(GTJA_191) if callable(getattr(GTJA_191, attr)) and attr.startswith("alpha191")]
        for method in class_methods:
            logger.info(method)
            df_temp_2 = getattr(gtja, method)()
            df_temp_2 = df_temp_2.stack().reset_index()
            df_temp_2.columns = ["date_id", "seconds_in_bucket", 'stock_id', method]
            df = df.merge(df_temp_2, on=["date_id", "seconds_in_bucket", "stock_id"], how="left")

        calc_alpha101_feats(dfs)
        df_101 = pd.concat(dfs).reset_index()
        df_101 = df_101[['stock_id', 'date_id', 'seconds_in_bucket', 'alpha009', 'alpha049', 'alpha054', 'alpha101']]
        df = df.merge(df_101, on=["stock_id",  'date_id', 'seconds_in_bucket'], how="left")
        gc.collect()

        return df


    def fit_transform(self, df):
        # Fit transformers that require fitting, e.g. normalizer, one hot encoder etc.
        logger.info('Fitting Alpha 101 featurizers...')
        fea_df = self.alpha101_feat_eng(df)
        return fea_df


if is_offline:
    if debug:
        df_train = df[(df["date_id"] <= split_day)&(df['stock_id']<3)]
        df_test = df[(df["date_id"] > split_day)&(df['stock_id']<3)]
    else:
        df_train = df[df["date_id"] <= split_day]
        df_test = df[df["date_id"] > split_day]
    logger.info("Offline mode")
    logger.info(f"train : {df_train.shape}, valid : {df_test.shape}")
else:
    df_train = df
    logger.info("Online mode")


roll_mean_std_cols = ['market_urgency', 'slope_ask', 'bid_price', 'bid_size', 'ask_price', 'ask_size', 'wap']
for window in [3,5,10]:
    for col in ['ask_price', 'bid_price', 'ask_size', 'bid_size']:
        roll_mean_std_cols += [f"{col}_diff_{window}"]

roll_vol_cols = ['reference_price_ret_1', 'reference_price_ret_3', 'reference_price_ret_5', 'reference_price_ret_10']
windows = [3,5,10]


weights = [
    0.004, 0.001, 0.002, 0.006, 0.004, 0.004, 0.002, 0.006, 0.006, 0.002, 0.002, 0.008,
    0.006, 0.002, 0.008, 0.006, 0.002, 0.006, 0.004, 0.002, 0.004, 0.001, 0.006, 0.004,
    0.002, 0.002, 0.004, 0.002, 0.004, 0.004, 0.001, 0.001, 0.002, 0.002, 0.006, 0.004,
    0.004, 0.004, 0.006, 0.002, 0.002, 0.04 , 0.002, 0.002, 0.004, 0.04 , 0.002, 0.001,
    0.006, 0.004, 0.004, 0.006, 0.001, 0.004, 0.004, 0.002, 0.006, 0.004, 0.006, 0.004,
    0.006, 0.004, 0.002, 0.001, 0.002, 0.004, 0.002, 0.008, 0.004, 0.004, 0.002, 0.004,
    0.006, 0.002, 0.004, 0.004, 0.002, 0.004, 0.004, 0.004, 0.001, 0.002, 0.002, 0.008,
    0.02 , 0.004, 0.006, 0.002, 0.02 , 0.002, 0.002, 0.006, 0.004, 0.002, 0.001, 0.02,
    0.006, 0.001, 0.002, 0.004, 0.001, 0.002, 0.006, 0.006, 0.004, 0.006, 0.001, 0.002,
    0.004, 0.006, 0.006, 0.001, 0.04 , 0.006, 0.002, 0.004, 0.002, 0.002, 0.006, 0.002,
    0.002, 0.004, 0.006, 0.006, 0.002, 0.002, 0.008, 0.006, 0.004, 0.002, 0.006, 0.002,
    0.004, 0.006, 0.002, 0.004, 0.001, 0.004, 0.002, 0.004, 0.008, 0.006, 0.008, 0.002,
    0.004, 0.002, 0.001, 0.004, 0.004, 0.004, 0.006, 0.008, 0.004, 0.001, 0.001, 0.002,
    0.006, 0.004, 0.001, 0.002, 0.006, 0.004, 0.006, 0.008, 0.002, 0.002, 0.004, 0.002,
    0.04 , 0.002, 0.002, 0.004, 0.002, 0.002, 0.006, 0.02 , 0.004, 0.002, 0.006, 0.02,
    0.001, 0.002, 0.006, 0.004, 0.006, 0.004, 0.004, 0.004, 0.004, 0.002, 0.004, 0.04,
    0.002, 0.008, 0.002, 0.004, 0.001, 0.004, 0.006, 0.004,
]
weights = {int(k):v for k,v in enumerate(weights)}

alpha101_featurizer = Alpha101_Featurizer()

if is_train:
    global_stock_id_feats = {
        "median_size": df_train.groupby("stock_id")["bid_size"].median() + df_train.groupby("stock_id")["ask_size"].median(),
        "std_size": df_train.groupby("stock_id")["bid_size"].std() + df_train.groupby("stock_id")["ask_size"].std(),
        "ptp_size": df_train.groupby("stock_id")["bid_size"].max() - df_train.groupby("stock_id")["bid_size"].min(),
        "median_price": df_train.groupby("stock_id")["bid_price"].median() + df_train.groupby("stock_id")["ask_price"].median(),
        "std_price": df_train.groupby("stock_id")["bid_price"].std() + df_train.groupby("stock_id")["ask_price"].std(),
        "ptp_price": df_train.groupby("stock_id")["bid_price"].max() - df_train.groupby("stock_id")["ask_price"].min(),
    }
    if is_offline:
        df_train_feats = generate_all_features(df_train)
        logger.info("Build Train Feats Finished.")
        df_test_feats = generate_all_features(df_test)
        logger.info("Build Test Feats Finished.")
        # df_test_feats = reduce_mem_usage(df_test_feats)
    else:
        df_train_feats = generate_all_features(df_train)
        logger.info("Build Online Train Feats Finished.")
    # df_train_feats = reduce_mem_usage(df_train_feats)


lgb_params = {
    "objective": "mae",
    "n_estimators": 6000,
    "num_leaves": 256,
    "subsample": 0.6,
    "colsample_bytree": 0.8,
    "learning_rate": 0.01,
    'max_depth': 11,
    "n_jobs": -1,
    "device": "gpu",
    "verbosity": -1,
    "importance_type": "gain",
}


feature_save_path = 'feature'
if not os.path.exists(feature_save_path):
    os.makedirs(feature_save_path)
feature_name = list(df_train_feats.columns)
logger.info(f"Feature length = {len(feature_name)}")
joblib.dump(feature_name, f"{feature_save_path}/feats_name_{feature_id}")


num_folds = 5
if is_offline:
    fold_size = 435 // num_folds
else:
    fold_size = 480 // num_folds
gap = 5
models = []

model_save_path = 'model_from_start'
if not os.path.exists(model_save_path):
    os.makedirs(model_save_path)

date_ids = df_train['date_id'].values

#normal 5 fold CV
if not is_special_purged_cv:
    if is_offline:
        fold_set = {0: [0, 86], 1: [87, 173], 2: [174, 260], 3: [261, 347], 4: [348, 435]}
    else: #online mode
        if not debug:
            fold_set = {0: [0, 96], 1: [97, 193], 2: [194, 290], 3: [291, 387], 4: [388, 480]}

    train_idx, validation_idx = [], []
    for i in range(5):
        vmin, vmax = fold_set[i][0], fold_set[i][1]
        train_idx.append(df_train_feats.loc[(date_ids<vmin)|(date_ids>vmax)].index.to_list())
        validation_idx.append(df_train_feats.loc[(date_ids>=vmin)&(date_ids<=vmax)].index.to_list())
    cv_fold = zip(train_idx, validation_idx)

models, train_r2_ls, train_mae_ls, valid_mae_ls, test_mae_ls= [], [], [], [], []


for model_id in [3,4]:

    if not is_special_purged_cv: #normal 5 fold cv
        train_indices, valid_indices = train_idx[model_id], validation_idx[model_id]
    else: #special purged cv
        start = model_id * fold_size
        end = start + fold_size
        if model_id < num_folds - 1:  # No need to purge after the last fold
            purged_start = end - 2
            purged_end = end + gap + 2
            train_indices = (date_ids >= start) & (date_ids < purged_start) | (date_ids > purged_end)
        else:
            train_indices = (date_ids >= start) & (date_ids < end)
        valid_indices = (date_ids >= end) & (date_ids < end + fold_size)
        gc.collect()

    df_fold_train = df_train_feats.loc[train_indices, feature_name]
    df_fold_train_target = df_train['target'][train_indices]
    df_fold_valid = df_train_feats.loc[valid_indices, feature_name]
    df_fold_valid_target = df_train['target'][valid_indices]
    train_weight = np.log(df_train.loc[train_indices, 'time_id'] + 2)
    validation_weight = np.log(df_train.loc[valid_indices, 'time_id'] + 2)

    logger.info(f"Fold {model_id} Model Training")
    extra_params = {'random_seed':[1, 42, 60, 66, 80, 128], 'learning_rate': [0.01, 0.015, 0.015, 0.015, 0.015, 0.02]}
    i = 0
    while i < 6:
        logger.info(f"i: {i}")
        try:
            lgb_params['random_seed'], lgb_params['learning_rate'] = extra_params['random_seed'][i], extra_params['learning_rate'][i]
            gbm = lgb.LGBMRegressor(**lgb_params)
            gbm.fit(df_fold_train, df_fold_train_target, sample_weight=train_weight,
                    eval_set=[(df_fold_valid, df_fold_valid_target)], eval_sample_weight=[validation_weight],
                    eval_metric='mae', callbacks=[log_evaluation(period=100), early_stopping(stopping_rounds=100)])
            break
        except Exception as e:
            logger.info('模型训练报错：' + str(e))
            logger.info('traceback.format_exc(): \n%s' % (traceback.format_exc()))
            i += 1
            continue
    if i == 6: #try 6 times all fail.
        continue
    pred_train_y = gbm.predict(df_fold_train)
    train_r2 = np.corrcoef(np.array(df_fold_train_target), np.array(pred_train_y))[0][1]
    train_mae = mean_absolute_error(df_fold_train_target, pred_train_y)
    valid_mae = mean_absolute_error(df_fold_valid_target, gbm.predict(df_fold_valid))
    if is_offline:
        test_mae = mean_absolute_error(df_test.target, gbm.predict(df_test_feats))
        test_mae_ls.append(test_mae)
    logger.info('Model ID: %d Finished. train r2: %.2f, train MAE: %.2f, valid MAE: %.2f ' % (model_id, train_r2, train_mae, valid_mae))
    one_fold_md = {'model': gbm, 'train_r2': train_r2, 'train_mae': train_mae, 'valie_mae': valid_mae}
    joblib.dump(one_fold_md, f"{model_save_path}/lgb_IsOffline_{is_offline}_featureID_{feature_id}_modelID_{model_id}")
    train_r2_ls.append(train_r2)
    train_mae_ls.append(train_mae)
    valid_mae_ls.append(valid_mae)
    models.append(gbm)
    del df_fold_train, df_fold_train_target, df_fold_valid, df_fold_valid_target
    gc.collect()

iters = [929, 1145, 1797]
iters += [model.best_iteration_ for model in models]
average_best_iteration = int(np.mean(iters))
final_model_params = lgb_params.copy()
final_model_params['n_estimators'] = average_best_iteration
logger.info(f"Training final model with average best iteration: {average_best_iteration}")
final_model = lgb.LGBMRegressor(**final_model_params)
final_model.fit(
    df_train_feats[feature_name],
    df_train['target'],
    callbacks=[
        lgb.callback.log_evaluation(period=100),
    ],
)
models.append(final_model)
pred_train_y = final_model.predict(df_train_feats[feature_name])
train_r2 = np.corrcoef(np.array(df_train['target']), np.array(pred_train_y))[0][1]
train_mae = mean_absolute_error(df_train['target'], pred_train_y)
train_r2_ls.append(train_r2)
train_mae_ls.append(train_mae)
if is_offline:
    test_mae = mean_absolute_error(df_test.target, final_model.predict(df_test_feats))
    test_mae_ls.append(test_mae)
logger.info(f"Offline: {is_offline}. Average Validation MAE across all folds: {np.mean(valid_mae_ls)}")
if is_offline:
    logger.info(f"Offline: {is_offline}. Average Test MAE across all folds: {np.mean(test_mae_ls)}")
if not is_offline:
    md = {'model': models, 'train_r2': train_r2_ls, 'train_mae': train_mae_ls, 'valie_mae': valid_mae_ls}
    joblib.dump(md, f"{model_save_path}/lgb_featureID_{feature_id}_5fold")