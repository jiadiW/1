import warnings
import pandas as pd
import numpy as np
import lightgbm as lgb  #3.3.3
import gc
import joblib  #1.3.1
import os
import logging
import time
import multiprocessing
import traceback

from sklearn.metrics import mean_absolute_error
from itertools import combinations
from lightgbm import log_evaluation, early_stopping
from warnings import simplefilter
from joblib import Parallel, delayed
from numba import njit, prange
from contextlib import contextmanager

warnings.filterwarnings("ignore")
simplefilter(action="ignore", category=pd.errors.PerformanceWarning)


is_offline = True
is_train = True
is_infer = True
split_day = 435
debug = False
N_Jobs = min(multiprocessing.cpu_count(), 16)
feature_id = '2.1' #add rolling mean

df = pd.read_csv("train.csv")
df = df.dropna(subset=["target"])
df.reset_index(drop=True, inplace=True)
df_shape = df.shape


def setup_logger(path,name='logging'):
    path_ = '%s/' %(path)
    if not os.path.exists(path_): os.makedirs(path_)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    fhlr = logging.FileHandler(path_ +f'/{name}.log')
    fhlr.setFormatter(formatter)
    chlr = logging.StreamHandler()
    chlr.setFormatter(formatter)
    logger.addHandler(chlr)
    logger.addHandler(fhlr)
    return logger,path_

logger_path = 'log'
if not os.path.exists(logger_path):
    os.makedirs(logger_path)
logger, logger_path = setup_logger(logger_path, name=f"IsOffline_{is_offline}_FeatureId_{feature_id}")
lgb.register_logger(logger)

@contextmanager
def timer(name: str):
    s = time.time()
    yield
    elapsed = time.time() - s
    print(f'[{name}] {elapsed: .3f}sec')


def reduce_mem_usage(df):

    for col in df.columns:
        col_type = df[col].dtype
        if (col_type != object) and (col_type != 'category'):
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == "int":
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float32)
                elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float32)
    return df


@njit(parallel=True)
def compute_triplet_imbalance(df_values, comb_indices):
    num_rows = df_values.shape[0]
    num_combinations = len(comb_indices)
    imbalance_features = np.empty((num_rows, num_combinations))
    for i in prange(num_combinations):
        a, b, c = comb_indices[i]
        for j in range(num_rows):
            max_val = max(df_values[j, a], df_values[j, b], df_values[j, c])
            min_val = min(df_values[j, a], df_values[j, b], df_values[j, c])
            mid_val = df_values[j, a] + df_values[j, b] + df_values[j, c] - min_val - max_val
            if mid_val == min_val:
                imbalance_features[j, i] = np.nan
            else:
                # imbalance_features[j, i] = max(min((max_val - mid_val) / (mid_val - min_val), 1e4), -1e4)   #add clip
                imbalance_features[j, i] = (max_val - mid_val) / (mid_val - min_val)
    return imbalance_features


@njit
def ma(arr: np.ndarray, window: int, min_periods: int = 1) -> np.ndarray:
    result = np.full(arr.shape, np.nan)  # Fill with nan
    if min_periods is None:
        min_periods = window
    for i in prange(arr.shape[0]):
        windowed_data = arr[max(0, i - window + 1) : i + 1]
        valid_count = np.sum(~np.isnan(windowed_data))
        if valid_count >= min_periods:
            result[i] = np.nanmean(windowed_data)  # Compute mean considering possible NaN values
    return result


def calc_ma(x, lookback=6):
    '''
    已经验证完全一致
    df['temp2'] = df.groupby(['date_id', 'stock_id'], group_keys=False)['wap'].apply(lambda x: calc_ma(x, 10))
    df['temp1'] = df.groupby(['date_id', 'stock_id'], group_keys=False)['wap'].rolling(10, 1).mean().droplevel([0, 1])
    '''
    x2 = x.to_numpy()
    return pd.Series(ma(x2, lookback), index=x.index)


@njit
def nanstd(arr: np.ndarray, window: int, min_periods: int = 1) -> np.ndarray:
    result = np.full(arr.shape, np.nan)  # Fill with nan
    if min_periods is None:
        min_periods = window
    for i in prange(arr.shape[0]):
        windowed_data = arr[max(0, i - window + 1) : i + 1]
        valid_count = np.sum(~np.isnan(windowed_data))
        if valid_count >= min_periods:
            result[i] = np.nanstd(windowed_data)  # Compute mean considering possible NaN values
    return result


def calc_nanstd(x, lookback = 6):
    x2 = x.to_numpy()
    return pd.Series(nanstd(x2, lookback), index=x.index)


@njit
def realized_volatility(arr: np.ndarray, window: int, min_periods: int = 1)-> np.ndarray:
    result = np.full(arr.shape, np.nan)  # Fill with nan
    if min_periods is None:
        min_periods = window
    for i in prange(arr.shape[0]):
        windowed_data = arr[max(0, i - window + 1) : i + 1]
        valid_count = np.sum(~np.isnan(windowed_data))
        if valid_count >= min_periods:
            result[i] = np.sqrt(np.nanmean(windowed_data**2))
    return result


def calc_realized_vol(x, lookback = 6):
    x2 = x.to_numpy()
    return pd.Series(realized_volatility(x2, lookback), index=x.index)


def calculate_triplet_imbalance_numba(price, df):
    df_values = df[price].values
    comb_indices = [(price.index(a), price.index(b), price.index(c)) for a, b, c in combinations(price, 3)]
    features_array = compute_triplet_imbalance(df_values, comb_indices)
    columns = [f"{a}_{b}_{c}_imb2" for a, b, c in combinations(price, 3)]
    features = pd.DataFrame(features_array, columns=columns)
    return features


def imbalance_features(df):
    # Define lists of price and size-related column names
    prices = ["reference_price", "far_price", "near_price", "ask_price", "bid_price", "wap"]
    sizes = ["matched_size", "bid_size", "ask_size", "imbalance_size"]
    df["volume"] = df['ask_size'] + df['bid_size']
    df["mid_price"] = (df['ask_price'] + df['bid_price']) / 2
    df["liquidity_imbalance"] = (df['bid_size'] - df['ask_size']) / (df['bid_size'] + df['ask_size'])
    df["matched_imbalance"] = (df['imbalance_size'] - df['matched_size']) / (df['matched_size'] + df['imbalance_size'])
    df["size_imbalance"] = df['bid_size']/df['ask_size']

    for c in combinations(prices, 2):
        df[f"{c[0]}_{c[1]}_imb"] = df.eval(f"({c[0]} - {c[1]})/({c[0]} + {c[1]})")

    for c in [['ask_price', 'bid_price', 'wap', 'reference_price'], sizes]:
        triplet_feature = calculate_triplet_imbalance_numba(c, df)
        df[triplet_feature.columns] = triplet_feature.values

    df["imbalance_momentum"] = df.groupby(['stock_id'])['imbalance_size'].diff(periods=1) / df['matched_size']
    df["price_spread"] = df["ask_price"] - df["bid_price"]
    df["spread_intensity"] = df.groupby(['stock_id'])['price_spread'].diff()
    df['price_pressure'] = df['imbalance_size'] * (df['ask_price'] - df['bid_price'])
    df['market_urgency'] = df['price_spread'] * df['liquidity_imbalance']
    df['depth_pressure'] = (df['ask_size'] - df['bid_size']) * (df['far_price'] - df['near_price'])
    df['bid_wap'] = ((df['wap'] - df['bid_price']) / df['wap']).clip(1e-6, )
    df['ask_wap'] = ((df['ask_price'] - df['wap']) / df['wap']).clip(1e-6, )
    df['dispersion_diff'] = df['bid_wap'] - df['ask_wap']
    df['slope_ask'] = df['ask_size'] / (df["volume"] / 2 + 1)
    df['swap_price'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / df["volume"]

    # Calculate various statistical aggregation features
    for func in ["mean", "std", "skew", "kurt"]:
        df[f"all_prices_{func}"] = df[prices].agg(func, axis=1)
        df[f"all_sizes_{func}"] = df[sizes].agg(func, axis=1)

    for col in ['matched_size', 'imbalance_size', 'reference_price']:
        for window in [1, 2, 3, 10]:
            df[f"{col}_shift_{window}"] = df.groupby('stock_id')[col].shift(window)
            df[f"{col}_ret_{window}"] = df.groupby('stock_id')[col].pct_change(window)      #.clip(-1e4, 1e4)

    # Calculate diff features for specific columns
    for col in ['ask_price', 'bid_price', 'ask_size', 'bid_size', 'market_urgency', 'imbalance_momentum','size_imbalance']:
        for window in [1, 2, 3, 10]:
            df[f"{col}_diff_{window}"] = df.groupby("stock_id")[col].diff(window)

    df['imbalance_buy_sell_flag'] = df.imbalance_buy_sell_flag.apply(lambda x: 0 if x == -1 else 1)  # 0,1
    for col in ['imbalance_buy_sell_flag']:
        for window in [1, 2, 3, 10]:
            df[f"{col}_shift_{window}"] = df.groupby("stock_id")[col].shift(window)  # 0,1
            df[f"{col}_diff_{window}"] = df.groupby("stock_id")[col].diff(window).apply(lambda x: 2 if x == -1 else x)  # 0,1,2
    df.drop(columns=[
        'bid_wap', 'ask_wap',
    ], inplace=True)
    return df.replace([np.inf, -np.inf], np.nan)


def other_features(df):
    df["seconds"] = df["seconds_in_bucket"] % 60
    df["minute"] = df["seconds_in_bucket"] // 60
    for key, value in global_stock_id_feats.items():
        df[f"global_{key}"] = df["stock_id"].map(value.to_dict())
    return df


def generate_rolling_features(roll_cols, group, rolling_window):
    df = pd.DataFrame()
    new_cols = []
    for col in roll_cols:
        for window in rolling_window:
            print(f"{col}, {window}")
            df[f"{col}_roll{window}_mean"] = group[col].apply(lambda x: calc_ma(x, window))
            # df[f"{col}_roll{window}_nanstd"] = group[col].apply(lambda x: calc_nanstd(x, window))
            # df[f"{col}_roll{window}_realizedvol"] = group[col].apply(lambda x: calc_realized_vol(x, window))
            # new_cols+=[f"{col}_roll{window}_mean", f"{col}_roll{window}_nanstd", f"{col}_roll{window}_realizedvol"]
            new_cols += [f"{col}_roll{window}_mean"]
    return df, new_cols


def calc_rolling_features_parallel(df):
    group = df.groupby(['stock_id', 'date_id'], group_keys=False)
    step = int(len(roll_cols) / N_Jobs) + 1
    params = [roll_cols[i * step:(i + 1) * step] for i in range(N_Jobs)]
    p = Parallel(n_jobs=N_Jobs)(delayed(generate_rolling_features)(_param, group, windows) for _param in params)
    for res in p:
        df_part, new_cols = res[0], res[1]
        df[new_cols] = df_part
    gc.collect()
    return df


def generate_all_features(df):
    # Select relevant columns for feature generation
    cols = [c for c in df.columns if c not in ["row_id", "time_id", "target"]]
    df = df[cols]

    df = imbalance_features(df)
    df = other_features(df)
    df = calc_rolling_features_parallel(df)

    gc.collect()
    feature_name = [i for i in df.columns if i not in ["row_id", "target", "time_id", "date_id"]]
    cat_features = ['stock_id'] + [fea for fea in feature_name if fea.startswith('imbalance_buy_sell_flag')]
    for col in cat_features:
        df[col] = df[col].astype('category')
    return df[feature_name]


if is_offline:
    df_train = df[df["date_id"] <= split_day]
    df_test = df[df["date_id"] > split_day]
    logger.info("Offline mode")
    logger.info(f"train : {df_train.shape}, valid : {df_test.shape}")
else:
    df_train = df
    logger.info("Online mode")


roll_cols = [
    'dispersion_diff', 'slope_ask', 'reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price',
    'bid_price', 'bid_size', 'ask_price', 'ask_size', 'wap', 'swap_price']
windows = [6, 12]


if is_train:
    global_stock_id_feats = {
        "median_size": df_train.groupby("stock_id")["bid_size"].median() + df_train.groupby("stock_id")["ask_size"].median(),
        "std_size": df_train.groupby("stock_id")["bid_size"].std() + df_train.groupby("stock_id")["ask_size"].std(),
        "ptp_size": df_train.groupby("stock_id")["bid_size"].max() - df_train.groupby("stock_id")["bid_size"].min(),
        "median_price": df_train.groupby("stock_id")["bid_price"].median() + df_train.groupby("stock_id")["ask_price"].median(),
        "std_price": df_train.groupby("stock_id")["bid_price"].std() + df_train.groupby("stock_id")["ask_price"].std(),
        "ptp_price": df_train.groupby("stock_id")["bid_price"].max() - df_train.groupby("stock_id")["ask_price"].min(),
    }
    if is_offline:
        df_train_feats = generate_all_features(df_train)
        logger.info("Build Train Feats Finished.")
        df_test_feats = generate_all_features(df_test)
        logger.info("Build Test Feats Finished.")
        df_test_feats = reduce_mem_usage(df_test_feats)
    else:
        df_train_feats = generate_all_features(df_train)
        logger.info("Build Online Train Feats Finished.")
    df_train_feats = reduce_mem_usage(df_train_feats)


lgb_params = {
    "objective": "mae",
    "n_estimators": 6000,
    "num_leaves": 256,
    "subsample": 0.6,
    "colsample_bytree": 0.8,
    "learning_rate": 0.01,
    'max_depth': 11,
    "n_jobs": -1,
    "device": "gpu",
    "verbosity": -1,
    "importance_type": "gain",
}
feature_name = list(df_train_feats.columns)
logger.info(f"Feature length = {len(feature_name)}")

num_folds = 5
fold_size = 480 // num_folds
models = []

model_save_path = 'model_from_start'
if not os.path.exists(model_save_path):
    os.makedirs(model_save_path)

date_ids = df_train['date_id'].values
if is_offline:
    fold_set = {0: [0, 86], 1: [87, 173], 2: [174, 260], 3: [261, 347], 4: [348, 435]}
else: #online mode
    if not debug:
        fold_set = {0: [0, 96], 1: [97, 193], 2: [194, 290], 3: [291, 387], 4: [388, 480]}

train_idx, validation_idx = [], []
for i in range(5):
    vmin, vmax = fold_set[i][0], fold_set[i][1]
    train_idx.append(df_train_feats.loc[(date_ids<vmin)|(date_ids>vmax)].index.to_list())
    validation_idx.append(df_train_feats.loc[(date_ids>=vmin)&(date_ids<=vmax)].index.to_list())
cv_fold = zip(train_idx, validation_idx)

models, train_r2_ls, train_mae_ls, valid_mae_ls, test_mae_ls= [], [], [], [], []


for model_id in range(5):
    train_indices, valid_indices = train_idx[model_id], validation_idx[model_id]
    df_fold_train = df_train_feats.loc[train_indices, feature_name]
    df_fold_train_target = df_train['target'][train_indices]
    df_fold_valid = df_train_feats.loc[valid_indices, feature_name]
    df_fold_valid_target = df_train['target'][valid_indices]
    train_weight = np.log(df_train.loc[train_indices, 'time_id'] + 2)
    validation_weight = np.log(df_train.loc[valid_indices, 'time_id'] + 2)
    logger.info(f"Fold {model_id + 1} Model Training")
    extra_params = {'random_seed':[1, 42, 60, 66, 80, 128], 'learning_rate': [0.01, 0.015, 0.015, 0.015, 0.015, 0.02]}
    i = 0
    while i < 6:
        logger.info(f"i: {i}")
        try:
            lgb_params['random_seed'], lgb_params['learning_rate'] = extra_params['random_seed'][i], extra_params['learning_rate'][i]
            gbm = lgb.LGBMRegressor(**lgb_params)
            gbm.fit(df_fold_train, df_fold_train_target, sample_weight=train_weight,
                    eval_set=[(df_fold_valid, df_fold_valid_target)], eval_sample_weight=[validation_weight],
                    eval_metric='mae', callbacks=[log_evaluation(period=100), early_stopping(stopping_rounds=100)])
            break
        except Exception as e:
            logger.info('模型训练报错：' + str(e))
            logger.info('traceback.format_exc(): \n%s' % (traceback.format_exc()))
            i += 1
            continue
    if i == 6: #try 6 times all fail.
        continue
    pred_train_y = gbm.predict(df_fold_train)
    train_r2 = np.corrcoef(np.array(df_fold_train_target), np.array(pred_train_y))[0][1]
    train_mae = mean_absolute_error(df_fold_train_target, pred_train_y)
    valid_mae = mean_absolute_error(df_fold_valid_target, gbm.predict(df_fold_valid))
    if is_offline:
        test_mae = mean_absolute_error(df_test.target, gbm.predict(df_test_feats))
        test_mae_ls.append(test_mae)
    logger.info('Model ID: %d Finished. train r2: %.2f, train MAE: %.2f, valid MAE: %.2f ' % (model_id, train_r2, train_mae, valid_mae))

    train_r2_ls.append(train_r2)
    train_mae_ls.append(train_mae)
    valid_mae_ls.append(valid_mae)
    models.append(gbm)
    del df_fold_train, df_fold_train_target, df_fold_valid, df_fold_valid_target
    gc.collect()
logger.info(f"Offline: {is_offline}. Average Validation MAE across all folds: {np.mean(valid_mae_ls)}")
if is_offline:
    logger.info(f"Offline: {is_offline}. Average Test MAE across all folds: {np.mean(test_mae_ls)}")
md = {'model': models, 'train_r2': train_r2_ls, 'train_mae': train_mae_ls, 'valie_mae': valid_mae_ls}
if not is_offline:
    joblib.dump(md, f"{model_save_path}/lgb_featureID_{feature_id}_5fold")