import pandas as pd
import numpy as np
import lightgbm as lgb
import seaborn as sns
import gc
import plotly.express as px
import warnings
import datetime
import matplotlib.pyplot as plt
import sys
import pickle
import json
import joblib
import scipy
import time
import traceback
import bottleneck as bn
import multiprocessing

from openfe import OpenFE, tree_to_formula, transform
from sklearn.feature_selection import RFE
from joblib import Parallel, delayed
from numpy.lib import pad
from numba import jit, njit
from numpy.lib.stride_tricks import as_strided
from os import path, walk, getpid
from psutil import Process
from contextlib import contextmanager
from itertools import combinations
from itertools import groupby
from collections import defaultdict
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from pandas import Timestamp
from sklearn.metrics import mean_absolute_error
from lightgbm import log_evaluation, early_stopping
# from bayes_opt import BayesianOptimization
from typing import Dict, List, Optional, Tuple
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import minmax_scale
from warnings import simplefilter
from sklearn.base import BaseEstimator, TransformerMixin
simplefilter(action="ignore", category=pd.errors.PerformanceWarning)


def train_val_test_split(df):
  '''
  train: date_id: 0-360
  validation: date_id: 361-420
  test: date_id: 421-480
  '''
  df = df.sort_values(by=['date_id', 'seconds_in_bucket', 'stock_id'])
  train = df.loc[df.date_id <=360, :].copy()
  validation = df.loc[(df.date_id>360)&(df.date_id<=420)].copy()
  test = df.loc[df.date_id>420].copy()
  return train.index.to_list(), validation.index.to_list(), test.index.to_list()


@contextmanager
def timer(name: str):
    s = time.time()
    yield
    elapsed = time.time() - s
    print(f'[{name}] {elapsed: .3f}sec')



def calc_openFE_features(df0, col_list):
    df = df0.copy()
    openfe_num_vars, openfe_cat_vars = [], []
    for fea in col_list:
        try:
            df[fea] = df.eval(fea)
            openfe_num_vars += [fea]
        except:
            pass

    group =  df.groupby(['date_id'], group_keys=False)
    df['openfe0'] = df[['matched_size', 'ask_size']].min(axis = 1)
    df['openfe1'] = group['wap'].rolling(1000, 1).rank(ascending=True, pct=True, engine='numba',engine_kwargs={'nopython': True}).droplevel(0)
    df['openfe2'] = df[['wap', 'wap_shift_2']].max(axis = 1) - df[['reference_price', 'bid_price']].min(axis = 1)
    df['openfe3'] = df['reference_price_shift_1'] - df[['reference_price', 'bid_price']].min(axis = 1)
    df['openfe_cat0'] = df['tick_up_down'].astype(str) + df['seconds_in_bucket'].astype(str)
    df['openfe4'] = group['reference_price_shift_3'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
    df['openfe5'] = df[['imbalance_size', 'imbalance_size_shift_3']].min(axis = 1)
    df['openfe6'] = group['far_price'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
    df['temp7'] = df[['wap', 'wap_shift_2']].max(axis = 1)
    df['openfe7'] = group['temp7'].rolling(1000, 1).std(engine='numba',engine_kwargs={'nopython': True})
    df['openfe8'] = group['reference_price_shift_10'].rolling(1000, 1).min(engine='numba',engine_kwargs={'nopython': True})
    df['openfe9'] = df[['imbalance_size', 'imbalance_size_shift_3']].min(axis = 1)/df[['matched_size_shift_1', 'matched_size_shift_10']].max(axis =1)
    df['openfe10'] = np.sqrt(df[['matched_size', 'ask_size']].min(axis =1))
    df['openfe11'] = df[['ask_price', 'wap_shift_3']].max(axis = 1)
    df['openfe12'] = np.sqrt(1/(1+np.exp(-df['wap_shift_10'])))
    df['openfe13'] = np.square(df['ask_price'])
    df['openfe14'] = df['bid_price_diff_3'] * df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis = 1)
    df['openfe15'] = df['matched_size_shift_2'] - df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis = 1)
    df['openfe16'] = group['wap'].rolling(1000, 1).mean(engine='numba',engine_kwargs={'nopython': True})
    df['openfe17'] = df[['far_price', 'ask_price_diff_3']].max(axis =1)
    df['openfe18'] = 1/(1+np.exp(-df['wap_shift_10']))
    df['openfe19'] = group['far_price'].rolling(1000, 1).median(engine='numba',engine_kwargs={'nopython': True}).droplevel(0)
    df['openfe20'] = group['matched_size_shift_10'].rolling(1000, 1).min(engine='numba',engine_kwargs={'nopython': True})
    df['openfe21'] = group['ask_price_diff_3'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
    df['openfe22'] = df['ask_size_diff_3'] + df[['imbalance_size', 'imbalance_size_shift_3']].min(axis = 1)
    df['openfe23'] = df[['wap', 'wap_shift_2']].max(axis = 1)
    df['openfe24'] = df[['wap_shift_1', 'wap_shift_2']].max(axis = 1)
    df['openfe25'] = df['reference_price_shift_2'] + df[['ask_price', 'wap_shift_3']].max(axis = 1)
    df['openfe26'] = df[['matched_size', 'imbalance_size']].max(axis = 1)
    df['openfe27'] = df[['reference_price', 'bid_price']].min(axis = 1)
    df['openfe28'] = df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis = 1)
    df['openfe29'] = df['ask_price'] * df['openfe28']
    df['openfe30'] = 1/(1+np.exp(-df['reference_price']/df['wap_shift_3']))
    df['openfe31'] = df[['ask_size_diff_10', 'bid_size_diff_10']].min(axis =1)
    df.drop(columns=['temp7'], inplace=True)
    openfe_num_vars += [f'openfe{i}' for i in range(32)]
    openfe_cat_vars += [f'openfe_cat{i}' for i in range(1)]
    return df, openfe_num_vars, openfe_cat_vars




if __name__ == '__main__':

    train = pd.read_csv(r'train.csv') #(5237980, 17)
    train = train.dropna(subset=['target']).reset_index(drop = True)
    train_idx, val_idx, test_idx = train_val_test_split(train)

    train_val_data2 = joblib.load(r'D:\jiadi\optiver-trading-at-the-close\feature\basic_rolling_features.pkl')  # contains target, time_id
    vars_dict = joblib.load(r'D:\jiadi\optiver-trading-at-the-close\feature\vars_dict.pkl')

    openfe_df = pd.read_excel(r'D:\jiadi\optiver-trading-at-the-close\params\openfe_features_selected.xlsx',
                              sheet_name='merged').sort_values(by='score', ascending=False)
    col_list = openfe_df.features.to_list()
    with timer('calculate OpenFE features'):
        df, openfe_num_vars, openfe_cat_vars = calc_openFE_features(train_val_data2, col_list)
    print(df.shape)
    vars_dict['openfe_num_vars'], vars_dict['openfe_cat_vars'] = openfe_num_vars, openfe_cat_vars
    # na_pcts = df.isna().mean(axis = 0).rename('na_pct')
    # temp = na_pcts[na_pcts>0.5]

    joblib.dump(df, r'feature/basic_rolling_openfe_features.pkl')
    joblib.dump(vars_dict, r'feature/vars_dict1.pkl')




    # openFE_vars = (
    #     vars_dict['orig_price_vol_num_vars'] + vars_dict['lag_vars']
    #      + vars_dict['diff_vars'] + vars_dict['price_vol_cat_vars']
    #     + vars_dict['stock_cat_vars'] + vars_dict['date_num_vars']) # date_id, seconds in bucket here belongs to cat features
    # categorical_features =  vars_dict['price_vol_cat_vars'] + vars_dict['stock_cat_vars'] + vars_dict['date_num_vars']
    #
    # train_x = train_val_data2.loc[:, openFE_vars]
    # train_y = train_val_data2.loc[:, 'target']
    # print(train_x.shape)
    # print(train_y.shape)
    #
    # train_index = train_val_data2.loc[train_idx, :].index
    # val_index= train_val_data2.loc[val_idx, :].index
    # ofe = OpenFE()
    # new_features_list = ofe.fit(
    #     data=train_x,
    #     label=train_y,
    #     n_jobs=60,
    #     task = 'regression',
    #     train_index = train_index,
    #     val_index = val_index,
    #     n_data_blocks = 32,    #stage1 left: #features/32
    #     min_candidate_features = 300,
    #     categorical_features = categorical_features,
    #     stage1_metric = 'corr',
    #     )
    # joblib.dump(ofe, f"model/openFE_vars")
    #
    # ofe = joblib.load(r"model/openFE_vars")
    # fea_dict = {}
    # for i in range(len(ofe.new_features_list)):
    #     feature = ofe.new_features_list[i]
    #     print(tree_to_formula(feature))
    #     fea_dict[tree_to_formula(feature)] = [ofe.new_features_scores_list[i][1]]
    # fea_df = pd.DataFrame.from_dict(fea_dict).T
    # # train_x_tr, _ = transform(train_x, pd.DataFrame(), ofe.new_features_list[:100], n_jobs = 32)
    # train_x_order1 = train_x.copy()   #(, 53)
    # order1_fea = pd.read_excel(r'params/openfe_features_selected.xlsx', sheet_name = 'order1')['columns'].to_list()
    # for fea in order1_fea:
    #     try:
    #         train_x_order1[fea] = train_x_order1.eval(fea)
    #     except:
    #         print(fea)
    # train_x_order1['min_matched_size_ask_size'] = train_x_order1[['matched_size', 'ask_size']].min(axis = 1)
    # train_x_order1['min_imbalance_size_imbalance_size_shift_3'] = train_x_order1[['imbalance_size', 'imbalance_size_shift_3']].min(axis=1)
    # train_x_order1['max_ask_price_wap_shift_3'] = train_x_order1[['ask_price', 'wap_shift_3']].max(axis=1)
    # train_x_order1['square_ask_price'] = np.square(train_x_order1['ask_price'])
    # train_x_order1['sigmoid_wap_shift_10'] =  1 / (1 + np.exp(-train_x_order1['wap_shift_10']))
    # train_x_order1['max_wap_wap_shift_2'] = train_x_order1[['wap', 'wap_shift_2']].max(axis=1)
    # train_x_order1['max_wap_shift_1_wap_shift_2'] = train_x_order1[['wap_shift_1', 'wap_shift_2']].max(axis=1)
    # train_x_order1['min_reference_price_bid_price'] = train_x_order1[['reference_price', 'bid_price']].min(axis=1)
    # train_x_order1['min_matched_size_shift_2_imbalance_size_shift_2'] = train_x_order1[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis=1)
    # train_x_order1['max_matched_size_shift_1_matched_size_shift_10'] = train_x_order1[['matched_size_shift_1', 'matched_size_shift_10']].max(axis=1)
    # train_x_order1['square_imbalance_size_shift_2'] = np.square(train_x_order1['imbalance_size_shift_2'])
    # print(train_x_order1.shape)
    # ofe1 = OpenFE()
    # new_features_list = ofe1.fit(
    #     data=train_x_order1,
    #     label=train_y,
    #     n_jobs=60,
    #     task = 'regression',
    #     train_index = train_index,
    #     val_index = val_index,
    #     n_data_blocks = 64,    #stage1 left: #features/64
    #     min_candidate_features = 300,
    #     categorical_features = categorical_features,
    #     stage1_metric = 'corr',
    #     )
    # joblib.dump(ofe1, f"model/openFE_vars_order1")
    #
    #
    # ofe1 = joblib.load(r"model/openFE_vars_order1")
    # fea_dict1 = {}
    # for i in range(len(ofe1.new_features_list)):
    #     feature = ofe1.new_features_list[i]
    #     print(tree_to_formula(feature))
    #     fea_dict1[tree_to_formula(feature)] = [ofe1.new_features_scores_list[i][1]]
    # fea_df1 = pd.DataFrame.from_dict(fea_dict1).T
    # fea_df1.columns = ['score']
    # fea_df1 = fea_df1.loc[fea_df1.score>0]
    # fea_df1.to_excel(r'params/openfe_features_order1.xlsx')
