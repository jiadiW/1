import pandas as pd
import numpy as np
import lightgbm as lgb  #3.3.3
import seaborn as sns
import gc
import plotly.express as px
import warnings
import datetime
import matplotlib.pyplot as plt
import sys
import pickle
import json
import joblib  #1.3.1
import scipy
import time
import traceback
import bottleneck as bn
import multiprocessing

from openfe import OpenFE, tree_to_formula, transform
from sklearn.feature_selection import RFE
from joblib import Parallel, delayed
from numpy.lib import pad
from numba import jit, njit
from numpy.lib.stride_tricks import as_strided
from os import path, walk, getpid
from psutil import Process
from contextlib import contextmanager
from itertools import combinations
from itertools import groupby
from collections import defaultdict
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from pandas import Timestamp
from sklearn.metrics import mean_absolute_error
from lightgbm import log_evaluation, early_stopping
# from bayes_opt import BayesianOptimization
from typing import Dict, List, Optional, Tuple
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import minmax_scale
from warnings import simplefilter
from sklearn.base import BaseEstimator, TransformerMixin
simplefilter(action="ignore", category=pd.errors.PerformanceWarning)

class FEATURIZER_CFG:
    """
    Configuration class for feature engineering
    """
    target = 'target'
    Is_Train = True
    Is_Infer = True
    USE_TIME_CV_FOLD = True
    N_Folds = 4
    USE_PRECOMPUTE_FEATURES = True
    N_NEIGHBORS_MAX = 50    #80
    USE_PRICE_NN_FEATURES = True  # Use nearest neighbor features
    USE_SIZE_NN_FEATURES = True  # Use nearest neighbor features that can be calculated without tick size
    USE_RETURN_NN_FEATURES = True
    USE_TIME_ID_NN = True  # Use time-id based neighbors
    USE_STOCK_ID_NN = True  # Use stock-id based neighbors
    ENABLE_RANK_NORMALIZATION = True  # Enable rank-normalization
    MY_Path = r'D:\jiadi\optiver-trading-at-the-close'
    N_Jobs = multiprocessing.cpu_count()  #8
    is_offline = False  # Flag for online/offline mode
    max_lookback = np.nan  # Maximum lookback (not specified)
    split_day = 420  # Split day for time series data


def reduce_mem_usage(df, verbose=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64', 'int64[pyarrow]', 'double[pyarrow]',
                'Int16', 'Int32', 'Int64', 'Float16', 'Float32', 'Float64']
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtypes
        # print(col)
        if col_type in numerics:
            try:
                c_min = df[col].min()
                c_max = df[col].max()
                if str(col_type)[:3] in ['int', 'Int']:
                    if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                        df[col] = df[col].astype(np.int8)
                    elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                        df[col] = df[col].astype(np.int16)
                    elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                        df[col] = df[col].astype(np.int32)
                    elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                        df[col] = df[col].astype(np.int64)
                else:
                    # if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    #     df[col] = df[col].astype(np.float16)
                    if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                        df[col] = df[col].astype(np.float32)
                    else:
                        df[col] = df[col].astype(np.float64)
            except: #columns all nan
                df[col] = df[col].astype(np.float32)
    end_mem = df.memory_usage().sum() / 1024**2
    print('Memory usage after optimization is: {:.2f} MB'.format(end_mem))
    print('Decreased by {:.1f}%'.format(100 * (start_mem - end_mem) / start_mem))

    return df


def train_val_test_split(df):
  '''
  train: date_id: 0-360
  validation: date_id: 361-420
  test: date_id: 421-480
  '''
  df = df.sort_values(by=['date_id', 'seconds_in_bucket', 'stock_id'])
  train = df.loc[df.date_id <=360, :].copy()
  validation = df.loc[(df.date_id>360)&(df.date_id<=420)].copy()
  test = df.loc[df.date_id>420].copy()
  return train.index.to_list(), validation.index.to_list(), test.index.to_list()


def log_return(series: np.ndarray, window): #TODO:需要加速
    # return np.clip(np.log(series).diff(window), -10, 10)
    return np.log(series).diff(window)

@njit(cache=True)
def realized_volatility(series):
    return np.sqrt(np.nanmean(series**2))


from numba import njit, prange

@njit(cache=True)
def compute_triplet_imbalance(df_values, comb_indices):  #(max-mid)/(mid-min), min/max
    num_rows = df_values.shape[0]
    num_combinations = len(comb_indices)
    imbalance_features = np.empty((num_rows, 2*num_combinations))

    for i in prange(num_combinations):
        a, b, c = comb_indices[i]
        for j in range(num_rows):
            max_val = max(df_values[j, a], df_values[j, b], df_values[j, c])
            min_val = min(df_values[j, a], df_values[j, b], df_values[j, c])
            mid_val = df_values[j, a] + df_values[j, b] + df_values[j, c] - min_val - max_val

            if mid_val == min_val:
                imbalance_features[j, 2*i] = np.nan
            else:
                imbalance_features[j, 2*i] = (max_val - mid_val) / (mid_val - min_val)
            imbalance_features[j, 2*i+1] = min_val/max_val
    return imbalance_features


def calculate_triplet_imbalance_numba(price, df):

    df_values = df[price].values
    comb_indices = [(price.index(a), price.index(b), price.index(c)) for a, b, c in combinations(price, 3)]
    features_array = compute_triplet_imbalance(df_values, comb_indices)
    temp = [[f"{a}_{b}_{c}_imb2", f"{a}_{b}_{c}_imb3"] for a, b, c in combinations(price, 3)]
    columns = sum(temp, [])
    features = pd.DataFrame(features_array, columns=columns)

    return features


def write_rolling_features(roll_cols, group, rolling_window):
    df = pd.DataFrame()
    new_cols = []
    for col in roll_cols:
        # print(col)
        for window in rolling_window:
            df[f'{col}_rmean_{window}'] = group[col].rolling(window, 1).mean(engine='numba', engine_kwargs={'nopython': True})
            df[f'{col}_rnanstd_{window}'] = group[col].rolling(window, 1).std(engine='numba',engine_kwargs={'nopython': True})
            df[f'{col}_rrvol_{window}'] = group[col].rolling(window, 1).apply(realized_volatility,engine='numba', raw=True).droplevel(level=[0, 1])
            new_cols+=[f'{col}_rmean_{window}', f'{col}_rnanstd_{window}', f'{col}_rrvol_{window}']
    return df, new_cols


class OptiverFeaturizer(BaseEstimator, TransformerMixin):
    def __init__(self, config):
        # configurations
        self.config = config
        self.target = self.config.target
        if self.config.USE_PRECOMPUTE_FEATURES:
            # self.vars_dict = joblib.load(f'{self.config.MY_Path}/feature/vars_dict.pkl')
            self.vars_dict = joblib.load(f'{self.config.MY_Path}/feature/vars_dict1.pkl')

    def basic_feat_eng(self, df):

        df = df.sort_values(by=['date_id', 'seconds_in_bucket', 'stock_id']).reset_index(drop=True)
        sizes = ["matched_size", "bid_size", "ask_size", "imbalance_size"]

        df['tick_diff'] = df.groupby(['date_id', 'stock_id'])['wap'].diff()
        df['mid_price'] = (df['ask_price'] + df['bid_price']) / 2
        df['swap_price'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / (
                    df['bid_size'] + df['ask_size'])

        df['total_volume1'] = df['ask_size'] + df['bid_size']
        df['total_volume2'] = df['matched_size'] + df['imbalance_size']
        df['imb_s1'] = (df['bid_size'] - df['ask_size']) / (df['bid_size'] + df['ask_size'])
        df['imb_s2'] = (df['imbalance_size'] - df['matched_size']) / (df['matched_size'] + df['imbalance_size'])
        df['imb_s3'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / (
                df['bid_price'] * df['bid_size'] - df['ask_price'] * df['ask_size'])
        df['imbalance_ratio'] = df['imbalance_size'] / df['matched_size']
        df['slope_bid'] = df['bid_size'] / ((df['bid_size'] + df['ask_size']) / 2 + 1)
        df['slope_ask'] = df['ask_size'] / ((df['bid_size'] + df['ask_size']) / 2 + 1)

        prices = ['reference_price', 'far_price', 'near_price', 'ask_price', 'bid_price', 'wap']
        interactive_num_vars = []

        # all prices pairs filter correlation > 0.9

        # (x-y)
        df['near_price_minus_wap'] = df['near_price'] - df['wap']
        df['near_price_minus_ask_price'] = df['near_price'] - df['ask_price']
        df['far_price_minus_near_price'] = df['far_price'] - df['near_price']

        # (x-y)/(x+y)
        df['ask_price_wap_imb'] = (df['ask_price'] - df['wap']) / (df['ask_price'] + df['wap'])
        df['reference_price_wap_imb'] = (df['reference_price'] - df['wap']) / (df['reference_price'] + df['wap'])
        df['reference_price_bid_price_imb'] = (df['reference_price'] - df['bid_price']) / (
                    df['reference_price'] + df['bid_price'])

        # 1/(1/x+1/y)
        df['far_price_bid_price_imb4'] = 1 / (1 / df['far_price'] + 1 / df['bid_price'])
        df['reference_price_near_price_imb4'] = 1 / (1 / df['reference_price'] + 1 / df['near_price'])
        interactive_num_vars += ['near_price_minus_wap', 'near_price_minus_ask_price', 'far_price_minus_near_price', 'ask_price_wap_imb',
                                 'reference_price_wap_imb', 'reference_price_bid_price_imb', 'far_price_bid_price_imb4', 'reference_price_near_price_imb4']
        # all triple pairs filter correlation > 0.9
        print('all triple pairs filter correlation > 0.9')
        # min/max, (max-mid)/(mid-min)
        for c in [['ask_price', 'bid_price', 'wap', 'reference_price'], sizes]:  # imb2, imb3
            triplet_feature = calculate_triplet_imbalance_numba(c, df)
            df[triplet_feature.columns] = triplet_feature.values
            interactive_num_vars += list(triplet_feature.columns)
        # z/(x+y), (x-y)/z
        for c in [
            ('reference_price', 'bid_price', 'wap'), ('reference_price', 'ask_price', 'wap'),
            ('far_price', 'near_price', 'bid_price'),
            ('reference_price', 'ask_price', 'bid_price'), ('ask_price', 'bid_price', 'wap'),
            ('reference_price', 'near_price', 'bid_price'),
            ('reference_price', 'near_price', 'ask_price'), ('reference_price', 'far_price', 'bid_price'),
            ('reference_price', 'near_price', 'wap')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb5'] = 2 * df[c[0]] / (df[c[1]] + df[c[2]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb5']

        for c in [
            ('far_price', 'near_price', 'wap'), ('near_price', 'ask_price', 'bid_price'),
            ('far_price', 'near_price', 'ask_price'),
            ('far_price', 'near_price', 'bid_price'), ('reference_price', 'far_price', 'ask_price'),
            ('far_price', 'ask_price', 'bid_price'),
            ('reference_price', 'ask_price', 'wap'), ('reference_price', 'bid_price', 'wap'),
            ('ask_price', 'bid_price', 'wap'),
            ('reference_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb6'] = 2 * df[c[1]] / (df[c[0]] + df[c[2]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb6']

        for c in [
            ('reference_price', 'ask_price', 'wap'), ('reference_price', 'bid_price', 'wap'),
            ('near_price', 'ask_price', 'wap'),
            ('reference_price', 'near_price', 'wap'), ('far_price', 'bid_price', 'wap'),
            ('far_price', 'ask_price', 'wap'),
            ('reference_price', 'near_price', 'ask_price'), ('reference_price', 'near_price', 'bid_price'),
            ('near_price', 'ask_price', 'bid_price'),
            ('reference_price', 'far_price', 'near_price'), ('far_price', 'ask_price', 'bid_price'),
            ('reference_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb7'] = 2 * df[c[2]] / (df[c[0]] + df[c[1]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb7']

        for c in [
            ('reference_price', 'near_price', 'bid_price'), ('reference_price', 'far_price', 'wap'),
            ('reference_price', 'bid_price', 'wap')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb8'] = (df[c[0]] - df[c[1]]) / df[c[2]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb8']

        for c in [
            ('reference_price', 'bid_price', 'wap'), ('reference_price', 'near_price', 'ask_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb9'] = (df[c[0]] - df[c[2]]) / df[c[1]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb9']

        for c in [
            ('ask_price', 'bid_price', 'wap'), ('far_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb10'] = (df[c[1]] - df[c[2]]) / df[c[0]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb10']

        print('calculate other features.')
        df['if_last5min'] = df['seconds_in_bucket'].apply(lambda x: 1 if x >= 300 else 0)
        df['if_last2min'] = df['seconds_in_bucket'].apply(lambda x: 1 if x >= 480 else 0)
        df['imbalance_buy_sell_flag'] = df.imbalance_buy_sell_flag.apply(lambda x: 0 if x == -1 else 1)  # 0,1
        df['tick_up_down'] = np.where(df['tick_diff'] > 0, 2, np.where(df['tick_diff'] < 0, 0, 1))  # 0,1,2
        df['tick_path'] = np.abs(df['tick_diff'] / df['wap'])

        group = df.groupby(['date_id', 'stock_id'], group_keys=False)
        df['bs_lag1'] = group['bid_size'].shift(1)
        df['as_lag1'] = group['ask_size'].shift(1)
        df['b1p_diff1'] = group['bid_price'].diff()
        df['a1p_diff1'] = group['ask_price'].diff()
        df['flow'] = (
                             df['bid_size'] * np.where(df['b1p_diff1'] >= 0, 1, 0) - df['bs_lag1'] * np.where(
                         df['b1p_diff1'] <= 0, 1, 0)) - (
                             df['ask_size'] * np.where(df['a1p_diff1'] <= 0, 1, 0) - df['as_lag1'] * np.where(
                         df['a1p_diff1'] >= 0, 1, 0)
                     )
        df['bid_wap'] = (df['wap'] - df['bid_price']) / df['wap'].clip(1e-6, )
        df['ask_wap'] = (df['ask_price'] - df['wap']) / df['wap'].clip(1e-6, )
        df['dispersion_diff'] = df['bid_wap'] - df['ask_wap']

        df["imbalance_momentum"] = group['imbalance_size'].diff(periods=1) / df['matched_size']
        df["price_spread"] = df["ask_price"] - df["bid_price"]
        df["spread_intensity"] = group['price_spread'].diff()
        df['price_pressure'] = df['imbalance_size'] * (df['ask_price'] - df['bid_price'])
        df['market_urgency'] = df['price_spread'] * df['imb_s1']
        df['depth_pressure'] = (df['ask_size'] - df['bid_size']) * (df['far_price'] - df['near_price'])

        # Calculate various statistical aggregation features
        reference_global_vars = []
        prices = ["reference_price", "far_price", "near_price", "ask_price", "bid_price", "wap"]
        for func in ["mean", "std", "skew", "kurt"]:
            df[f"all_prices_{func}"] = df[prices].agg(func, axis=1)
            df[f"all_sizes_{func}"] = df[sizes].agg(func, axis=1)
            reference_global_vars += [f"all_prices_{func}", f"all_sizes_{func}"]

        # Calculate shifted and return features for specific columns
        print('calculate lag, return vars')
        return_vars = []
        lag_vars = []
        lag_cat_vars = []
        for col in ['matched_size', 'imbalance_size', 'reference_price', 'wap',]:
            for window in [1, 2, 3, 10]:
                print(col, window)
                df[f"{col}_shift_{window}"] = group[col].shift(window)
                lag_vars.append(f"{col}_shift_{window}")
                df[f'log_return_{col}_{window}'] = group[col].apply(log_return, window=window)
                return_vars.append(f'log_return_{col}_{window}')
        for col in ['imbalance_buy_sell_flag']:
            for window in [1,2,3,10]:
                df[f"{col}_shift_{window}"] = group[col].shift(window)
                lag_cat_vars.append(f"{col}_shift_{window}")

        # Calculate diff features for specific columns
        diff_vars = []
        for col in ['ask_price', 'bid_price', 'ask_size', 'bid_size', 'imbalance_buy_sell_flag']:
            for window in [1, 2, 3, 10]:
                df[f"{col}_diff_{window}"] = group[col].diff(window)
                diff_vars += [f"{col}_diff_{window}"]

        # cols_to_log = ['total_volume1', 'total_volume2', 'matched_size', 'imbalance_size']
        # for col in cols_to_log:
        #     df[col] = np.log(df[col] + 1)

        df.drop(columns=[
            'row_id'
        ], inplace=True)

        df = df.replace([np.inf, -np.inf], 0)

        orig_price_vol_num_vars = [
            'reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price', 'bid_price', 'bid_size',
            'ask_price', 'ask_size', 'wap']

        # return_vars, lag_vars, diff_vars, lag_cat_vars

        # interactive_num_vars

        derived_price_vol_num_vars = [
            'tick_diff', 'mid_price', 'swap_price', 'total_volume1', 'total_volume2', 'imb_s1', 'imb_s2', 'imb_s3',
            'imbalance_ratio', 'slope_bid', 'slope_ask', 'tick_path', 'flow', 'bid_wap', 'ask_wap', 'dispersion_diff',
            'imbalance_momentum', 'price_spread', 'spread_intensity', 'price_pressure', 'market_urgency',
            'depth_pressure'
        ]

        # reference_global_vars

        price_vol_cat_vars = ['imbalance_buy_sell_flag', 'if_last5min', 'if_last2min', 'tick_up_down']

        stock_cat_vars = ['stock_id']

        date_num_vars = ['date_id', 'seconds_in_bucket']

        cat_features = price_vol_cat_vars + stock_cat_vars +lag_cat_vars

        vars_dict = {
            'orig_price_vol_num_vars': orig_price_vol_num_vars,
            'return_vars': return_vars,
            'diff_vars': diff_vars,
            'lag_vars': lag_vars,
            'lag_cat_vars': lag_cat_vars,
            'interactive_num_vars': interactive_num_vars,
            'derived_price_vol_num_vars': derived_price_vol_num_vars,
            'price_vol_cat_vars': price_vol_cat_vars,
            'stock_cat_vars': stock_cat_vars,
            'date_num_vars': date_num_vars,
            'reference_global_vars': reference_global_vars,
            'cat_features': cat_features
        }
        gc.collect()
        #[col for col in df.columns if col not in all_features]: ['target', 'time_id', 'bs_lag1', 'as_lag1', 'b1p_diff1', 'a1p_diff1']
        return df, vars_dict

    def calc_rolling_features(self, fea_df, roll_cols, rolling_window):

        df_new = fea_df.copy()
        group = df_new.groupby(['stock_id', 'date_id'], group_keys=False)

        with timer('Calculating rolling features with Multiprocessing: '):
            n_job = self.config.N_Jobs
            print('N Jobs: %d' % n_job)
            step = int(len(roll_cols) / n_job) + 1
            params = [roll_cols[i * step:(i + 1) * step] for i in range(n_job)]
            p = Parallel(n_jobs=-1)(delayed(write_rolling_features)(_param, group, rolling_window) for _param in params)
            for res in p:
                df, new_cols = res[0], res[1]
                df_new[new_cols] = df

        rolling_features = [col for col in df_new.columns if col not in fea_df.columns]
        del fea_df
        gc.collect()
        return df_new, rolling_features


    def calc_openFE_features(self, df0, col_list):
        df = df0.copy()
        openfe_num_vars, openfe_cat_vars = [], []
        for fea in col_list:
            try:
                df[fea] = df.eval(fea)
                openfe_num_vars += [fea]
            except:
                pass
        group = df.groupby(['date_id'], group_keys=False)
        df['openfe0'] = df[['matched_size', 'ask_size']].min(axis=1)
        df['openfe1'] = group['wap'].rolling(1000, 1).rank(ascending=True, pct=True, engine='numba',
                                                           engine_kwargs={'nopython': True}).droplevel(0)
        df['openfe2'] = df[['wap', 'wap_shift_2']].max(axis=1) - df[['reference_price', 'bid_price']].min(axis=1)
        df['openfe3'] = df['reference_price_shift_1'] - df[['reference_price', 'bid_price']].min(axis=1)
        df['openfe_cat0'] = df['tick_up_down'].astype(str) + df['seconds_in_bucket'].astype(str)
        df['openfe4'] = group['reference_price_shift_3'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
        df['openfe5'] = df[['imbalance_size', 'imbalance_size_shift_3']].min(axis=1)
        df['openfe6'] = group['far_price'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
        df['temp7'] = df[['wap', 'wap_shift_2']].max(axis=1)
        df['openfe7'] = group['temp7'].rolling(1000, 1).std(engine='numba', engine_kwargs={'nopython': True})
        df['openfe8'] = group['reference_price_shift_10'].rolling(1000, 1).min(engine='numba',
                                                                               engine_kwargs={'nopython': True})
        df['openfe9'] = df[['imbalance_size', 'imbalance_size_shift_3']].min(axis=1) / df[
            ['matched_size_shift_1', 'matched_size_shift_10']].max(axis=1)
        df['openfe10'] = np.sqrt(df[['matched_size', 'ask_size']].min(axis=1))
        df['openfe11'] = df[['ask_price', 'wap_shift_3']].max(axis=1)
        df['openfe12'] = np.sqrt(1 / (1 + np.exp(-df['wap_shift_10'])))
        df['openfe13'] = np.square(df['ask_price'])
        df['openfe14'] = df['bid_price_diff_3'] * df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis=1)
        df['openfe15'] = df['matched_size_shift_2'] - df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis=1)
        df['openfe16'] = group['wap'].rolling(1000, 1).mean(engine='numba', engine_kwargs={'nopython': True})
        df['openfe17'] = df[['far_price', 'ask_price_diff_3']].max(axis=1)
        df['openfe18'] = 1 / (1 + np.exp(-df['wap_shift_10']))
        df['openfe19'] = group['far_price'].rolling(1000, 1).median(engine='numba',
                                                                    engine_kwargs={'nopython': True}).droplevel(0)
        df['openfe20'] = group['matched_size_shift_10'].rolling(1000, 1).min(engine='numba',
                                                                             engine_kwargs={'nopython': True})
        df['openfe21'] = group['ask_price_diff_3'].rolling(1000, 1).rank(ascending=True, pct=True).droplevel(0)
        df['openfe22'] = df['ask_size_diff_3'] + df[['imbalance_size', 'imbalance_size_shift_3']].min(axis=1)
        df['openfe23'] = df[['wap', 'wap_shift_2']].max(axis=1)
        df['openfe24'] = df[['wap_shift_1', 'wap_shift_2']].max(axis=1)
        df['openfe25'] = df['reference_price_shift_2'] + df[['ask_price', 'wap_shift_3']].max(axis=1)
        df['openfe26'] = df[['matched_size', 'imbalance_size']].max(axis=1)
        df['openfe27'] = df[['reference_price', 'bid_price']].min(axis=1)
        df['openfe28'] = df[['matched_size_shift_2', 'imbalance_size_shift_2']].min(axis=1)
        df['openfe29'] = df['ask_price'] * df['openfe28']
        df['openfe30'] = 1 / (1 + np.exp(-df['reference_price'] / df['wap_shift_3']))
        df['openfe31'] = df[['ask_size_diff_10', 'bid_size_diff_10']].min(axis=1)
        df.drop(columns=['temp7'], inplace=True)
        openfe_num_vars += [f'openfe{i}' for i in range(32)]
        openfe_cat_vars += [f'openfe_cat{i}' for i in range(1)]
        return df, openfe_num_vars, openfe_cat_vars


    def fit_transform(self, df):

        # Fit transformers that require fitting, e.g. normalizer, one hot encoder etc.
        print('Fitting featurizers...')

        if self.config.USE_PRECOMPUTE_FEATURES:
            self.train_val_data = pd.read_feather(f'{self.config.MY_Path}/feature/basic_rolling_openfe_features.feather') # contains target, time_id

        else:
            with timer('make basic feature'):  # (, 171)
                fea_basic_df, self.vars_dict = self.basic_feat_eng(df)
                fea_basic_df.to_feather(f'{self.config.MY_Path}/feature/basic_features.feather')

            with timer('calculating rollling feature'):  # +126
                temp = ['dispersion_diff', 'slope_ask', 'reference_price_bid_price_wap_imb7',
                        'reference_price_ask_price_wap_imb7', 'reference_price_bid_price_wap_imb9',
                        'reference_price_wap_imb']
                orig_price_vol_num_vars = [
                    'reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price', 'bid_price',
                    'bid_size', 'ask_price', 'ask_size', 'wap']
                additial_columns = orig_price_vol_num_vars + ['mid_price', 'swap_price', 'total_volume1',
                                                              'total_volume2', 'flow']
                roll_cols = list(set(temp + additial_columns))
                fea_rolling_df, rolling_features = self.calc_rolling_features(fea_basic_df, roll_cols, [6, 12])
                self.vars_dict['rolling_vars'] = rolling_features
                print(fea_rolling_df.shape)  # (, 297)

                fea_rolling_df = reduce_mem_usage(
                    fea_rolling_df.convert_dtypes())  # change each columns from object to Float, Int
                fea_rolling_df.to_feather(f'{self.config.MY_Path}/feature/basic_rolling_features.feather')


            with timer('calculating OpenFE features'):
                openfe_df = pd.read_excel(r'D:\jiadi\optiver-trading-at-the-close\params\openfe_features_selected.xlsx',
                                          sheet_name='merged').sort_values(by='score', ascending=False)
                col_list = openfe_df.features.to_list()
                fea_openfe_df,openfe_num_vars, openfe_cat_vars = self.calc_openFE_features(fea_rolling_df, col_list)
                self.vars_dict['openfe_num_vars'], self.vars_dict['openfe_cat_vars'] = openfe_num_vars, openfe_cat_vars
                self.vars_dict['cat_features'] += openfe_cat_vars
                self.train_val_data = reduce_mem_usage(fea_openfe_df)
                for col in self.vars_dict['cat_features']:
                    self.train_val_data[col] = self.train_val_data[col].astype('category')
                self.train_val_data.to_feather(f'{self.config.MY_Path}/feature/basic_rolling_openfe_features.feather')

            joblib.dump(self.vars_dict, f'{self.config.MY_Path}/feature/vars_dict1.pkl')

        return self.train_val_data


    def preprocess(self, X, y=None):
        pass


    def transform(self, df):
        # Perform arbitary transformation
        print('Transforming Test Data...')

        with timer('Make Basic Features'):
            fea_basic_df, _ = self.basic_feat_eng(df)

        with timer('Make Rolling Features'):
            temp = ['dispersion_diff', 'slope_ask', 'reference_price_bid_price_wap_imb7',
                    'reference_price_ask_price_wap_imb7', 'reference_price_bid_price_wap_imb9',
                    'reference_price_wap_imb']
            orig_price_vol_num_vars = [
                'reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price', 'bid_price',
                'bid_size', 'ask_price', 'ask_size', 'wap']
            additial_columns = orig_price_vol_num_vars + ['mid_price', 'swap_price', 'total_volume1', 'total_volume2', 'flow']
            roll_cols = list(set(temp + additial_columns))
            fea_rolling_df, _ = self.calc_rolling_features(fea_basic_df, roll_cols, [6, 12])
            fea_rolling_df = reduce_mem_usage(fea_rolling_df.convert_dtypes())  # change each columns from object to Float, Int

        with timer('make OpenFE Features'):
            openfe_df = pd.read_excel(r'D:\jiadi\optiver-trading-at-the-close\params\openfe_features_selected.xlsx',
                                      sheet_name='merged').sort_values(by='score', ascending=False)
            col_list = openfe_df.features.to_list()
            fea_openfe_df, openfe_num_vars, openfe_cat_vars = self.calc_openFE_features(fea_rolling_df, col_list)
            df = reduce_mem_usage(fea_openfe_df)

        for col in self.vars_dict['cat_features']:
            df[col] = df[col].astype('category')

        return df


@contextmanager
def timer(name: str):
    s = time.time()
    yield
    elapsed = time.time() - s
    print(f'[{name}] {elapsed: .3f}sec')


def print_trace(name: str = ''):
    print(f'ERROR RAISED IN {name or "anonymous"}')
    print(traceback.format_exc())

def calc_ic_ir(df, exclude_cols = ['stock_id', 'time_id', 'date_id', 'seconds_in_bucket', 'target', 'if_last5min', 'if_last2min']):
  full_vars = df.columns.to_list()
  corr = defaultdict(dict)
  target_value = df.pivot(index= 'stock_id', columns = 'time_id', values = 'target')
  for col in full_vars:
    if col in exclude_cols: continue
    else:
        factor_value = df.pivot(index= 'stock_id', columns = 'time_id', values = col)
        IC = factor_value.corrwith(target_value, method = 'kendall', axis = 0)  #每个time_id求一个IC取平均
        mean_ic = np.nanmean(IC)
        ir = mean_ic/np.nanstd(IC)
        corr[col]['mean_ic'], corr[col]['ir'] = mean_ic, ir
        print(f'{col}, Mean IC: {mean_ic: .4f}, IR: {ir: .4f}')
  metric_df = pd.DataFrame.from_dict(corr).T
  metric_df['abs_mean_ic'] = np.abs(metric_df['mean_ic'])
  metric_df['abs_ir'] = np.abs(metric_df['ir'])
  metric_df = metric_df.sort_values(by = ['abs_ir', 'abs_mean_ic'], ascending = False)
  return metric_df


train = pd.read_csv(r'train.csv') #(5237980, 17)
train = train.dropna(subset=['target']).reset_index(drop = True)
train = reduce_mem_usage(train)
train.info()
temp = train.groupby('date_id')['stock_id'].apply(lambda x: len(x.unique()))

train_idx, val_idx, test_idx = train_val_test_split(train)
train_val_data = train.loc[(train_idx+val_idx), :].copy()
test_data = train.loc[(test_idx), :].copy()
gc.collect()


featurizer = OptiverFeaturizer(FEATURIZER_CFG)
try:
  train_val_data2 = featurizer.fit_transform(train_val_data)
  test_data2 = featurizer.transform(test_data)
  gc.collect()
except:
  print_trace('stock featurization')

print(train_val_data2.shape, test_data2.shape)  #(4577893, 297) (659999, 297)


"""
Model Build 
full_vars: Test MAE: 5.7251; full_vars+knn_vars+sample_weights: 5.7242, v5: 5.7168, v5 + filtered feature importance: 5.7181,
v7: Test MAE: 5.7073, v7+openfe: 5.7010
"""
train_data, validation_data = train_val_data2.loc[train_idx], train_val_data2.loc[val_idx] #(3917948, 297),(659945, 297),
test_data = test_data2.copy() #(659999, 297)
vars_dict = featurizer.vars_dict
total_vars = (vars_dict['orig_price_vol_num_vars']
              + vars_dict['return_vars']
              + vars_dict['diff_vars']
              + vars_dict['lag_vars']
              + vars_dict['lag_cat_vars']
              + vars_dict['interactive_num_vars']
              + vars_dict['derived_price_vol_num_vars']
              + vars_dict['price_vol_cat_vars']
              + vars_dict['stock_cat_vars']
              + vars_dict['date_num_vars']
              + vars_dict['reference_global_vars']
              + vars_dict['rolling_vars'])

total_vars2 = total_vars + vars_dict['openfe_num_vars'] + vars_dict['openfe_cat_vars']

train_x, train_y = train_data.loc[:, total_vars2], train_data.loc[:, 'target']
validation_x, validation_y = validation_data.loc[:, total_vars2], validation_data.loc[:, 'target']
test_x, test_y = test_data.loc[:, total_vars2], test_data.loc[:, 'target']
#time_id: date_id*55+(seconds_in_bucket/10)
train_weight = np.log(train_data.loc[:, 'time_id']+2)
validation_weight = np.log(validation_data.loc[:, 'time_id']+2)

hyper_param0 = {'bagging_fraction': 0.98286014592707, 'feature_fraction': 0.444310836387477, 'lambda_l1': 0.0156252302416767,
         'lambda_l2': 0.06077603113532735, 'max_depth': 12, 'min_gain_to_split': 0.006515715387013565,
         'min_sum_hessian_in_leaf': 91.18902125462651, 'num_leaves': 236, 'objective': 'mae', 'learning_rate': 0.01,
         'extra_trees': True, 'metric': 'mae', 'bagging_freq': 1, 'n_estimators': 2000}

gbm = lgb.LGBMRegressor(device = 'cpu', **hyper_param0)
gbm.fit(train_x , train_y, sample_weight = train_weight,
    eval_set = [(validation_x, validation_y)], eval_sample_weight = [validation_weight],
    eval_metric = 'mae', callbacks = [log_evaluation(period=100), early_stopping(stopping_rounds=100)])
pred_test_y = gbm.predict(test_x)

if np.isnan(np.array(pred_test_y)).any():
  print("Error: There are some None values in predictions!")
test_mae = mean_absolute_error(test_y, pred_test_y)
print('Test MAE: %.4f '%(test_mae))  #full_vars: Test MAE: 5.7251; full_vars+knn_vars+sample_weights: 5.7242, v5: 5.7168, v5 + filtered feature importance: 5.7181
gc.collect()


