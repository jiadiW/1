import pandas as pd
import numpy as np
import tensorflow as tf
import random
import os
import pickle

from sklearn.metrics import mean_absolute_error
from itertools import combinations
from tqdm import tqdm
from tensorflow.keras.layers import Input, Dense, Embedding, Flatten, Concatenate, GaussianNoise
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.optimizers.schedules import ExponentialDecay
from tensorflow.keras.models import load_model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import Callback
from tensorflow.keras.layers import Input, Embedding, Lambda, Reshape, LSTM, Dense, BatchNormalization, Dropout, concatenate
from tensorflow.keras import backend as K
from tensorflow.keras.layers import ZeroPadding1D, Activation
from tensorflow.keras.layers import Conv1D
from tensorflow.keras.layers import Add
from matplotlib import pyplot as plt
#---------------------------------------------------------------------- setup dashboard ------------------------------------------------------------
kaggle = True
is_inference = False
load_models = False
run_pipeline = True
train_models = True
is_rnn = True   #3
online_learning = True
tpu_strategy = False
dates_train = [0,390]
dates_val = [391, 435]
dates_test = [436, 480]
dates_train_val = [0, 435]
num_models ={'rnn':2}
models_path = "optiver-inference-models/"
train_path = "train.csv"

if dates_train[1]!=480:
    models_path = "vals-258/"
#---------------------------------------------------------------------- setup dashboard ------------------------------------------------------------
simulation_path = "vals-258/"
rnn_ep = 100  #epoch 33 early stop
rnn_lr = 0.001
rnn_bs = 2**14  #4096
window_size = 3
if not kaggle:
    from public_timeseries_testing_util import MockApi
pd.set_option('mode.chained_assignment', None)

raw_cols = ['imbalance_size','matched_size','bid_size','ask_size','reference_price','far_price','near_price','bid_price',
                     'ask_price','wap','imbalance_buy_sell_flag']
columns_prices = ['reference_price','far_price','near_price','bid_price','ask_price','wap']
columns_sizes = ['imbalance_size','matched_size','bid_size','ask_size']
columns_flag = ['imbalance_buy_sell_flag']
num_of_target_lags= 3
target_lags = list(range(1,num_of_target_lags+1))
excluded_columns = ['row_id', 'date_id', 'time_id', 'target','stock_return']


def convert_price_cols_float32(df):
    # Columns containing 'price'
    price_columns = [col for col in df.columns if 'price' in col]
    df[price_columns] = df[price_columns].astype('float32')
    # Columns containing 'wap'
    wap_columns = [col for col in df.columns if 'wap' in col]
    df[wap_columns] = df[wap_columns].astype('float32')
    return df


def split_by_date(df, dates):
    df_start, df_end = dates
    df = df[(df['date_id'] >= df_start) & (df['date_id'] <=df_end)].reset_index(drop=True)
    return df


def lag_function(df, columns_to_lag, numbers_of_days_to_lag):
    """
    lag based on stock id, seconds_in_bucket
    """
    df_indexed = df.set_index(['stock_id', 'seconds_in_bucket', 'date_id'])
    for column_to_lag in columns_to_lag:
        for number_days_to_lag in numbers_of_days_to_lag:
            df_indexed[f'lag{number_days_to_lag}_{column_to_lag}'] = df_indexed.groupby(level=['stock_id', 'seconds_in_bucket'])[column_to_lag].shift(number_days_to_lag)
    df_indexed.reset_index(inplace=True)
    return df_indexed


def compute_imbalances(df_, columns, prefix = ''):
    """Computes the differences and imbalances for pairs of columns and stores them in the DataFrame."""
    df = df_.copy()
    for col1, col2 in combinations(columns, 2):
        # Sort the columns lexicographically to ensure consistent ordering
        col1, col2 = sorted([col1, col2])
        # Compute imbalance directly without creating a temporary difference column
        total = df[col1] + df[col2]
        imbalance_column_name = f'{col1}_{col2}_imb{prefix}'
        # Ensure we don't divide by zero
        df[imbalance_column_name] = (df[col1] - df[col2]).divide(total, fill_value=np.nan)
    return df


def save_pickle(data, file_path):
    # Create the directory if it doesn't exist
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Save the pickle file
    with open(file_path, 'wb') as file:
        pickle.dump(data, file)
    print(f"Data saved to {file_path}")


def load_pickle(file_path):
    # Load and return the data from the pickle file
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            data = pickle.load(file)
        return data
    else:
        raise FileNotFoundError(f"No such file: {file_path}")


def feature_pipeline(df):
    if df.empty:
        return pd.DataFrame()
    print(f"lagging target column for {len(target_lags)} lags.")
    df = lag_function(df, ['target'], target_lags)
    print("Done...")
    return df


def make_predictions(models, X_test,model = 'nn'):
    if model == 'nn':  #batch size: determine the data size that fit into CPU/GPU RAM, and also impact if BN layer is used.
        all_predictions = [model.predict(X_test, batch_size=16384) for model in models]
    if model == 'lgb' or model == 'xgb' or model == 'cat':
        all_predictions = [model.predict(X_test) for model in models]
    prediction = np.mean(all_predictions, axis=0)
    return prediction


def set_all_seeds(seed):
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


class BestScoresCallback(Callback):
    def __init__(self):
        super().__init__()
        self.best_train_loss = float('inf')
        self.best_val_loss = float('inf')

    def on_epoch_end(self, epoch, logs=None):
        train_loss = logs.get('loss', float('inf'))
        val_loss = logs.get('val_loss', float('inf'))

        if train_loss < self.best_train_loss:
            self.best_train_loss = train_loss
        if val_loss < self.best_val_loss:
            self.best_val_loss = val_loss

    def on_train_end(self, logs=None):
        print(f"Best training loss: {self.best_train_loss}, Best validation loss: {self.best_val_loss}")


def precompute_sequences(stock_data, window_size, rnn_numerical_features, rnn_categorical_features):
    # Convert DataFrame columns to NumPy arrays
    stock_data_num = stock_data[rnn_numerical_features].values
    stock_data_cat = stock_data[rnn_categorical_features].values

    # Pre-compute all sequences
    all_sequences_num = [stock_data_num[max(0, i - window_size + 1):i + 1] for i in range(len(stock_data))]
    all_sequences_cat = [stock_data_cat[max(0, i - window_size + 1):i + 1] for i in range(len(stock_data))]

    # Add padding in front if necessary
    padded_sequences_num = [np.pad(seq, ((window_size - len(seq), 0), (0, 0)), 'constant') for seq in all_sequences_num]
    padded_sequences_cat = [np.pad(seq, ((window_size - len(seq), 0), (0, 0)), 'constant') for seq in all_sequences_cat]

    # Combine numerical and categorical features, shape: (55,3,36)
    combined_sequences = np.array([np.concatenate([num, cat], axis=-1)
                                   for num, cat in zip(padded_sequences_num, padded_sequences_cat)])

    # Extract targets
    targets = stock_data['target'].values

    return combined_sequences, targets


def get_sequence(precomputed_data, time_step):
    combined_sequences, targets = precomputed_data
    return combined_sequences[time_step], targets[time_step]


def create_batches(data, window_size, rnn_numerical_features, rnn_categorical_features, max_time_steps=55):

    grouped = data.groupby(['stock_id', 'date_id'])
    all_batches = []
    all_targets = []

    for _, group in tqdm(grouped, desc="Processing groups"):
        # Precompute sequences for the current group
        precomputed_data = precompute_sequences(group, window_size, rnn_numerical_features, rnn_categorical_features)

        # Initialize containers for group sequences and targets
        group_sequences = []
        group_targets = []

        # transform a 3-dimenional np.array into a list of 2 dimensional numpy array
        for time_step in range(max_time_steps):
            sequence, target = get_sequence(precomputed_data, time_step)  #sequence shape: (3, 36), target: scaler value
            if sequence.size > 0:
                group_sequences.append(sequence)
                group_targets.append(target)

        # Extend the main batches with the group's sequences and targets
        all_batches.extend(group_sequences) #group sequence: (55, 3, 36)
        all_targets.extend(group_targets)

    return all_batches, all_targets


def compute_last_sequence(group, window_size, rnn_numerical_features, rnn_categorical_features):
    # Convert DataFrame columns to NumPy arrays
    stock_data_num = group[rnn_numerical_features].values
    stock_data_cat = group[rnn_categorical_features].values
    stock_data_target = group['target'].values

    # Find the index of the target second
    target_index = len(group) - 1

    # Extract the sequence for the target index
    sequence_num = stock_data_num[max(0, target_index - window_size + 1):target_index + 1]
    sequence_cat = stock_data_cat[max(0, target_index - window_size + 1):target_index + 1]

    # Add padding if necessary
    padded_sequence_num = np.pad(sequence_num, ((window_size - len(sequence_num), 0), (0, 0)), 'constant')
    padded_sequence_cat = np.pad(sequence_cat, ((window_size - len(sequence_cat), 0), (0, 0)), 'constant')

    # Combine numerical and categorical features
    combined_sequence = np.concatenate([padded_sequence_num, padded_sequence_cat], axis=-1)

    # Extract target
    target = stock_data_target[-1]
    return combined_sequence, target


def create_last_batches(data, window_size, rnn_numerical_features, rnn_categorical_features):

    grouped = data.groupby(['stock_id'])
    all_batches = []
    all_targets = []

    for _, group in grouped:
        # Compute the sequence for the last data point in the current group on inference mode
        last_sequence, last_target = compute_last_sequence(group, window_size, rnn_numerical_features, rnn_categorical_features)

        # Check if the sequence is valid (i.e., not empty)
        if last_sequence.size > 0:
            all_batches.append(last_sequence)
            all_targets.append(last_target)

    return all_batches, all_targets


def second_pass_for_rnn(df, rnn_numerical_features, rnn_categorical_features, window_size, is_inference=False):
    # Check if the DataFrame is empty
    global rnn_scaler,rnn_medians
    if df.empty:
        return None, None
    # Work on a copy of the DataFrame to avoid changing the original df
    df_copy = df.copy()
    # Standard scaling for numerical features
    if is_inference:
        df_copy.fillna(rnn_medians, inplace=True)
        df_copy[rnn_numerical_features] = rnn_scaler.transform(df_copy[rnn_numerical_features])
    # Preprocess Data
    df_copy['seconds_in_bucket'] = df_copy['seconds_in_bucket'] / 10
    df_copy['imbalance_buy_sell_flag'] += 1
    if is_inference:   #only return the data point which is the last one for each stock id
        df_copy_batches, df_copy_targets = create_last_batches(df_copy, window_size, rnn_numerical_features, rnn_categorical_features)
    else:
        df_copy_batches, df_copy_targets = create_batches(df_copy, window_size, rnn_numerical_features, rnn_categorical_features)
    df_copy_batches = np.array(df_copy_batches)  #(#samples, 3, 36)
    df_copy_targets = np.array(df_copy_targets)  #(#samples,)
    return df_copy_batches, df_copy_targets


def online_pass_for_rnn(df, rnn_numerical_features, rnn_categorical_features, window_size):
    # Check if the DataFrame is empty
    global rnn_scaler,rnn_medians

    if df.empty:
        return None, None

    # Work on a copy of the DataFrame to avoid changing the original df
    df_copy = df.copy()

    # Standard scaling for numerical features
    df_copy.fillna(rnn_medians, inplace=True)
    df_copy[rnn_numerical_features] = rnn_scaler.transform(df_copy[rnn_numerical_features])

    # Preprocess Data
    df_copy['seconds_in_bucket'] = df_copy['seconds_in_bucket'] / 10
    df_copy['imbalance_buy_sell_flag'] += 1
    grouped = df_copy.groupby(['stock_id'])
    all_batches = []
    all_targets = []

    for _, group in tqdm(grouped, desc="Processing groups"):
        # Precompute sequences for the current group
        precomputed_data = precompute_sequences(group, window_size, rnn_numerical_features, rnn_categorical_features)

        # Initialize containers for group sequences and targets
        group_sequences = []
        group_targets = []

        # Iterate over the time steps and retrieve precomputed sequences
        for time_step in range(55):
            sequence, target = get_sequence(precomputed_data, time_step)
            if sequence.size > 0:
                group_sequences.append(sequence)
                group_targets.append(target)

        # Extend the main batches with the group's sequences and targets
        all_batches.extend(group_sequences)
        all_targets.extend(group_targets)

    df_batches = np.array(all_batches)
    df_targets = np.array(all_targets)
    return df_batches, df_targets


def create_lstm_model_with_residual(window_size, numerical_features, initial_learning_rate=0.001):
    categorical_features = 'seconds_in_bucket'
    categorical_uniques  = { 'seconds_in_bucket' : 55}
    embedding_dim        = {'seconds_in_bucket' : 10}
    input_layer = Input(shape=(window_size, len(numerical_features) + 1), name="combined_input")  #(None, 3, 36)
    # Split the input into numerical and categorical parts
    numerical_input = Lambda(lambda x: x[:, :, :-1], name="numerical_part")(input_layer)  #(None, 3, 35)
    categorical_input = Lambda(lambda x: x[:, :, -1:], name="categorical_part")(input_layer)  #(None, 3, 1)

    # diffrentiate layers
    def create_difference_layer(lag):
        return Lambda(lambda x: x[:, lag:, :] - x[:, :-lag, :], name=f"difference_layer_lag{lag}")

    difference_layers = []
    for lag in range(1, window_size):
        diff_layer = create_difference_layer(lag)(numerical_input)  #(None, 3-lag, 35)
        padding = ZeroPadding1D(padding=(lag, 0))(diff_layer)  # Add padding to the beginning of the sequence, (None, 3, 35)
        difference_layers.append(padding)
    combined_diff_layer = Concatenate(name="combined_difference_layer")(difference_layers)  #(None, 3, 70)
    enhanced_numerical_input = Concatenate(name="enhanced_numerical_input")([numerical_input, combined_diff_layer])

    # Embedding for categorical part
    vocab_size, embedding_dim = categorical_uniques[categorical_features], embedding_dim[categorical_features]
    embedding = Embedding(vocab_size, embedding_dim, input_length=window_size)(categorical_input)
    embedding = Reshape((window_size, -1))(embedding)  #(None, 3, 10)

    # Concatenate numerical input and embedding
    lstm_input = concatenate([enhanced_numerical_input, embedding], axis=-1)

    # First LSTM layer
    lstml = LSTM(64, return_sequences=False)(lstm_input)
    lstml = BatchNormalization()(lstml)
    lstml = Dropout(0.3)(lstml)

    dense_output = lstml
    dense_sizes = [512, 256, 128, 64, 32]
    do_ratio = 0.3
    for size in dense_sizes:
        dense_output = Dense(size, activation='swish')(dense_output)
        dense_output = BatchNormalization()(dense_output)
        dense_output = Dropout(do_ratio)(dense_output)

    # Output layer
    output = Dense(1, name='output_layer')(dense_output)
    # Learning rate schedule
    lr_schedule = ExponentialDecay(
        initial_learning_rate=initial_learning_rate,
        decay_steps=10000,
        decay_rate=0.7,
        staircase=True)
    # Create and compile the model
    model = Model(inputs=input_layer, outputs=output)
    optimizer = Adam(learning_rate=lr_schedule)
    model.compile(optimizer=optimizer, loss="mean_absolute_error")
    return model


def plot_model_accuracy(history):
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.show()


# ----------------------------- Reading train data -------------------------
train = pd.read_csv(train_path).drop(['row_id', 'time_id'], axis = 1)
nan_count = train['target'].isna().sum()
print(f"The 'target' column has {nan_count} NaN values.")

target_median = train['target'].median()
train['target'].fillna(target_median, inplace=True)

print(f"converting prices columns to float32 values.")
train = convert_price_cols_float32(train)

train_data = split_by_date(train, dates_train_val)
test_data = split_by_date(train,dates_test)

if run_pipeline:
    train_eng = feature_pipeline(train_data)  #(5237980, 39)
    test_eng = feature_pipeline(test_data)
    excluded_columns = excluded_columns + ['stock_id']
    features = [col for col in train_eng.columns if col not in excluded_columns]
    rnn_categorical_features =  ['seconds_in_bucket']
    rnn_numerical_features = [feat for feat in features if feat not in rnn_categorical_features]
    print("we have {} numerical and {} categorical".format(len(rnn_numerical_features),len(rnn_categorical_features)))
    rnn_scaler = StandardScaler()
    rnn_medians = train_eng.median()
    train_eng.fillna(rnn_medians, inplace=True)
    test_eng.fillna(rnn_medians, inplace=True)
    train_eng[rnn_numerical_features] = rnn_scaler.fit_transform(train_eng[rnn_numerical_features])
    test_eng[rnn_numerical_features]  = rnn_scaler.transform(test_eng[rnn_numerical_features])

    rnn_all_data = {
        "rnn_scaler": rnn_scaler,
        "rnn_medians": rnn_medians,
        "rnn_categorical_features": rnn_categorical_features,
        "rnn_numerical_features": rnn_numerical_features
    }
    save_pickle(rnn_all_data, f'{models_path}lstm_all_data.pkl')
    print("Pipline Done!")

    train_data = split_by_date(train_eng, dates_train)
    val_data = split_by_date(train_eng, dates_val)
    test_data = test_eng.copy()
    print("number of dates in train = {} , number of dates in validation = {}, number of dates in test = {}".format(
        train_data['date_id'].nunique(),val_data['date_id'].nunique(), test_data['date_id'].nunique()))
    cleaning = True
    if cleaning:
        import gc
        del train_eng, test_eng
        gc.collect()

if train_models:
    if val_data.empty:
        print("--------------test data is empty so adjusting the last date for test-----------------")
        val_data = train_data.query("date_id == 480").copy()
    if is_rnn:
        train_batches, train_targets = second_pass_for_rnn(train_data, rnn_numerical_features, rnn_categorical_features, window_size)
        val_batches, val_targets  = second_pass_for_rnn(val_data, rnn_numerical_features, rnn_categorical_features, window_size)
        test_batches, test_targets = second_pass_for_rnn(test_data, rnn_numerical_features, rnn_categorical_features, window_size)
        print(f"train batches shape:{train_batches.shape}")


if train_models:
    directory = os.path.dirname(models_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    if is_rnn:
        callbacks = [BestScoresCallback()]  # Always include BestScoresCallback
        if dates_train[1] != 480:    #if train online, use all data don't set early stopping.
            early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=False)
            callbacks.append(early_stopping)
        if True or tpu_strategy:
            # with tpu_strategy.scope():
            rnn_models = []
            for i in range(num_models['rnn']):
                print(f"Training rnn model {i+1} out of {num_models['rnn']} with seed {42+i}")
                print("---------------------------------------")
                set_all_seeds(42+i)
                rnn_model = create_lstm_model_with_residual(window_size, rnn_numerical_features, initial_learning_rate=rnn_lr)
                history = rnn_model.fit(
                    train_batches,
                    train_targets,
                    validation_data=(val_batches, val_targets),
                    epochs=rnn_ep,
                    batch_size=rnn_bs,
                    callbacks=callbacks)
                print("---------------------------------------")
                rnn_model.save(f'{models_path}lstm_model_seed_{i}.h5')
                rnn_models.append(rnn_model)

            valid_predictions = make_predictions(rnn_models, val_batches,model = 'nn')
            test_predictions = make_predictions(rnn_models, test_batches,model = 'nn')
            # total params: 471639
            print(f"Ensemble Validation data Mean Absolute Error: {mean_absolute_error(val_targets, valid_predictions):.4f}.")
            print(f"Ensemble Test data Mean Absolute Error: {mean_absolute_error(test_targets, test_predictions):.4f}.")


def clean_format(df):
    df['target'] = df['target'].astype('float64')
    for feat in ['stock_id','date_id','seconds_in_bucket']:
        df[feat] = df[feat].astype('int64')
    return df


def clean_up(df):
    df = df[['stock_id','revealed_date_id','seconds_in_bucket','revealed_target']].rename(columns={'revealed_date_id': 'date_id', 'revealed_target': 'target'})
    df['target'].fillna(-0.06020069, inplace=True)
    df = clean_format(df)
    return df


def manage_buffer(buffer, df, max_lag):
    if buffer.empty:
        return df.copy()
    elif buffer['iteration'].nunique() < max_lag:
        return pd.concat([buffer, df], ignore_index=True)
    else:
        oldest_iteration = buffer['iteration'].min()
        buffer = buffer[buffer['iteration'] > oldest_iteration]
        return pd.concat([buffer, df], ignore_index=True)


def append_target_lags(df, target_buffer, lags):

    column_to_lag = 'target'
    df_lagged = df.copy()
    for lag in lags:
        temp_df = target_buffer.copy()
        temp_df['date_id'] = temp_df['date_id'] + lag
        temp_df.rename(columns={column_to_lag: f'lag{lag}_{column_to_lag}'}, inplace=True)
        df_lagged = pd.merge(df_lagged, temp_df[['stock_id', 'date_id', 'seconds_in_bucket', f'lag{lag}_{column_to_lag}']],
                             on=['stock_id', 'date_id', 'seconds_in_bucket'],
                             how='left')
    return df_lagged


if kaggle:
    import gc
    del train
    gc.collect()

if is_inference:
    if online_learning:
        # rnn
        online_rnn_lr_rate = 2e-4  # 2e-4
        online_rnn_batch_size = 2 ** 14  # 2**12 reduced for memory  #8192
        online_rnn_epochs = 4  # 2

    if kaggle:
        import optiver2023
        env = optiver2023.make_env()
        iter_test = env.iter_test()
    else:
        env = MockApi()
        iter_test = env.iter_test()

    if load_models:
        if is_rnn:
            print("loading rnn models...")
            loaded_data = load_pickle(f'{models_path}lstm_all_data.pkl')
            rnn_scaler = loaded_data["rnn_scaler"]
            rnn_medians = loaded_data["rnn_medians"]
            rnn_categorical_features = loaded_data["rnn_categorical_features"]
            rnn_numerical_features = loaded_data["rnn_numerical_features"]
            rnn_models = []
            for i in range(num_models['rnn']):
                loaded_model = load_model(f"{models_path}lstm_model_seed_{i}.h5")
                rnn_models.append(loaded_model)
            print("Done!")

    # ---------------------------buffer management ---------------------------
    max_target_lag = num_of_target_lags
    i = 0
    target_counter = 0
    target_buffer = pd.DataFrame()
    total_test = pd.DataFrame()
    daily_online = pd.DataFrame()
    # ---------------------------buffer management ---------------------------

    for (test, revealed_targets, sample_prediction) in iter_test:
        test = convert_price_cols_float32(test)
        if test.seconds_in_bucket.iloc[0] == 0:   #每天second_in_bucket==0的时候用昨天一整天的数做online learning
            # ----------------------------- storing previous targets -------------------------
            revealed_targets = clean_up(revealed_targets)
            revealed_targets['iteration'] = target_counter
            target_buffer = manage_buffer(target_buffer, revealed_targets, max_target_lag)
            target_counter += 1
            if not daily_online.empty and online_learning:
                daily_online.drop(columns='target', inplace=True)
                daily_online = pd.merge(daily_online,
                                        revealed_targets[['stock_id', 'date_id', 'seconds_in_bucket', 'target']],
                                        on=['stock_id', 'date_id', 'seconds_in_bucket'],
                                        how='inner')
                if is_rnn:
                    online_batches, online_targets = online_pass_for_rnn(daily_online, rnn_numerical_features,
                                                                         rnn_categorical_features, window_size)
                    for rnn_model in rnn_models:
                        lr_schedule = ExponentialDecay(initial_learning_rate=online_rnn_lr_rate, decay_steps=10000,
                                                       decay_rate=0.8, staircase=True)
                        optimizer = Adam(learning_rate=lr_schedule)
                        rnn_model.compile(optimizer=optimizer, loss="mean_absolute_error")
                        rnn_model.fit(online_batches, online_targets, epochs=online_rnn_epochs,
                                      batch_size=online_rnn_batch_size)
                        K.clear_session()
                        gc.collect()

            daily_online = pd.DataFrame()
            # ----------------------------- storing previous targets -------------------------
        test['target'] = 0
        test = compute_imbalances(test, columns_sizes, prefix='_sz_')
        test = compute_imbalances(test, columns_prices, prefix='_pr_')
        test = append_target_lags(test, target_buffer, target_lags)

        if not daily_online.empty:
            full_data = pd.concat([daily_online[test.columns], test], ignore_index=True)
        else:
            full_data = test

        # getting back to test size
        test = full_data.iloc[-test.shape[0]:].copy()
        if test.currently_scored.iloc[0]:
            if is_rnn:
                X_test, _ = second_pass_for_rnn(full_data, rnn_numerical_features, rnn_categorical_features, window_size, is_inference=True)
                test['target'] += make_predictions(rnn_models, X_test, model='nn').flatten()

        if not kaggle:
            total_test = pd.concat([total_test, test], ignore_index=True)
        daily_online = pd.concat([daily_online, test], ignore_index=True)
        sample_prediction = pd.merge(sample_prediction.drop(columns='target'), test[['row_id', 'target']],on=['row_id'], how='left')
        sample_prediction['target'].fillna(0, inplace=True)
        env.predict(sample_prediction)
        i += 1