"""
CPU pytorch cannot work, needs downloading pytorch 2.0.0 with cu117
"""
import pandas as pd
import numpy as np
import os
import torch
import torch.nn as nn
import warnings
import multiprocessing
import time
import traceback
import gc
import joblib
import random

from torch.utils import data
from torch.utils.data import Dataset
from datetime import datetime
from tqdm import tqdm
from numba import njit, prange
from itertools import combinations
from contextlib import contextmanager
from sklearn.base import BaseEstimator, TransformerMixin

warnings.filterwarnings("ignore")
pd.set_option('display.max_rows', 60)
pd.set_option('display.max_columns', None)
torch.__version__  #'1.13.0+cpu'
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
torch.use_deterministic_algorithms(False)
random.seed(0)
np.random.seed(0)
torch.manual_seed(0)
base_path = r'drive/MyDrive/Kaggle/Optiver/NN'
feature_save_path = 'feature'
T=12
batch_size = 4096
d_model = 48
nhead = 2
num_layers = 1
lr = 1e-7 * batch_size / 8
n_epochs = 25


# 填补空值far_price，near_price，返回三个结果
def imputer(df):
    df['far_price'] = df['far_price'].fillna(0)
    df['near_price'] = df['near_price'].fillna(0)
    return df, 0, 0

# 补充缺失的行
def add_missing_data(df):
    all_stock_ids = set(range(200))
    all_missed_data_list = []
    # 将数据预先进行分组，以便我们可以快速访问每个time_id的相关数据
    grouped = df.groupby('time_id')
    for t, group in grouped:
        current_stock_ids = set(group['stock_id'].to_list())
        missed_stock_id = list(all_stock_ids - current_stock_ids)
        date_id = group['date_id'].iloc[-1]
        seconds_in_bucket = group['seconds_in_bucket'].iloc[-1]
        missed_stock_id_num = len(missed_stock_id)
        missed_date_id = [date_id] * missed_stock_id_num
        missed_seconds_in_bucket = [seconds_in_bucket] * missed_stock_id_num
        missed_time_id = [t] * missed_stock_id_num
        missed_data = pd.DataFrame({
            'stock_id': missed_stock_id,
            'date_id': missed_date_id,
            'seconds_in_bucket': missed_seconds_in_bucket,
            'time_id': missed_time_id
        })
        all_missed_data_list.append(missed_data)
    all_missed_data = pd.concat(all_missed_data_list, axis=0).reset_index(drop=True).astype(int)
    df = pd.concat([df, all_missed_data], axis=0)
    df = df.sort_values(by=['time_id', 'stock_id']).reset_index(drop=True)
    df = df.groupby('stock_id').apply(lambda x: x.fillna(method='ffill')).reset_index(drop=True)
    return df


def reduce_mem_usage(df, verbose=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64', 'int64[pyarrow]', 'double[pyarrow]',
                'Int16', 'Int32', 'Int64', 'Float16', 'Float32', 'Float64']
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtypes
        if col_type in numerics:
            try:
                c_min = df[col].min()
                c_max = df[col].max()
                if str(col_type)[:3] in ['int', 'Int']:
                    if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                        df[col] = df[col].astype(np.int8)
                    elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                        df[col] = df[col].astype(np.int16)
                    elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                        df[col] = df[col].astype(np.int32)
                    elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                        df[col] = df[col].astype(np.int64)
                else:
                    if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:   #之前commet
                        df[col] = df[col].astype(np.float32)
                    elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                        df[col] = df[col].astype(np.float32)
                    else:
                        df[col] = df[col].astype(np.float64)
            except: #columns all nan
                df[col] = df[col].astype(np.float32)
    end_mem = df.memory_usage().sum() / 1024**2
    return df


def log_return(series: np.ndarray, window):
    return np.log(series).diff(window)


@njit(cache=True)
def realized_volatility(series):
    return np.sqrt(np.nanmean(series**2))


@njit(cache=True)
def compute_triplet_imbalance(df_values, comb_indices):
    '''
    (max-mid)/(mid-min), min/max
    '''
    num_rows = df_values.shape[0]
    num_combinations = len(comb_indices)
    imbalance_features = np.empty((num_rows, 2*num_combinations))

    for i in prange(num_combinations):
        a, b, c = comb_indices[i]
        for j in range(num_rows):
            max_val = max(df_values[j, a], df_values[j, b], df_values[j, c])
            min_val = min(df_values[j, a], df_values[j, b], df_values[j, c])
            mid_val = df_values[j, a] + df_values[j, b] + df_values[j, c] - min_val - max_val
            imbalance_features[j, 2*i] = (max_val - mid_val) / max(mid_val - min_val, 1e-6)
            imbalance_features[j, 2*i+1] = min_val/max(max_val, 1e-6)
    return imbalance_features


def calculate_triplet_imbalance_numba(price, df):
    df_values = df[price].values
    comb_indices = [(price.index(a), price.index(b), price.index(c)) for a, b, c in combinations(price, 3)]
    features_array = compute_triplet_imbalance(df_values, comb_indices)
    temp = [[f"{a}_{b}_{c}_imb2", f"{a}_{b}_{c}_imb3"] for a, b, c in combinations(price, 3)]
    columns = sum(temp, [])
    features = pd.DataFrame(features_array, columns=columns)
    return features


class OptiverFeaturizer(BaseEstimator, TransformerMixin):
    def __init__(self, config):
        # configurations
        self.config = config
        self.target = self.config.target
        temp = ['dispersion_diff', 'slope_ask', 'reference_price_bid_price_wap_imb7','reference_price_ask_price_wap_imb7', 'reference_price_bid_price_wap_imb9',
        'reference_price_wap_imb']
        orig_price_vol_num_vars = ['reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price', 'bid_price','bid_size', 'ask_price', 'ask_size', 'wap']
        additial_columns = orig_price_vol_num_vars + ['mid_price', 'swap_price', 'total_volume1', 'total_volume2', 'flow']
        self.roll_cols = list(set(temp + additial_columns))

        if self.config.USE_PRECOMPUTE_VARS_DICT:
            self.vars_dict = joblib.load(f'{self.config.MY_Path}/vars_dict1.pkl')


    def basic_feat_eng(self, df):
        df = df.sort_values(by=['date_id', 'seconds_in_bucket', 'stock_id']).reset_index(drop=True)
        sizes = ["matched_size", "bid_size", "ask_size", "imbalance_size"]
        df['tick_diff'] = df.groupby(['date_id', 'stock_id'])['wap'].diff()
        df['mid_price'] = (df['ask_price'] + df['bid_price']) / 2
        df['swap_price'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / (df['bid_size'] + df['ask_size'])
        df['total_volume1'] = df['ask_size'] + df['bid_size']
        df['total_volume2'] = df['matched_size'] + df['imbalance_size']
        df['imb_s1'] = (df['bid_size'] - df['ask_size']) / (df['bid_size'] + df['ask_size'])
        df['imb_s2'] = (df['imbalance_size'] - df['matched_size']) / (df['matched_size'] + df['imbalance_size'])
        df['imb_s3'] = (df['bid_price'] * df['bid_size'] + df['ask_price'] * df['ask_size']) / (
                df['bid_price'] * df['bid_size'] - df['ask_price'] * df['ask_size'])
        df['imbalance_ratio'] = df['imbalance_size'] / df['matched_size']
        df['slope_bid'] = df['bid_size'] / ((df['bid_size'] + df['ask_size']) / 2 + 1)
        df['slope_ask'] = df['ask_size'] / ((df['bid_size'] + df['ask_size']) / 2 + 1)
        prices = ['reference_price', 'far_price', 'near_price', 'ask_price', 'bid_price', 'wap']
        interactive_num_vars = []

        # all prices pairs filter correlation > 0.9
        # (x-y)/(x+y)
        df['ask_price_wap_imb'] = (df['ask_price'] - df['wap']) / (df['ask_price'] + df['wap'])
        df['reference_price_wap_imb'] = (df['reference_price'] - df['wap']) / (df['reference_price'] + df['wap'])
        df['reference_price_bid_price_imb'] = (df['reference_price'] - df['bid_price']) / (
                    df['reference_price'] + df['bid_price'])

        # 1/(1/x+1/y)
        df['far_price_bid_price_imb4'] = 1 / (1 / df['far_price'] + 1 / df['bid_price'])
        df['reference_price_near_price_imb4'] = 1 / (1 / df['reference_price'] + 1 / df['near_price'])
        interactive_num_vars += ['ask_price_wap_imb', 'reference_price_wap_imb', 'reference_price_bid_price_imb',
                                 'far_price_bid_price_imb4', 'reference_price_near_price_imb4']

        # z/(x+y), (x-y)/z
        for c in [
            ('reference_price', 'bid_price', 'wap'), ('reference_price', 'ask_price', 'wap'),
            ('far_price', 'near_price', 'bid_price'),
            ('reference_price', 'ask_price', 'bid_price'), ('ask_price', 'bid_price', 'wap'),
            ('reference_price', 'near_price', 'bid_price'),
            ('reference_price', 'near_price', 'ask_price'), ('reference_price', 'far_price', 'bid_price'),
            ('reference_price', 'near_price', 'wap')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb5'] = 2 * df[c[0]] / (df[c[1]] + df[c[2]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb5']

        for c in [
            ('far_price', 'near_price', 'wap'), ('near_price', 'ask_price', 'bid_price'),
            ('far_price', 'near_price', 'ask_price'),
            ('far_price', 'near_price', 'bid_price'), ('reference_price', 'far_price', 'ask_price'),
            ('far_price', 'ask_price', 'bid_price'),
            ('reference_price', 'ask_price', 'wap'), ('reference_price', 'bid_price', 'wap'),
            ('ask_price', 'bid_price', 'wap'),
            ('reference_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb6'] = 2 * df[c[1]] / (df[c[0]] + df[c[2]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb6']

        for c in [
            ('reference_price', 'ask_price', 'wap'), ('reference_price', 'bid_price', 'wap'),
            ('near_price', 'ask_price', 'wap'),
            ('reference_price', 'near_price', 'wap'), ('far_price', 'bid_price', 'wap'),
            ('far_price', 'ask_price', 'wap'),
            ('reference_price', 'near_price', 'ask_price'), ('reference_price', 'near_price', 'bid_price'),
            ('near_price', 'ask_price', 'bid_price'),
            ('reference_price', 'far_price', 'near_price'), ('far_price', 'ask_price', 'bid_price'),
            ('reference_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb7'] = 2 * df[c[2]] / (df[c[0]] + df[c[1]])
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb7']

        for c in [
            ('reference_price', 'near_price', 'bid_price'), ('reference_price', 'far_price', 'wap'),
            ('reference_price', 'bid_price', 'wap')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb8'] = (df[c[0]] - df[c[1]]) / df[c[2]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb8']

        for c in [
            ('reference_price', 'bid_price', 'wap'), ('reference_price', 'near_price', 'ask_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb9'] = (df[c[0]] - df[c[2]]) / df[c[1]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb9']

        for c in [
            ('ask_price', 'bid_price', 'wap'), ('far_price', 'ask_price', 'bid_price')
        ]:
            df[f'{c[0]}_{c[1]}_{c[2]}_imb10'] = (df[c[1]] - df[c[2]]) / df[c[0]]
            interactive_num_vars += [f'{c[0]}_{c[1]}_{c[2]}_imb10']

        df['if_last5min'] = df['seconds_in_bucket'].apply(lambda x: 1 if x >= 300 else 0)
        df['if_last2min'] = df['seconds_in_bucket'].apply(lambda x: 1 if x >= 480 else 0)
        df['tick_path'] = np.abs(df['tick_diff'] / df['wap'])

        group = df.groupby(['date_id', 'stock_id'], group_keys=False)
        df['bs_lag1'] = group['bid_size'].shift(1)
        df['as_lag1'] = group['ask_size'].shift(1)
        df['b1p_diff1'] = group['bid_price'].diff()
        df['a1p_diff1'] = group['ask_price'].diff()
        df['bid_wap'] = (df['wap'] - df['bid_price']) / df['wap'].clip(1e-6, )
        df['ask_wap'] = (df['ask_price'] - df['wap']) / df['wap'].clip(1e-6, )

        df["imbalance_momentum"] = group['imbalance_size'].diff(periods=1) / df['matched_size']
        df["price_spread"] = df["ask_price"] - df["bid_price"]
        df["spread_intensity"] = group['price_spread'].diff()
        df['price_pressure'] = df['imbalance_size'] * (df['ask_price'] - df['bid_price'])
        df['market_urgency'] = df['price_spread'] * df['imb_s1']
        df['depth_pressure'] = (df['ask_size'] - df['bid_size']) * (df['far_price'] - df['near_price'])

        # Calculate shifted and return features for specific columns
        return_vars, lag_vars, lag_cat_vars, diff_vars, diff_cat_vars = [], [], [], [], []

        group2 = df.groupby(['stock_id'], group_keys=False)
        for col in ['reference_price', 'wap']:
            for window in [1, 2, 3, 10]:
                df[f'log_return_{col}_{window}'] = group2[col].pct_change(window)  #没用log_return
                return_vars.append(f'log_return_{col}_{window}')

        df['matched_size_add1'] = 1+df['matched_size']
        df['imbalance_size_add1'] = 1 + df['imbalance_size']
        for col in ['matched_size', 'imbalance_size']:
            for window in [1, 2, 3, 10]:
                df[f'log_return_{col}_{window}'] = (group2[f"{col}_add1"]).pct_change(window)  #没用log_return
                return_vars.append(f'log_return_{col}_{window}')

        df['imbalance_buy_sell_flag'] = df.imbalance_buy_sell_flag.apply(lambda x: 0 if x == -1 else 1)  # 0,1
        for col in ['imbalance_buy_sell_flag']:
            for window in [1, 2, 3, 10]:
                df[f"{col}_diff_{window}"] = group2[col].diff(window).apply(lambda x: 2 if x == -1 else x) # 0,1,2
                diff_cat_vars += [f"{col}_diff_{window}"]
        df["minute"] = df["seconds_in_bucket"] // 60
        df['tick_up_down'] = np.where(df['tick_diff'] > 0, 2, np.where(df['tick_diff'] < 0, 0, 1))  # 0,1,2
        group2 = df.groupby(['stock_id'], group_keys=False)
        df['flow'] = (
                     df['bid_size'] * np.where(df['b1p_diff1'] >= 0, 1, 0) - df['bs_lag1'] * np.where(
                 df['b1p_diff1'] <= 0, 1, 0)) - (
                     df['ask_size'] * np.where(df['a1p_diff1'] <= 0, 1, 0) - df['as_lag1'] * np.where(
                 df['a1p_diff1'] >= 0, 1, 0)
             )
        df["global_median_size"] = (
                group2["bid_size"].rolling(110, 1).median(engine='numba', engine_kwargs={'nopython': True}).droplevel(0)
                + group2["ask_size"].rolling(110, 1).median(engine='numba', engine_kwargs={'nopython': True}).droplevel(0)
        )
        df['global_std_size'] = (
            group2["bid_size"].rolling(110, 1).std(engine='numba', engine_kwargs={'nopython': True})
            + group2["ask_size"].rolling(110, 1).std(engine='numba', engine_kwargs={'nopython': True})
        )
        df['global_ptp_size'] = (
            group2["bid_size"].rolling(110, 1).max(engine='numba', engine_kwargs={'nopython': True})
            - group2["bid_size"].rolling(110, 1).min(engine='numba', engine_kwargs={'nopython': True})
        )
        df['global_median_price'] = (
                group2["bid_price"].rolling(110, 1).median(engine='numba', engine_kwargs={'nopython': True}).droplevel(0)
                + group2["ask_price"].rolling(110, 1).median(engine='numba', engine_kwargs={'nopython': True}).droplevel(0)
        )
        df['global_std_price'] = (
                group2["bid_price"].rolling(110, 1).std(engine='numba', engine_kwargs={'nopython': True})
                + group2["ask_price"].rolling(110, 1).std(engine='numba', engine_kwargs={'nopython': True})
        )
        df['global_ptp_price'] = (
            group2["bid_price"].rolling(110, 1).max(engine='numba', engine_kwargs={'nopython': True}) - group2[
                "ask_price"].rolling(110, 1).min(engine='numba', engine_kwargs={'nopython': True})
        )

        # all triple pairs filter correlation > 0.9
        # min/max, (max-mid)/(mid-min)
        for c in [['ask_price', 'bid_price', 'wap', 'reference_price'], sizes]:  # imb2, imb3
            triplet_feature = calculate_triplet_imbalance_numba(c, df)
            df[triplet_feature.columns] = triplet_feature.values
            interactive_num_vars += list(triplet_feature.columns)

        # Calculate various statistical aggregation features
        reference_global_vars = []
        prices = ["reference_price", "far_price", "near_price", "ask_price", "bid_price", "wap"]
        for func in ["mean", "std", "skew", "kurt"]:
            df[f"all_prices_{func}"] = df[prices].agg(func, axis=1)
            df[f"all_sizes_{func}"] = df[sizes].agg(func, axis=1)
            reference_global_vars += [f"all_prices_{func}", f"all_sizes_{func}"]

        df.drop(columns=[
            'row_id', 'matched_size_add1', 'imbalance_size_add1', 'bs_lag1', 'as_lag1', 'b1p_diff1', 'a1p_diff1'
        ], inplace=True)

        df = df.replace([np.inf, -np.inf], np.nan)  #正常情况没有np.inf

        orig_price_vol_num_vars = [
            'reference_price', 'matched_size', 'imbalance_size', 'far_price', 'near_price', 'bid_price', 'bid_size',
            'ask_price', 'ask_size', 'wap']

        global_stock_id_vars = ['global_median_size', 'global_std_size','global_ptp_size',  'global_median_price', 'global_std_price', 'global_ptp_price']

        derived_price_vol_num_vars = [
            'tick_diff', 'mid_price', 'swap_price', 'total_volume1', 'total_volume2', 'imb_s1', 'imb_s2', 'imb_s3',
            'imbalance_ratio', 'slope_bid', 'slope_ask', 'tick_path', 'flow', 'bid_wap', 'ask_wap',
            'imbalance_momentum', 'spread_intensity', 'price_pressure', 'market_urgency',
            'depth_pressure'
        ]

        price_vol_cat_vars = ['imbalance_buy_sell_flag', 'if_last5min', 'if_last2min', 'tick_up_down']

        stock_cat_vars = ['stock_id']

        date_num_vars = ['date_id', 'seconds_in_bucket', 'minute']

        cat_features = price_vol_cat_vars + stock_cat_vars + lag_cat_vars + diff_cat_vars

        vars_dict = {
            'orig_price_vol_num_vars': orig_price_vol_num_vars,
            'return_vars': return_vars,
            'diff_vars': diff_vars,
            'lag_vars': lag_vars,
            'lag_cat_vars': lag_cat_vars,
            'interactive_num_vars': interactive_num_vars,
            'derived_price_vol_num_vars': derived_price_vol_num_vars,
            'price_vol_cat_vars': price_vol_cat_vars,
            'stock_cat_vars': stock_cat_vars,
            'date_num_vars': date_num_vars,
            'reference_global_vars': reference_global_vars,
            'global_stock_id_vars': global_stock_id_vars,
            'diff_cat_vars': diff_cat_vars,
            'cat_features': cat_features
        }
        gc.collect()
        return df, vars_dict


    def fit_transform(self, df):
        # Fit transformers that require fitting, e.g. normalizer, one hot encoder etc.
        print('Fitting featurizers...')
        if self.config.USE_PRECOMPUTE_FEATURES:
            self.train_val_data = pd.read_feather(f'{self.config.MY_Path}/basic_features.feather') # contains target, time_id
        else:
            with timer('make basic feature'):  # (, 174)
                fea_basic_df, self.vars_dict = self.basic_feat_eng(df)
        return fea_basic_df


@contextmanager
def timer(name: str):
    s = time.time()
    yield
    elapsed = time.time() - s
    print(f'[{name}] {elapsed: .3f}sec')


def print_trace(name: str = ''):
    print(f'ERROR RAISED IN {name or "anonymous"}')
    print(traceback.format_exc())


class FEATURIZER_CFG:
    """
    Configuration class for feature engineering
    """
    target = 'target'
    Is_Offline = False
    Is_Train = True
    Is_Infer = True
    N_Folds = 5
    USE_PRECOMPUTE_FEATURES = False
    USE_PRECOMPUTE_VARS_DICT = False
    MY_Path = base_path
    N_Jobs = min(multiprocessing.cpu_count(), 32)
    split_day = 435  # Split day for time series data
    DEBUG = False


def get_data(df, T):
    """
    transform data into the specific format.
    :param df: dataframe
    :param T: timestep = 12
    :return: dict, each stock id with samples, each sample shape: (12, 131)
    """
    na_count = df.isna().mean()
    print(na_count.loc[na_count>0])
    df = df.dropna()
    Xs = {}
    ys = {}
    for stock in sorted(df['stock_id'].unique()):
      df_stock = df.loc[df['stock_id']==stock]
      X_samples = []
      y_samples = []
      for date in sorted(df_stock['date_id'].unique()):
        df_stock_date = df_stock.loc[df_stock['date_id']==date].reset_index().drop(columns=["date_id", "index"])
        X_stock_date_array = df_stock_date.drop(columns=["target"]).values
        [N, D] = X_stock_date_array.shape
        X_stock_date_array_padded = np.concatenate([np.zeros((T-1, D)), X_stock_date_array], axis=0)
        #print(date, N, D)
        y_stock_date = df_stock_date["target"].values#[T-1:]
        X_stock_date = np.zeros((N, T, D), dtype=np.float32)
        for i in range(N):
          X_stock_date[i] = X_stock_date_array_padded[i:i+T, :]
          if (i <= T) and (stock == 0) and (date==0):
            print(i, X_stock_date[i])
        X_stock_date = X_stock_date#[T-1:]
        X_samples.append(X_stock_date)
        y_samples.append(y_stock_date)
      X_stock_samples = np.concatenate(X_samples, axis=0)
      y_stock_samples = np.concatenate(y_samples, axis=0)
      Xs[stock] = X_stock_samples
      ys[stock] = y_stock_samples

    return Xs, ys


class TSDataset(Dataset):
    """Characterizes a dataset for PyTorch"""
    def __init__(self, df, T):
        """Initialization"""
        self.T = T
        self.x = None
        self.y = None

        Xs, ys = get_data(df, T)
        x = np.concatenate(list(Xs.values()), axis=0)
        y = np.concatenate(list(ys.values()), axis=0)
        Xs, ys = 0, 0
        gc.collect()
        print()
        print('fetching data: ', x.shape, y.shape)  #(2128700, 12, 131) (2128700,)

        self.length = len(x)

        x = torch.from_numpy(x)
        self.x = x # torch.unsqueeze(x, 1)
        y = torch.from_numpy(y)
        self.y = y # torch.unsqueeze(y, 1)
        gc.collect()

    def __len__(self):
        """Denotes the total number of samples"""
        return self.length

    def __getitem__(self, index):
        """Generates samples of data"""
        return self.x[index], self.y[index]


def fill_na(df_all):
    df_all["far_price_ask_price_bid_price_imb10"] = df_all["far_price_ask_price_bid_price_imb10"].fillna(-1)
    df_all["reference_price_near_price_ask_price_imb9"] = df_all["reference_price_near_price_ask_price_imb9"].fillna(-0.2)
    df_all["tick_diff"] = df_all["tick_diff"].fillna(-0.05)
    df_all["tick_path"] = df_all["tick_path"].fillna(-0.02)
    df_all["imbalance_momentum"] = df_all["imbalance_momentum"].fillna(-20)
    df_all["spread_intensity"] = df_all["spread_intensity"].fillna(-0.02)
    df_all["flow"] = df_all["flow"].fillna(-3e7)
    for col in ['log_return_reference_price_1',
                'log_return_reference_price_2',
                'log_return_reference_price_3',
                'log_return_reference_price_10',
                'log_return_wap_1',
                'log_return_wap_2',
                'log_return_wap_3',
                'log_return_wap_10',
                ]:
        df_all[col] = df_all[col].fillna(-0.1)
    for col in ['log_return_matched_size_1',
                'log_return_matched_size_2',
                'log_return_matched_size_3',
                'log_return_matched_size_10',
                'log_return_imbalance_size_1',
                'log_return_imbalance_size_2',
                'log_return_imbalance_size_3',
                'log_return_imbalance_size_10',
                'imbalance_buy_sell_flag_diff_1',
                'imbalance_buy_sell_flag_diff_2',
                'imbalance_buy_sell_flag_diff_3',
                'imbalance_buy_sell_flag_diff_10',
                ]:
        df_all[col] = df_all[col].fillna(-1)
    for col in ["global_std_size", "global_std_price"]:
        df_all[col] = df_all[col].fillna(-1)
    return df_all


class MyModel(nn.Module):
    def __init__(self, feature_num, d_model, nhead, num_layers):
        super(MyModel, self).__init__()
        self.embedding = nn.Linear(feature_num, d_model)  #change the shape from (, 12, 131) to (, 12*131, 1) then to (, 48, 1)
        self.tf1 = nn.Transformer(d_model=d_model, nhead=nhead, num_encoder_layers=num_layers, batch_first=True) #make sure the first dimension of input is batch size
        self.fc = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(0.5)
        self.tf2 = nn.Transformer(d_model=d_model, nhead=nhead, num_encoder_layers=num_layers, batch_first=True)
        self.decoder = nn.Linear(d_model, 1)

    def forward(self, x):
        x = self.embedding(x)
        x = self.tf1.encoder(x)
        x = x[:, -1, :]  #只要time step Tth vector, (, d)
        x = self.fc(x)
        x = self.dropout(x)
        x = self.tf2.encoder(x)
        x = self.decoder(x)
        return x.squeeze(-1)

# A function to encapsulate the training loop
def batch_gd(model, criterion, optimizer, train_loader, test_loader, epochs, patience=2, fold=None, save=True):

    train_losses = np.zeros(epochs)
    test_losses = np.zeros(epochs)
    best_test_loss = np.inf
    best_test_epoch = 0
    patience_counter = 0
    pre_test_loss = np.inf

    for it in tqdm(range(epochs)):
        model.train()
        t0 = datetime.now()
        train_loss = []
        for inputs, targets in train_loader:
            # zero the parameter gradients
            optimizer.zero_grad()
            # move data to GPU
            inputs, targets = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float)
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1)
            optimizer.step()
            train_loss.append(loss.item())
        # Get train loss and test loss
        train_loss = np.mean(train_loss) # a little misleading
        model.eval()
        test_loss = []
        with torch.no_grad():
          for inputs, targets in test_loader:
              inputs, targets = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float)
              outputs = model(inputs)
              loss = criterion(outputs, targets)
              test_loss.append(loss.item())
        test_loss = np.mean(test_loss)
        # Save losses
        train_losses[it] = train_loss
        test_losses[it] = test_loss
        # 前一轮mae必须小于当前mae，否则学习率减半
        if test_loss - pre_test_loss > 0:
            patience_counter += 1
            if patience_counter == patience:
                patience_counter = 0
                for param_group in optimizer.param_groups:
                    param_group['lr'] = param_group['lr'] * 0.5  # 更新学习率
                    print(f'renew lr to {param_group["lr"]}')

        # 更新mae
        pre_test_loss = test_loss
        if test_loss < best_test_loss:
          if save:
            torch.save(model, f'{base_path}/best_val_model_pytorch_1_{fold}_tail_110')
            print('model saved')
          best_test_loss = test_loss
          best_test_epoch = it
        dt = datetime.now() - t0
        print(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4e}, \
          Validation Loss: {test_loss:.4e}, Duration: {dt}, Best Val Epoch: {best_test_epoch}')
    return train_losses, test_losses


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)

feature_cols = joblib.load(f"{feature_save_path}/feats_name_transformer_1217")
cfg = FEATURIZER_CFG()
featurizer = OptiverFeaturizer(FEATURIZER_CFG)


# train_data = pd.read_csv(r'train.csv')
# train_data, _, _ = imputer(train_data)
# train_data = featurizer.fit_transform(train_data).dropna(subset=["target"])
# train_data = fill_na(train_data)
# train_data.reset_index(drop = True).to_feather('feature/transformer_featured_data.feather')

train_data = pd.read_feather(f"feature/transformer_featured_data.feather")
avg = pd.read_csv(f"feature/avg_tail_110.csv")
avg = avg.set_index("Unnamed: 0")["0"]
std = pd.read_csv(f"feature/std_tail_110.csv")
std = std.set_index("Unnamed: 0")["0"]
train_data = train_data.loc[train_data["seconds_in_bucket"] < 275]
train_data[feature_cols] = (train_data[feature_cols] - avg[feature_cols])/std[feature_cols]
gc.collect()

df_train = train_data.copy()
# The total number of date_ids is 480, we split them into 5 folds with a gap of 5 days in between
df_train_target = df_train['target']
# We need to use the date_id from df_train to split the data
df_train_date_ids = df_train['date_id']
num_folds, gap = 5, 2
fold_size = 480 // num_folds
fold_set = {0: [0, 96], 1: [97, 193], 2: [194, 290], 3: [291, 387], 4: [388, 480]}
train_idx, validation_idx = [], []
for i in range(5):
    vmin, vmax = fold_set[i][0], fold_set[i][1]
    train_idx.append(df_train.loc[(df_train_date_ids<vmin)|(df_train_date_ids>vmax+gap)].index.to_list())
    validation_idx.append(df_train.loc[(df_train_date_ids>=vmin)&(df_train_date_ids<=vmax)].index.to_list())
cv_fold = zip(train_idx, validation_idx)
models, scores = [], []

for i in range(num_folds):
    train_indices, valid_indices = train_idx[i], validation_idx[i]
    fold_train = df_train.loc[train_indices]
    fold_valid = df_train.loc[valid_indices]
    dataset_train =TSDataset(fold_train[feature_cols + ["date_id", "target"]], T)
    dataset_val = TSDataset(fold_valid[feature_cols + ["date_id", "target"]], T)
    gc.collect()
    train_loader = torch.utils.data.DataLoader(dataset=dataset_train, batch_size=batch_size, shuffle=True, num_workers=min(32, os.cpu_count() - 1))
    val_loader = torch.utils.data.DataLoader(dataset=dataset_val, batch_size=batch_size, shuffle=False, num_workers=min(32, os.cpu_count() - 1))
    gc.collect()
    print(f"Fold {i+1} Model Training")
    # Train a TabNet model for the current fold
    feature_num = dataset_train.x.shape[-1]  #131
    model = MyModel(feature_num=feature_num, d_model=d_model, nhead=nhead, num_layers=num_layers).to(device)
    criterion = nn.L1Loss().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
    train_losses, val_losses = batch_gd(model, criterion, optimizer,
                                        train_loader, val_loader, epochs=n_epochs, fold=i)
    # Append the model to the list
    models.append(model)
    # Free up memory by deleting fold specific variables
    del fold_train
    # Evaluate model performance on the validation set
    fold_score = min(val_losses)
    scores.append(fold_score)
    print(f"Fold {i+1} MAE: {fold_score}")
    # Free up memory by deleting fold specific variables
    del fold_valid
    gc.collect()

# Now 'models' holds the trained models for each fold and 'scores' holds the validation scores
print(f"Average MAE across all folds: {np.mean(scores)}")

dataset_train =TSDataset(train_data[feature_cols + ["date_id", "target"]], T)
train_loader = torch.utils.data.DataLoader(dataset=dataset_train, batch_size=batch_size, shuffle=True, num_workers=os.cpu_count() - 1)


feature_num = dataset_train.x.shape[-1]
model = MyModel(feature_num=feature_num, d_model=d_model, nhead=nhead, num_layers=num_layers).to(device)

criterion = nn.L1Loss().to(device)
lr = 1e-7 * batch_size / 8
n_epochs = 20
optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
#use all in sample data to train a model without early stopping and no validation. 
train_losses, test_losses = batch_gd(model, criterion, optimizer,train_loader, train_loader, epochs=n_epochs,
                                     patience=100, fold=None, save=False)
torch.save(model, f'{base_path}/best_val_model_pytorch_1_tail_110')