Some top solutions which I can learn:

1. feature-elimination-by-catboost.ipynb: catboost feature elimination

2. CNN and LSTM model (score: 3.34-3.35) (needs running step by step)
https://www.kaggle.com/competitions/optiver-trading-at-the-close/discussion/462639#2568891

3. Features can learn:
https://www.kaggle.com/competitions/optiver-trading-at-the-close/discussion/462664#2573648

4. post processing:
prediction- weighted mean, so that weighted sum after post-processing will be 0. 

5. Insights on Market Urgency: 
https://www.kaggle.com/competitions/optiver-trading-at-the-close/discussion/462708#2569383
market_urgency_v2: mid price - wap(micro price)
market_urgency = -2 market_urgency_v2

6. what worked and what not worked (79th Public LB)
https://www.kaggle.com/competitions/optiver-trading-at-the-close/discussion/462653

7. pytorch TFT example code(not for this competition)
https://www.kaggle.com/code/tomwarrens/temporal-fusion-transformer-in-pytorch/notebook

8. Latest NVIDIA cuDF fully supports Pandas with 150x speedup! No code changes needed!
https://www.kaggle.com/competitions/optiver-trading-at-the-close/discussion/454454#2527151

9. some features about the technical indicators of WAP. 
https://www.kaggle.com/code/shubhamcodez/exploring-the-relation-between-wap-and-target

10.pytorch transformer LB: 5.358
https://www.kaggle.com/competitions/optiver-trading-at-the-close/discussion/455468#2533323
https://www.kaggle.com/code/jirkaborovec/optiver-gpu-speedsup-feature-eng-torch-dnn

11. numba build rolling features
https://www.kaggle.com/code/wenxuanxx/faster-function-build-feature

12. Technical Indicators
https://www.kaggle.com/competitions/optiver-trading-at-the-close/discussion/454179
