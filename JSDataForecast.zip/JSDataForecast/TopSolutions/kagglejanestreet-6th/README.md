# Kaggle Jane Street Real-Time Market Data Forecasting

Solution for the [Jane Street 2024 Kaggle competition](https://www.kaggle.com/competitions/jane-street-real-time-market-data-forecasting/overview).

A detailed description can be found in [`solution.md`](solution.md) and in [Kaggle discussion](https://www.kaggle.com/competitions/jane-street-real-time-market-data-forecasting/discussion/556542).

## Requirements

- ~100GB RAM
- 12GB GPU RAM

## Usage

1. Install requirements from [`pyproject.toml`](pyproject.toml).
2. Download the dataset from [Kaggle](https://www.kaggle.com/competitions/jane-street-real-time-market-data-forecasting/data).
3. Set paths and other config variables in [`janestreet/config.py`](janestreet/config.py).

### Scripts

- [`run_cv.py`](scripts/python/run_cv.py) - Estimate model on cross-validation.
- [`run_full.py`](scripts/python/run_full.py) - Estimate model for the final submission (on the whole sample).
- [`run_ensemble.py`](scripts/python/run_ensemble.py) - Evaluate ensemble of models on CV.
- [`run_test_gap.py`](scripts/python/run_test_gap.py) - Test model on a sample of the last 200 dates with a gap of 200 dates.

#### Additional scripts

- [`monitor_kaggle.py`](scripts/python/monitor_kaggle.py) - Monitor kaggle submissions and send notifications when completed.
- [`update_kaggle.py`](scripts/python/update_kaggle.py) - Push code and models to Kaggle datasets to be used in submission.


model structure design 巧妙的地方:
1. 每个data sample是一天的数 每一天的symbol id * time id * number of features. 然后train和validation的时候batch size ==1. 
intuition behind this:
"I suspect this is due to the fact that the data is super non-stationary and when you mix sequences from different date_ids,
 it may confuse the model. Another side effect will be it's hard to copy this mode for online learning, since the new data is 
 coming date_id by date_id. One thing I observed when I prepared each batch from different date_ids is it's very easy to be 
 overfitting, while for feeding data date_id by date_id, you could even see the train loss increase for some epochs."
2. Add auxiliary labels. tain responders 6, responder 7, responder 8, respomder 9(pl.col("responder_8").shift(-4).over("symbol_id")
    ).fill_null(0.0)) and responder 10(pl.col("responder_6").shift(-40).over("symbol_id")
    ).fill_null(0.0)) together. loss 是这5个Loss的和。output_y的最后一层是这4个auxiliary 的线性加权。 
3. pytorch GRU model 