import pandas as pd
import polars as pl
import numpy as np
import os, gc
import pickle
import torch
import torch.nn as nn
import torch.nn.functional as F
import logging
from torch.utils.data import Dataset
from sklearn.metrics import r2_score
from torchsummary import summary
from tqdm.auto import tqdm
from matplotlib import pyplot as plt
from sklearn.preprocessing import StandardScaler
from multiprocessing import Pool
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')
pd.options.display.max_columns = None
import sys
sys.path.append("/root")
import kaggle_evaluation.jane_street_inference_server

"""
Changes:
1. add time id related features
"""

class CONFIG:
    seed = 42
    target_col = "responder_6"
    lag_cols_original = ["date_id", "symbol_id"] + [f"responder_{idx}" for idx in range(9)]
    nolag_to_lag_rename = { f"responder_{idx}" : f"responder_{idx}_lag_1" for idx in range(9)}
    start_dt = 900
    gap = 1 # make sure there is no info overlap between train and validation, set it as 1 since we only use lag 1
    rnn_categorical_features_dict = {"feature_09": 23, "feature_10":10 , "feature_11":31} #{feature_name: dictionary size}
    categorical_features = (list(rnn_categorical_features_dict.keys())).copy()
    numerical_features = [f"feature_{i:02d}" for i in range(79) if i not in [9, 10, 11]]\
        + [f"responder_{idx}_lag_1" for idx in range(9)] \
        +  ['sin_time_id', 'cos_time_id', 'sin_time_id_halfday', 'cos_time_id_halfday']
    feature_names = [f"feature_{i:02d}" for i in range(79)] + [f"responder_{idx}_lag_1" for idx in range(9)] + ['sin_time_id', 'cos_time_id', 'sin_time_id_halfday', 'cos_time_id_halfday']
    label_name = 'responder_6'
    features_label_name = feature_names + [label_name]
    weight_name = 'weight'
    features_label_weight_name = feature_names + [label_name] + [weight_name]
    model_version = "v2.6"
    model_path = f"model_{model_version}"
    input_path = 'autodl-tmp' if os.path.exists('autodl-tmp') else '/kaggle/input/jane-street-real-time-market-data-forecasting'
    split_date = 1600
    
    local_train = False
    online_train = True
    debug = False




class custom_args():
    def __init__(self):
        self.usegpu = True
        self.gpuid = 0
        self.seed = 42
        self.bs = 16384  # 8192
        self.lr = 1e-4   #1e-4
        self.weight_decay = 5e-4
        self.drop_ratio = 0.2
        self.n_hidden = [512, 512, 256]
        self.patience = 15
        self.max_epochs = 80

args = custom_args()

if not os.path.exists(CONFIG.model_path):
    os.makedirs(CONFIG.model_path)


def setup_logger(path, name):
    path_ = f'{path}/'
    if not os.path.exists(path_):
        os.makedirs(path_)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    fhlr = logging.FileHandler(f'{path_}{name}.log')
    fhlr.setFormatter(formatter)
    chlr = logging.StreamHandler()
    chlr.setFormatter(formatter)
    logger.addHandler(chlr)
    logger.addHandler(fhlr)
    return logger, path_


logger_path = 'JSLog'
if not os.path.exists(logger_path):
    os.makedirs(logger_path)
now = datetime.now()-pd.Timedelta('13H')
crrt_time = now.strftime(f"%Y%m%d%H%M")
logger, logger_path = setup_logger(logger_path, name=f"{CONFIG.model_path}_onlinetrain_{CONFIG.online_train}_{crrt_time}")


# checking device
device = torch.device(f'cuda:{args.gpuid}' if torch.cuda.is_available() and args.usegpu else 'cpu')  #cuda:0
accelerator = 'gpu' if torch.cuda.is_available() and args.usegpu else 'cpu'  #gpu
logger.info(f"Device: {device}, Accelerator: {accelerator}")
# device = "cpu"
# accelerator=  "cpu"



def save_pickle(data, file_path):
    # Create the directory if it doesn't exist
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Save the pickle file
    with open(file_path, 'wb') as file:  #the file is opened for writing in binary mode.
        pickle.dump(data, file)
    logger.info(f"Data saved to {file_path}")


def load_pickle(file_path):
    # Load and return the data from the pickle file
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            data = pickle.load(file)
        return data
    else:
        raise FileNotFoundError(f"No such file: {file_path}")
    

"""
Data Processing
"""

"""
train = pl.scan_parquet(f"{CONFIG.input_path}/train.parquet").select(pl.int_range(pl.len(), dtype=pl.UInt32).alias("id"), pl.all(),).with_columns(
    (pl.col(CONFIG.target_col)*2).cast(pl.Int32).alias("label"),).filter(pl.col("date_id").gt(CONFIG.start_dt-10)) #not used "label"
logger.info(f"The Train data length after cut is {train.collect().shape}.")  #(29052584, 95)

lags = train.select(pl.col(CONFIG.lag_cols_original))
lags = lags.rename(CONFIG.nolag_to_lag_rename)
lags = lags.with_columns(
    date_id = pl.col('date_id') + 1,  # lagged by 1 day
    )
lags = lags.group_by(["date_id", "symbol_id"], maintain_order=True).last()  # pick up last record of previous date, as last day's closing price return 
train = train.join(lags, on=["date_id", "symbol_id"],  how="left")
train = train.filter(pl.col("date_id").gt(CONFIG.start_dt-1))
logger.info(f"The Train data length after cut is {train.collect().shape}.")  #(28786384, 104)
end_dt = train.select(pl.col("date_id")).max().collect()["date_id"][0]
start_dt = train.select(pl.col("date_id")).min().collect()["date_id"][0]
train.collect().write_parquet(f"training_startf_{start_dt}.parquet") #start from 1101
"""


"""
df_train_medians = df_train.median()
in_sample_medians = df.median()
data_pickle = {
    "train_medians": df_train_medians,
    "in_sample_medians": in_sample_medians,
}
save_pickle(data_pickle, f'{CONFIG.input_path}/data_pickle.pkl')
"""

def feature_engineer(df: pl.DataFrame):
    """
    1. add some time features
    return: pl.dataframe
    """
    df_copy = df.clone()
    df_copy = df_copy.with_columns([
        (2 * np.pi * pl.col("time_id") / 967).sin().alias("sin_time_id"),
        (2 * np.pi * pl.col("time_id") / 967).cos().alias("cos_time_id"),
        (2 * np.pi * pl.col("time_id") / 483).sin().alias("sin_time_id_halfday"),
        (2 * np.pi * pl.col("time_id") / 483).cos().alias("cos_time_id_halfday"),
    ])
    return df_copy


class CustomDataset(Dataset):
    """Characterizes a dataset for PyTorch, same as pytorch"""
    def __init__(self, df):
        """Initialization"""
        self.features = torch.from_numpy(df[CONFIG.feature_names].values)
        self.labels = torch.from_numpy(df[CONFIG.label_name].values)
        self.weights = torch.from_numpy(df[CONFIG.weight_name].values)
    
    def __len__(self): 
        """Denotes the total number of samples"""
        return len(self.labels)
    
    def __getitem__(self, idx):
        """Generates samples of data"""
        x = self.features[idx]
        y = self.labels[idx]
        w = self.weights[idx]
        return x, y, w

    
# Custom R2 metric for validation
def r2_val(y_true, y_pred, sample_weight):
    r2 = 1 - np.average((y_pred - y_true) ** 2, weights=sample_weight) / (np.average((y_true) ** 2, weights=sample_weight) + 1e-38)
    return r2

        


class NN(nn.Module): #~440k parameters
    def __init__(self, input_dim, hidden_dims, drop_ratio, device):
        super().__init__()
        self.device = device
        layers = []
        in_dim = input_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(in_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(num_features=hidden_dim))
            layers.append(nn.SiLU())
            layers.append(nn.Dropout(drop_ratio))
            in_dim = hidden_dim
        layers.append(nn.Linear(in_dim, 1))
        layers.append(nn.Tanh())
        self.model = nn.Sequential(*layers)
        self.to(self.device)  # Move the model to the specified device



    def forward(self, x):
        x = x.to(self.device)
        return 5 * self.model(x).squeeze(-1)



# A function to encapsulate the training loop with early stopping and learning rate scheduler
def batch_gd(model, criterion, optimizer, scheduler, train_loader, test_loader, epochs, patience=10, save=True, save_path=None):

    train_losses = np.zeros(epochs)
    test_losses = np.zeros(epochs)
    
    best_test_loss = np.inf
    best_test_epoch = 0
    patience_counter = 0

    for it in tqdm(range(epochs)):
        model.train()
        t0 = datetime.now()
        train_loss_it = []
        for inputs, targets, weights in train_loader:
            optimizer.zero_grad() # zero the parameter gradients
            inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
            outputs = model(inputs)
            loss = criterion(outputs, targets) * weights #if reduction is none, it is a vector (w_i*(yi-yi_hat)**2, ..., ..., )
            loss = loss.mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5)
            optimizer.step()
            train_loss_it.append(loss.item()) 
        
        # Get train loss and test loss
        train_loss = np.mean(train_loss_it) 
        
        if epochs == 1: #no need to adjust lr
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4f}, Duration: {datetime.now() - t0}. ')

        else:
            model.eval()
            test_loss_it = []
            with torch.no_grad():
                for inputs, targets, weights in test_loader:
                    inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
                    outputs = model(inputs)
                    loss = criterion(outputs, targets) * weights
                    loss = loss.mean()
                    test_loss_it.append(loss.item())
            test_loss = np.mean(test_loss_it)

            # Save losses
            train_losses[it] = train_loss
            test_losses[it] = test_loss
            
            # Update the scheduler
            scheduler.step(test_loss)

            # Check for early stopping
            if test_loss < best_test_loss:
                patience_counter = 0
                best_test_loss = test_loss
                best_test_epoch = it
                if save:
                    torch.save(model.state_dict(), f'{CONFIG.model_path}/{save_path}')
                    logger.info('Model saved.')
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    logger.info('Early stopping.')
                    break

            dt = datetime.now() - t0
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4e},  Validation Loss: {test_loss:.4e}, Duration: {dt}, Best Val Epoch: {best_test_epoch}')
    
    return train_losses, test_losses



def plot_epochs_loss(data_path, save_path, loss_type, save = True):
    train_temp, valid_temp =  load_pickle(data_path)
    loss_idx = np.where(train_temp>0)
    train_losses, valid_losses = train_temp[loss_idx], valid_temp[loss_idx]
    epochs = range(1, len(train_losses) + 1)
    plt.figure(figsize=(10, 6))
    if loss_type == "train":
        plt.plot(epochs, train_losses, 'b-', label='Training Loss')
        plt.title(' train Loss')
    elif loss_type == "valid":
        plt.plot(epochs, valid_losses, 'r-', label='Validation Loss')
        plt.title(' Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
    if save:
        plt.savefig(save_path)



def predict_in_batches(model, x_valid, batch_size, device):
    """
    x_valid: np.array
    """
    model.eval()
    predictions = []
    total_samples = len(x_valid)
    try:
        with torch.no_grad():
            for i in range(0, total_samples, batch_size):
                logger.info(f"Processing batch {i//batch_size + 1}/{(total_samples + batch_size - 1)//batch_size}")
                # Clear cache before each batch
                torch.cuda.empty_cache()
                gc.collect()
                batch_x = x_valid[i:i + batch_size]
                batch_tensor = torch.tensor(batch_x, dtype=torch.float32).to(device)
                model = model.to(device)
                batch_predictions = model(batch_tensor)
                predictions.append(batch_predictions.cpu().numpy())
                del batch_tensor, batch_predictions
                torch.cuda.empty_cache()
        y_pred_valid = np.concatenate(predictions, axis=0)
        return y_pred_valid
    except RuntimeError as e:
        logger.info(f"Error occurred: {e}")
        logger.info("Trying with smaller batch size...")
        if batch_size > 1:
            return predict_in_batches(
                model, x_valid, batch_size=batch_size//2, device=device
            )
        else:
            raise Exception("Cannot reduce batch size further")


"""
Split Train and Validation
"""

df = pl.scan_parquet(f"training_startf_{CONFIG.start_dt}.parquet").collect()
df = feature_engineer(df)
df = df.to_pandas()
logger.info(f"In sample data start from date 900, Data shape: {df.shape}")
df_train = df[(df['date_id'] <= CONFIG.split_date)].copy().reset_index(drop=True)
df_valid = df[(df['date_id'] > CONFIG.split_date)].copy().reset_index(drop=True)

if not os.path.exists(f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl"):
    df_train_medians = df_train.median()
    in_sample_medians = df.median()
    data_pickle = {
        "train_medians": df_train_medians,
        "in_sample_medians": in_sample_medians,
    }
    save_pickle(data_pickle, f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl")

data_pickle = load_pickle(f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl")

"""
Use date id 900-1600 to train a model and 1600-1698 for validation. 
"""
if CONFIG.local_train and not CONFIG.debug: 
    logger.info(f"Model version: {CONFIG.model_version}. ")
    rnn_medians = data_pickle["train_medians"] #use train medians
    df_train.fillna(rnn_medians, inplace=True) #in train mode, we fill train and validation na with train medians (25141864, 108)
    df_valid.fillna(rnn_medians, inplace=True)
    rnn_scaler = StandardScaler() 
    df_train[CONFIG.numerical_features] = rnn_scaler.fit_transform(df_train[CONFIG.numerical_features])
    df_valid[CONFIG.numerical_features]  = rnn_scaler.transform(df_valid[CONFIG.numerical_features])

    dataset_train = CustomDataset(df_train)  #(25141864, 88), (25141864,)
    dataset_val = CustomDataset(df_valid) #(3644520, 88), (3644520,)
    train_loader = torch.utils.data.DataLoader(dataset=dataset_train, batch_size=args.bs, shuffle=True, num_workers=min(32, os.cpu_count() - 1))
    val_loader = torch.utils.data.DataLoader(dataset=dataset_val, batch_size=args.bs, shuffle=False, num_workers=min(32, os.cpu_count() - 1))
    
    model = NN(input_dim=len(CONFIG.feature_names), hidden_dims = args.n_hidden, drop_ratio = args.drop_ratio, device = device)
    model_summary = summary(model,input_size=(len(CONFIG.feature_names),), batch_size=args.bs, device=device.type)
    logger.info(f"{model_summary}")

    criterion = nn.MSELoss(reduction='none').to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=10, cooldown=0, min_lr=1e-8, verbose=True)
    train_losses, val_losses = batch_gd(model, criterion, optimizer, scheduler, train_loader, val_loader, 
                                        epochs=args.max_epochs, patience=args.patience, save=True, 
                                        save_path=f'best_model_{CONFIG.model_version}_localtrain')
    save_pickle([train_losses, val_losses], f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl')      

    # Get the validation score
    model = NN( input_dim=len(CONFIG.feature_names), hidden_dims = args.n_hidden, drop_ratio = args.drop_ratio, device = device)
    model_path = f'{CONFIG.model_path}/best_model_{CONFIG.model_version}_localtrain'
    model.load_state_dict(torch.load(model_path, map_location=device))
    model = model.to(device)
    model.eval()
    with torch.no_grad():
        x_valid, y_valid, w_valid = df_valid[CONFIG.feature_names].values, df_valid[CONFIG.label_name].values, df_valid[CONFIG.weight_name].values
        y_pred_valid = predict_in_batches(model, x_valid, batch_size=args.bs, device=device)
    valid_score = r2_score(y_valid, y_pred_valid, sample_weight=w_valid )
    logger.info(f"Model Version: {CONFIG.model_version}, Validation score is {valid_score:.4f}. ")
    data_path = f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl'
    for loss_type in ["train", "valid"]:
        plot_epochs_loss(data_path = data_path, save_path = f'{CONFIG.model_path}/{loss_type}_loss_curves.png', loss_type = loss_type, save = True) 
    logger.info("Local train is done! ")  


"""
Use date id 900-1698 data to retrain a model for online inference. 
"""
if CONFIG.online_train and not CONFIG.debug:
    logger.info(f"Model version: {CONFIG.model_version}. Online Train: {CONFIG.online_train}")
    
    #find the best epoch number
    _, valid_temp =  load_pickle(f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl')
    valid_losses = valid_temp[valid_temp>0]
    best_epoch = np.argmin(valid_losses) + 1 #starts from index 1
    logger.info(f"Find the best epoch in local train, the best epoch is {best_epoch} with validation loss {valid_losses[best_epoch-1]}.")
    rnn_medians = data_pickle["in_sample_medians"]  
    df.fillna(rnn_medians, inplace=True)
    rnn_scaler = StandardScaler() 
    df[CONFIG.numerical_features] = rnn_scaler.fit_transform(df[CONFIG.numerical_features])
    if "in_sample_rnn_scaler" not in data_pickle.keys():
        data_pickle["in_sample_rnn_scaler"] = rnn_scaler
        save_pickle(data_pickle, f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl")

    dataset_insample = CustomDataset(df) 
    insample_loader = torch.utils.data.DataLoader(dataset=dataset_insample, batch_size=args.bs, shuffle=True, num_workers=min(32, os.cpu_count() - 1))
    online_model = NN(input_dim=len(CONFIG.feature_names), hidden_dims = args.n_hidden, drop_ratio = args.drop_ratio, device = device)
    criterion = nn.MSELoss(reduction='none').to(device)
    optimizer = torch.optim.Adam(online_model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=10, cooldown=0, min_lr=1e-8, verbose=True)
    ol_train_losses, _= batch_gd(online_model, criterion, optimizer, scheduler, insample_loader, insample_loader, 
                                epochs=best_epoch, patience=100, save=True, 
                                save_path=f'best_model_{CONFIG.model_version}_onlinetrain')
    save_pickle([ol_train_losses], f'{CONFIG.model_path}/online_trainlosses_{CONFIG.model_version}.pkl')         
    logger.info("Online train is done! ") 
