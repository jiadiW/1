import pandas as pd
import polars as pl
import numpy as np
import os, gc
import pickle
import torch
import torch.nn as nn
import torch.nn.functional as F
import logging
from pytorch_lightning.loggers import WandbLogger
from torch.utils.data import Dataset
from sklearn.metrics import r2_score
from torchsummary import summary
from tqdm.auto import tqdm
from matplotlib import pyplot as plt
from sklearn.preprocessing import StandardScaler
from multiprocessing import Pool
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')
pd.options.display.max_columns = None
import sys
import copy
import kaggle_evaluation.jane_street_inference_server


"""
Imporve online learning
"""

class CONFIG:
    seed = 42
    target_col = "responder_6"
    lag_cols_original = ["date_id", "symbol_id"] + [f"responder_{idx}" for idx in range(9)]
    nolag_to_lag_rename = { f"responder_{idx}" : f"responder_{idx}_lag_1" for idx in range(9)}
    start_dt = 900
    gap = 1 # make sure there is no info overlap between train and validation, set it as 1 since we only use lag 1
    rnn_categorical_features_dict = {"feature_09": 23, "feature_10":10 , "feature_11":31} #{feature_name: dictionary size}
    categorical_features = (list(rnn_categorical_features_dict.keys())).copy()
    numerical_features = [f"feature_{i:02d}" for i in range(79) if i not in [9, 10, 11]]\
        + [f"responder_{idx}_lag_1" for idx in range(9)] \
        +  ['sin_time_id', 'cos_time_id', 'sin_time_id_halfday', 'cos_time_id_halfday']
    feature_names = [f"feature_{i:02d}" for i in range(79)] + [f"responder_{idx}_lag_1" for idx in range(9)] + ['sin_time_id', 'cos_time_id', 'sin_time_id_halfday', 'cos_time_id_halfday']
    label_name = 'responder_6'
    features_label_name = feature_names + [label_name]
    weight_name = 'weight'
    features_label_weight_name = feature_names + [label_name] + [weight_name]
    model_version = "v2.6-ol-pipeline"
    model_path = f"model_{model_version}"
    input_path = 'autodl-tmp' if os.path.exists('autodl-tmp') else '/kaggle/input/jane-street-real-time-market-data-forecasting'
    split_date = 1500
    local_train = False
    online_train = True
    debug = False


class custom_args():
    def __init__(self):
        self.usegpu = True
        self.gpuid = 0
        self.seed = 42
        self.bs = 16384  # 8192
        self.lr = 1e-4   #1e-4
        self.weight_decay = 5e-4
        self.drop_ratio = 0.2
        self.n_hidden = [512, 512, 256]
        self.patience = 15
        self.max_epochs = 80

args = custom_args()
if not os.path.exists(CONFIG.model_path):
    os.makedirs(CONFIG.model_path)

def setup_logger(path, name):
    path_ = f'{path}/'
    if not os.path.exists(path_):
        os.makedirs(path_)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    fhlr = logging.FileHandler(f'{path_}{name}.log')
    fhlr.setFormatter(formatter)
    chlr = logging.StreamHandler()
    chlr.setFormatter(formatter)
    logger.addHandler(chlr)
    logger.addHandler(fhlr)
    return logger, path_


logger_path = 'JSLog'
if not os.path.exists(logger_path):
    os.makedirs(logger_path)
now = datetime.now()-pd.Timedelta('13H')
crrt_time = now.strftime(f"%Y%m%d%H%M")
logger, logger_path = setup_logger(logger_path, name=f"{CONFIG.model_path}_onlinetrain_{CONFIG.online_train}_{crrt_time}")


device = torch.device(f'cuda:{args.gpuid}' if torch.cuda.is_available() and args.usegpu else 'cpu')  #cuda:0
accelerator = 'gpu' if torch.cuda.is_available() and args.usegpu else 'cpu'  #gpu
logger.info(f"Device: {device}, Accelerator: {accelerator}")


def save_pickle(data, file_path):
    # Create the directory if it doesn't exist
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Save the pickle file
    with open(file_path, 'wb') as file:  #the file is opened for writing in binary mode.
        pickle.dump(data, file)
    logger.info(f"Data saved to {file_path}")


def load_pickle(file_path):
    # Load and return the data from the pickle file
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            data = pickle.load(file)
        return data
    else:
        raise FileNotFoundError(f"No such file: {file_path}")


class CustomDataset(Dataset):
    """Characterizes a dataset for PyTorch, same as pytorch"""
    def __init__(self, df):
        """Initialization"""
        self.features = torch.from_numpy(df[CONFIG.feature_names].values)
        self.labels = torch.from_numpy(df[CONFIG.label_name].values)
        self.weights = torch.from_numpy(df[CONFIG.weight_name].values)
    
    def __len__(self): 
        """Denotes the total number of samples"""
        return len(self.labels)
    
    def __getitem__(self, idx):
        """Generates samples of data"""
        x = self.features[idx]
        y = self.labels[idx]
        w = self.weights[idx]
        return x, y, w

    
# Custom R2 metric for validation
def r2_val(y_true, y_pred, sample_weight):
    r2 = 1 - np.average((y_pred - y_true) ** 2, weights=sample_weight) / (np.average((y_true) ** 2, weights=sample_weight) + 1e-38)
    return r2


def feature_engineer(df: pl.DataFrame):
    """
    1. add some time features
    return: pl.dataframe
    """
    df_copy = df.clone()
    df_copy = df_copy.with_columns([
        (2 * np.pi * pl.col("time_id") / 967).sin().alias("sin_time_id"),
        (2 * np.pi * pl.col("time_id") / 967).cos().alias("cos_time_id"),
        (2 * np.pi * pl.col("time_id") / 483).sin().alias("sin_time_id_halfday"),
        (2 * np.pi * pl.col("time_id") / 483).cos().alias("cos_time_id_halfday"),
    ])
    return df_copy


class NN(nn.Module): #~440k parameters
    def __init__(self, input_dim, hidden_dims, drop_ratio, device):
        super().__init__()
        self.device = device
        layers = []
        in_dim = input_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(in_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(num_features=hidden_dim))
            layers.append(nn.SiLU())
            layers.append(nn.Dropout(drop_ratio))
            in_dim = hidden_dim
        layers.append(nn.Linear(in_dim, 1))
        layers.append(nn.Tanh())
        self.model = nn.Sequential(*layers)
        self.to(self.device)  # Move the model to the specified device

    def forward(self, x):
        x = x.to(self.device)
        return 5 * self.model(x).squeeze(-1)


class DataBuffer:
    def __init__(self, max_size=100000):
        self.data = pl.DataFrame()  # Changed to Polars DataFrame
        self.max_size = max_size
        
    def add_data(self, new_data: pl.DataFrame):
        self.data = pl.concat([self.data, new_data], how="vertical")
        if self.data.height > self.max_size:
            # Keep most recent data
            self.data = self.data.tail(self.max_size)
            
    def get_sample(self, sample_size):
        if self.data.is_empty():
            return pl.DataFrame()
        return self.data.sample(n=min(sample_size, self.data.height))

def efficient_scaling(df: pl.DataFrame, scaler, numeric_features: list) -> pl.DataFrame:
    """Efficiently scale numerical features"""
    numeric_data = df.select(numeric_features).to_numpy()
    scaled_data = scaler.transform(numeric_data)
    
    # Update scaled columns
    for idx, col in enumerate(numeric_features):
        df = df.with_columns(pl.Series(name=col, values=scaled_data[:, idx]))
    return df


# A function to encapsulate the training loop with early stopping and learning rate scheduler
def batch_gd(model, criterion, optimizer, scheduler, train_loader, test_loader, epochs, patience=10, save=True, save_path=None):

    train_losses = np.zeros(epochs)
    test_losses = np.zeros(epochs)
    best_test_loss = np.inf
    best_test_epoch = 0
    patience_counter = 0

    for it in tqdm(range(epochs)):
        model.train()
        t0 = datetime.now()
        train_loss_it = []
        for inputs, targets, weights in train_loader:
            optimizer.zero_grad() 
            inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
            outputs = model(inputs)
            loss = criterion(outputs, targets) * weights #if reduction is none, it is a vector (w_i*(yi-yi_hat)**2, ..., ..., )
            loss = loss.mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5)
            optimizer.step()
            train_loss_it.append(loss.item()) 
        
        # Get train loss and test loss
        train_loss = np.mean(train_loss_it) 
        
        if epochs == 1: #no need to adjust lr
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4f}, Duration: {datetime.now() - t0}. ')

        else:
            model.eval()
            test_loss_it = []
            with torch.no_grad():
                for inputs, targets, weights in test_loader:
                    inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
                    outputs = model(inputs)
                    loss = criterion(outputs, targets) * weights
                    loss = loss.mean()
                    test_loss_it.append(loss.item())
            test_loss = np.mean(test_loss_it)

            # Save losses
            train_losses[it] = train_loss
            test_losses[it] = test_loss
            
            # Update the scheduler
            scheduler.step(test_loss)

            # Check for early stopping
            if test_loss < best_test_loss:
                patience_counter = 0
                best_test_loss = test_loss
                best_test_epoch = it
                if save:
                    torch.save(model.state_dict(), f'{CONFIG.model_path}/{save_path}')
                    logger.info('Model saved.')
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    logger.info('Early stopping.')
                    break

            dt = datetime.now() - t0
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4e}, \
                Validation Loss: {test_loss:.4e}, Duration: {dt}, Best Val Epoch: {best_test_epoch}')
    
    return train_losses, test_losses


# Online learning function to encapsulate the training loop with early stopping and learning rate scheduler
def batch_gd_ol(model, criterion, optimizer, scheduler, train_loader, test_loader, epochs, patience):

    best_test_loss = np.inf
    best_test_epoch = -1
    patience_counter = 0
    
    model.eval()
    test_loss_it = 0
    with torch.no_grad():
        for inputs, targets, weights in test_loader:
            inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
            outputs = model(inputs)
            loss = criterion(outputs, targets) * weights
            loss = loss.mean()
            test_loss_it += loss.item()
    best_test_loss = test_loss_it/len(test_loader)  #save the current model validation score. 
    best_model_state = copy.deepcopy(model.state_dict())  # Save current model state
    logger.info(f"Online Learning with new data, the validation data loss with current model is {best_test_loss}. ")
    for it in tqdm(range(epochs)):
        model.train()
        t0 = datetime.now()
        train_loss_it = 0
        for inputs, targets, weights in train_loader:
            optimizer.zero_grad() 
            inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
            outputs = model(inputs)
            loss = criterion(outputs, targets) * weights #if reduction is none, it is a vector (w_i*(yi-yi_hat)**2, ..., ..., )
            loss = loss.mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5)
            optimizer.step()
            train_loss_it += loss.item()
        # Get train loss and test loss
        train_loss = train_loss_it/len(train_loader)
        
        model.eval()
        test_loss_it = 0
        with torch.no_grad():
            for inputs, targets, weights in test_loader:
                inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
                outputs = model(inputs)
                loss = criterion(outputs, targets) * weights
                loss = loss.mean()
                test_loss_it += loss.item()
        test_loss = test_loss_it/len(test_loader)
        
        # Update the scheduler
        scheduler.step(test_loss)

        # Check for early stopping
        if test_loss < best_test_loss:
            patience_counter = 0
            best_test_loss = test_loss
            best_test_epoch = it
            best_model_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
            if patience_counter >= patience:
                logger.info('Early stopping.')
                break

        dt = datetime.now() - t0
        logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4e}, Validation Loss: {test_loss:.4e}, Duration: {dt}, Best Val Epoch: {best_test_epoch}')
    
    if test_loss > best_test_loss: # Restore best model if validation didn't improve
        model.load_state_dict(best_model_state)
        return False
    return True


def plot_epochs_loss(data_path, save_path, loss_type, save = True):
    train_temp, valid_temp =  load_pickle(data_path)
    loss_idx = np.where(train_temp>0)
    train_losses, valid_losses = train_temp[loss_idx], valid_temp[loss_idx]
    epochs = range(1, len(train_losses) + 1)
    plt.figure(figsize=(10, 6))
    if loss_type == "train":
        plt.plot(epochs, train_losses, 'b-', label='Training Loss')
        plt.title(' train Loss')
    elif loss_type == "valid":
        plt.plot(epochs, valid_losses, 'r-', label='Validation Loss')
        plt.title(' Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
    if save:
        plt.savefig(save_path)



def predict_in_batches(model, x_valid, batch_size, device):
    """
    x_valid: np.array
    """
    model.eval()
    predictions = []
    total_samples = len(x_valid)
    try:
        with torch.no_grad():
            for i in range(0, total_samples, batch_size):
                logger.info(f"Processing batch {i//batch_size + 1}/{(total_samples + batch_size - 1)//batch_size}")
                # Clear cache before each batch
                torch.cuda.empty_cache()
                gc.collect()
                batch_x = x_valid[i:i + batch_size]
                batch_tensor = torch.tensor(batch_x, dtype=torch.float32).to(device)
                model = model.to(device)
                batch_predictions = model(batch_tensor)
                predictions.append(batch_predictions.cpu().numpy())
                del batch_tensor, batch_predictions
                torch.cuda.empty_cache()
        y_pred_valid = np.concatenate(predictions, axis=0)
        return y_pred_valid
    except RuntimeError as e:
        logger.info(f"Error occurred: {e}")
        logger.info("Trying with smaller batch size...")
        if batch_size > 1:
            return predict_in_batches(
                model, x_valid, batch_size=batch_size//2, device=device
            )
        else:
            raise Exception("Cannot reduce batch size further")


"""
Split Train and Validation
"""

df = pl.scan_parquet(f"training_startf_{CONFIG.start_dt}.parquet").collect()
df = feature_engineer(df)
df = df.to_pandas()
logger.info(f"In sample data start from date 900, Data shape: {df.shape}")
# df_train = df[(df['date_id'] <= 1500)].copy().reset_index(drop=True)  #date id 900-1500 train
# df_valid = df[(df['date_id'] >1500)&(df['date_id']<= 1600)].copy().reset_index(drop=True) #date-id 1501-1600 local validation
# df_test = df[(df['date_id'] > 1600)].copy().reset_index(drop=True)  #date id 1601-1698 test
# train_val_data = pd.concat([df_train, df_valid])
train_val_data = df[(df['date_id'] <= 1600)].copy().reset_index(drop=True)
# del df_train, df_valid, df_test, df
gc.collect()


# if not os.path.exists(f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl"):
#     df_train_medians = df_train.median()
#     in_sample_medians = train_val_data.median()
#     data_pickle = {
#         "train_medians": df_train_medians,
#         "in_sample_medians": in_sample_medians,
#     }
#     save_pickle(data_pickle, f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl")


data_pickle = load_pickle(f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl")
"""
Use date id 900-1500 to train a model and 1500-1600 for validation. 
"""
# if CONFIG.local_train and not CONFIG.debug: 
#     logger.info(f"Model version: {CONFIG.model_version}. ")
#     rnn_medians = data_pickle["train_medians"] #use train medians
#     df_train.fillna(rnn_medians, inplace=True) #in train mode, we fill train and validation na with train medians (25141864, 108)
#     df_valid.fillna(rnn_medians, inplace=True)
#     df_test.fillna(rnn_medians, inplace=True)
#     rnn_scaler = StandardScaler() 
#     df_train[CONFIG.numerical_features] = rnn_scaler.fit_transform(df_train[CONFIG.numerical_features])
#     df_valid[CONFIG.numerical_features]  = rnn_scaler.transform(df_valid[CONFIG.numerical_features])
#     df_test[CONFIG.numerical_features]  = rnn_scaler.transform(df_test[CONFIG.numerical_features])

#     dataset_train = CustomDataset(df_train)  #(25141864, 88), (25141864,)
#     dataset_val = CustomDataset(df_valid) #(3644520, 88), (3644520,)
#     train_loader = torch.utils.data.DataLoader(dataset=dataset_train, batch_size=args.bs, shuffle=True, num_workers=min(32, os.cpu_count() - 1))
#     val_loader = torch.utils.data.DataLoader(dataset=dataset_val, batch_size=args.bs, shuffle=False, num_workers=min(32, os.cpu_count() - 1))
    
#     model = NN(input_dim=len(CONFIG.feature_names), hidden_dims = args.n_hidden, drop_ratio = args.drop_ratio, device = device)
#     model_summary = summary(model,input_size=(len(CONFIG.feature_names),), batch_size=args.bs, device=device.type)
#     logger.info(f"{model_summary}")

#     criterion = nn.MSELoss(reduction='none').to(device)
#     optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
#     scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=10, cooldown=0, min_lr=1e-8, verbose=True)
#     train_losses, val_losses = batch_gd(model, criterion, optimizer, scheduler, train_loader, val_loader, 
#                                         epochs=args.max_epochs, patience=args.patience, save=True, 
#                                         save_path=f'best_model_{CONFIG.model_version}_localtrain')
#     save_pickle([train_losses, val_losses], f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl')      

#     # Get the validation score
#     model = NN( input_dim=len(CONFIG.feature_names), hidden_dims = args.n_hidden, drop_ratio = args.drop_ratio, device = device)
#     model_path = f'{CONFIG.model_path}/best_model_{CONFIG.model_version}_localtrain'
#     model.load_state_dict(torch.load(model_path, map_location=device))
#     model = model.to(device)
#     model.eval()
#     with torch.no_grad():
#         x_valid, y_valid, w_valid = df_valid[CONFIG.feature_names].values, df_valid[CONFIG.label_name].values, df_valid[CONFIG.weight_name].values
#         y_pred_valid = predict_in_batches(model, x_valid, batch_size=args.bs, device=device)
#         x_test, y_test, w_test = df_test[CONFIG.feature_names].values, df_test[CONFIG.label_name].values, df_test[CONFIG.weight_name].values
#         y_pred_test = predict_in_batches(model, x_test, batch_size=args.bs, device=device)

#     valid_score = r2_score(y_valid, y_pred_valid, sample_weight=w_valid )
#     test_score = r2_score(y_test, y_pred_test, sample_weight=w_test )
#     logger.info(f"Model Version: {CONFIG.model_version}, Local Model Validation score is {valid_score:.4f}. Local Model test score is {test_score:.4f}. ")
#     data_path = f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl'
#     for loss_type in ["train", "valid"]:
#         plot_epochs_loss(data_path = data_path, save_path = f'{CONFIG.model_path}/{loss_type}_loss_curves.png', loss_type = loss_type, save = True) 
#     logger.info("Local train is done! ")  



"""
Load local model and inference and online learning.
"""
model = NN(input_dim=len(CONFIG.feature_names), hidden_dims = args.n_hidden, drop_ratio = args.drop_ratio, device = device)
model_path = f'{CONFIG.model_path}/best_model_{CONFIG.model_version}_localtrain'
model.load_state_dict(torch.load(model_path, map_location=device))
model = model.to(device)
model.eval()


if "in_sample_rnn_scaler" not in data_pickle.keys():
    rnn_scaler = StandardScaler() 
    train_val_data[CONFIG.numerical_features] = rnn_scaler.fit_transform(train_val_data[CONFIG.numerical_features])
    data_pickle["in_sample_rnn_scaler"] = rnn_scaler  #date id 900-1600 in sample scaler
    save_pickle(data_pickle, f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl")


data_pickle = load_pickle(f"{CONFIG.input_path}/data_pickle_{CONFIG.model_version}.pkl")
in_sample_medians = data_pickle["in_sample_medians"]
rnn_scaler = data_pickle["in_sample_rnn_scaler"]


lags_ : pl.DataFrame | None = None
torch.backends.cudnn.benchmark = True
data_retrain = pd.DataFrame() #save 10 days' historical data
one_day_retrain = pl.DataFrame() #save last day's historical data
counter = 0
data_buffer = DataBuffer(max_size=1000000) 
criterion = nn.MSELoss(reduction='none').to(device)
lr = args.lr
optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=args.weight_decay)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=3, cooldown=0, min_lr=1e-8, verbose=True)
ol_bs = args.bs
medians_dict = in_sample_medians.to_dict()

def predict(test: pl.DataFrame, lags: pl.DataFrame | None) -> pl.DataFrame | pd.DataFrame:
    global lags_, data_retrain, one_day_retrain, rnn_scaler, counter, model, data_buffer
    
    if lags is not None:
        counter += 1
        if counter > 1:
            last_date_label = (lags.select(["time_id", "symbol_id", "responder_6_lag_1"]).rename({"responder_6_lag_1": "responder_6"}))
            one_day_retrain = (one_day_retrain.join(last_date_label, on=['time_id', 'symbol_id'], how="left"))
            one_day_retrain = one_day_retrain.with_columns([pl.col(col).fill_null(medians_dict[col]) for col in one_day_retrain.columns if col in medians_dict])
            one_day_retrain = efficient_scaling(one_day_retrain, rnn_scaler, CONFIG.numerical_features)
            data_retrain = pd.concat([data_retrain, one_day_retrain.to_pandas()])
            one_day_retrain = pl.DataFrame()
            gc.collect()
            if counter % 10 == 0:
                # Split new data into train and validation
                val_size = int(0.3 * len(data_retrain))
                train_new = data_retrain[:-val_size]
                val_data = data_retrain[-val_size:]
                            
                # Get historical data from buffer
                buffer_size = int(0.3 * len(train_new) / 0.7)  # historical data 30%, train_new: 70%
                buffer_data = data_buffer.get_sample(buffer_size)
                
                # Combine new and buffer data for training
                if not buffer_data.is_empty():
                    train_data = pd.concat([train_new, buffer_data.to_pandas()])
                else:
                    train_data = train_new
                torch.cuda.empty_cache()
                gc.collect() 
                
                train_dataset = CustomDataset(train_data)  #(37752, 99)\
                val_dataset = CustomDataset(val_data)
                train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=ol_bs, shuffle=True, num_workers=8)
                val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=ol_bs, shuffle=True, num_workers=8)
                batch_gd_ol(model, criterion, optimizer, scheduler, train_loader, val_loader, epochs=5, patience=3)
                data_buffer.add_data(pl.from_pandas(data_retrain)) # Update buffer with new data
                rnn_scaler.partial_fit(data_retrain[CONFIG.numerical_features])  # Update scaler       
                
                data_retrain = pd.DataFrame()
                torch.cuda.empty_cache()
                gc.collect() 
        
        lags = lags.group_by(["date_id", "symbol_id"], maintain_order=True).last().drop("time_id") # pick up last record of previous date
        lags_= lags.clone()        
    
    test = test.with_columns([
            (2 * np.pi * pl.col("time_id") / 967).sin().alias("sin_time_id"),
            (2 * np.pi * pl.col("time_id") / 967).cos().alias("cos_time_id"),
            (2 * np.pi * pl.col("time_id") / 483).sin().alias("sin_time_id_halfday"),
            (2 * np.pi * pl.col("time_id") / 483).cos().alias("cos_time_id_halfday"),
        ]).join(lags_, on=["date_id", "symbol_id"],  how="left")  #polars dataframe
    one_day_retrain = pl.concat([one_day_retrain,test], how = "vertical") #polars dataframe
    preds = np.zeros((test.height,))

    if test["is_scored"][0]:
        # Process test data for prediction
        test_features = (test.select(CONFIG.feature_names).with_columns([pl.col(col).fill_null(medians_dict[col]) for col in CONFIG.feature_names]))
        test_features = efficient_scaling(test_features, rnn_scaler, CONFIG.numerical_features)
        test_input = torch.FloatTensor(test_features.to_numpy()).to(device)
        with torch.no_grad(): 
            model.eval()
            preds = model(test_input).cpu().numpy()
    
    predictions = test.select(
        'row_id',
        pl.Series(preds).alias('responder_6'),)
    return predictions


"""
Simulation Online prediction pipeline.
"""

alltraindata = pl.scan_parquet(f"{CONFIG.input_path}/train.parquet")
test_data = alltraindata.filter((pl.col("date_id")>1600)).collect()
test_data = test_data.with_columns(pl.Series(range(len(test_data))).alias("row_id"))
lag0 = pl.scan_parquet(f"{CONFIG.input_path}/lags.parquet")
temp = lag0.collect()
test_sample = pl.scan_parquet(f"{CONFIG.input_path}/test.parquet")
test_sample = test_sample.collect()
lag_sample = pl.read_parquet(f"{CONFIG.input_path}/lags.parquet/date_id=0/part-0.parquet")
responder_cols = [s for s in test_data.columns if "responder" in s]

def makelag(date_id):
    """
    Making lag at the previout day

    Args:
    date_id (int): date_id at the previout day
    
    Returns:
    pl.dataframe, date_id == 同一个batch的test.date_id
    """
    
    lag = alltraindata.filter(pl.col("date_id")==date_id).select(["date_id","time_id","symbol_id"] + responder_cols).collect()
    lag.columns = lag_sample.columns
    lag = lag.with_columns((pl.col("date_id")+1).alias("date_id"))
    return lag   


all_submission_dataframe = []

for num_days, df_per_day in test_data.group_by("date_id",maintain_order=True): ## Step 1 The data is split by day using group_by.
    logger.info(f"Date id: {num_days[0]}")
    for time_id, test in df_per_day.group_by("time_id", maintain_order=True): ## Step 2 The data is split by time_id using group_by, and the lag is generated (for time_id == 0).
        
        if time_id[0] == 0: ## when time_id == 0, makelags
            lag = makelag(num_days[0] - 1)  #shape: (37_752, 12)
        else:
            lag = None
        test = test.with_columns(is_scored=True)
        test = test.select(test_sample.columns) #shape:(39, 85)
        submission_dataframe = predict(test, lag)
        all_submission_dataframe.append(submission_dataframe)
        
all_submission_dataframe = pl.concat(all_submission_dataframe)
all_submission_dataframe = all_submission_dataframe.rename({"responder_6": "y_pred"})
df_all = test_data.join(all_submission_dataframe, on = "row_id", how = "left" )
df_all.write_parquet(f"online_rolling_forecast_{CONFIG.model_version}.parquet")


df_all = pl.read_parquet(f"online_rolling_forecast_{CONFIG.model_version}.parquet")
test_score = r2_score(df_all["responder_6"], df_all["y_pred"], sample_weight=df_all["weight"] )
logger.info(f"Batch Size is {ol_bs}, Online Learning Test Score: {test_score}. ")
logger.info("Pipeline Inference is done!")