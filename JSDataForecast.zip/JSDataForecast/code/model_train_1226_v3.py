import pandas as pd
import polars as pl
import numpy as np
import os, gc
import pickle
import torch
import torch.nn as nn
import torch.nn.functional as F
import logging
from pytorch_lightning.loggers import WandbLogger
from torch.utils.data import Dataset
from sklearn.metrics import r2_score
from torchsummary import summary
from tqdm.auto import tqdm
from matplotlib import pyplot as plt
from sklearn.preprocessing import StandardScaler
from multiprocessing import Pool
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')
pd.options.display.max_columns = None
import sys
sys.path.append("/root")
import kaggle_evaluation.jane_street_inference_server


class CONFIG:
    seed = 42
    target_col = "responder_6"
    lag_cols_original = ["date_id", "symbol_id"] + [f"responder_{idx}" for idx in range(9)]
    lag_cols_rename = { f"responder_{idx}" : f"responder_{idx}_lag_1" for idx in range(9)}
    start_dt = 900
    gap = 1 # make sure there is no info overlap between train and validation, set it as 1 since we only use lag 1
    feature_names = [f"feature_{i:02d}" for i in range(79)] + [f"responder_{idx}_lag_1" for idx in range(9)]
    label_name = 'responder_6'
    weight_name = 'weight'
    model_version = "v3"
    model_path = f"models_{model_version}"
    input_path = 'autodl-tmp' if os.path.exists('autodl-tmp') else '/kaggle/input/jane-street-real-time-market-data-forecasting'
    split_date = 1600
    rnn_categorical_features_dict = {"feature_09": 23, "feature_10":10 , "feature_11":31} #{feature_name: dictionary size}
    local_train = False
    online_train = True
    debug = False



class custom_args():
    def __init__(self):
        self.usegpu = True
        self.gpuid = 0
        self.seed = 42
        self.use_wandb = True
        self.project = 'js-rnn' 
        self.bs = 16384  # 8192
        self.lr = 1e-4   #1e-4
        self.weight_decay = 5e-4
        self.patience = 10 
        self.max_epochs = 50   
        self.window_size = 3

args = custom_args()

if not os.path.exists(CONFIG.model_path):
    os.makedirs(CONFIG.model_path)



def setup_logger(path, name):
    path_ = f'{path}/'
    if not os.path.exists(path_):
        os.makedirs(path_)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    fhlr = logging.FileHandler(f'{path_}{name}.log')
    fhlr.setFormatter(formatter)
    chlr = logging.StreamHandler()
    chlr.setFormatter(formatter)
    logger.addHandler(chlr)
    logger.addHandler(fhlr)
    return logger, path_


logger_path = 'JSLog'
if not os.path.exists(logger_path):
    os.makedirs(logger_path)
now = datetime.now()-pd.Timedelta('13H')
crrt_time = now.strftime(f"%Y%m%d%H%M")
logger, logger_path = setup_logger(logger_path, name=f"{CONFIG.model_path}_onlinetrain_{CONFIG.online_train}_{crrt_time}")


# checking device
device = torch.device(f'cuda:{args.gpuid}' if torch.cuda.is_available() and args.usegpu else 'cpu')  #cuda:0
accelerator = 'gpu' if torch.cuda.is_available() and args.usegpu else 'cpu'  #gpu
logger.info(f"Device: {device}, Accelerator: {accelerator}")
# device = "cpu"
# accelerator=  "cpu"



def save_pickle(data, file_path):
    # Create the directory if it doesn't exist
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Save the pickle file
    with open(file_path, 'wb') as file:  #the file is opened for writing in binary mode.
        pickle.dump(data, file)
    logger.info(f"Data saved to {file_path}")


def load_pickle(file_path):
    # Load and return the data from the pickle file
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            data = pickle.load(file)
        return data
    else:
        raise FileNotFoundError(f"No such file: {file_path}")
    

"""
Data Processing
"""

"""
train = pl.scan_parquet(f"{CONFIG.input_path}/train.parquet").select(pl.int_range(pl.len(), dtype=pl.UInt32).alias("id"), pl.all(),).with_columns(
    (pl.col(CONFIG.target_col)*2).cast(pl.Int32).alias("label"),).filter(pl.col("date_id").gt(CONFIG.start_dt-10)) #not used "label"
logger.info(f"The Train data length after cut is {train.collect().shape}.")  #(29052584, 95)

lags = train.select(pl.col(CONFIG.lag_cols_original))
lags = lags.rename(CONFIG.lag_cols_rename)
lags = lags.with_columns(
    date_id = pl.col('date_id') + 1,  # lagged by 1 day
    )
lags = lags.group_by(["date_id", "symbol_id"], maintain_order=True).last()  # pick up last record of previous date, as last day's closing price return 
train = train.join(lags, on=["date_id", "symbol_id"],  how="left")
train = train.filter(pl.col("date_id").gt(CONFIG.start_dt-1))
logger.info(f"The Train data length after cut is {train.collect().shape}.")  #(28786384, 104)
end_dt = train.select(pl.col("date_id")).max().collect()["date_id"][0]
start_dt = train.select(pl.col("date_id")).min().collect()["date_id"][0]
train.collect().write_parquet(f"training_startf_{start_dt}.parquet") #start from 1101
"""

"""
Split Train and Validation
"""
df = pl.scan_parquet(f"training_startf_{CONFIG.start_dt}.parquet").collect().to_pandas()
logger.info(f"In sample data start from date 900, Data shape: {df.shape}")

#change the catogorical feature to indices
feature09_values = [11, 81,  4, 15, 42, 46, 70, 50, 44,  9, 64, 30, 34, 57, 26, 68,  2, 14, 12, 82, 49, 25]  #22
feature10_values = [ 7,  2,  3,  1,  5,  6, 10,  4, 12]  #9
feature11_values = [ 76,  59,  11,  62, 150, 261, 410, 522,  16,  25, 376,  50,  13, 214, 230, 158,  63, 336, 534, 388, 171,   
                    9,  40,  24,  48,  66, 539,  34, 297, 195]  #30
value09_to_index = {value: idx for idx, value in enumerate(feature09_values)}
value10_to_index = {value: idx for idx, value in enumerate(feature10_values)}
value11_to_index = {value: idx for idx, value in enumerate(feature11_values)}

df["feature_09"] = df["feature_09"].map(value09_to_index).fillna(22).astype(int)
df["feature_10"] = df["feature_10"].map(value10_to_index).fillna(9).astype(int)
df["feature_11"] = df["feature_11"].map(value11_to_index).fillna(30).astype(int)


df_train = df[(df['date_id'] <= CONFIG.split_date)].copy().reset_index(drop=True)
df_valid = df[(df['date_id'] > CONFIG.split_date)].copy().reset_index(drop=True)

"""
df_train_medians = df_train.median()
in_sample_medians = df.median()
data_pickle = {
    "train_medians": df_train_medians,
    "in_sample_medians": in_sample_medians,
}
save_pickle(data_pickle, f'{CONFIG.input_path}/data_pickle.pkl')
"""

"""
Model Train
"""
def precompute_sequences(stock_data, window_size, numerical_features, categorical_features):
    # Convert DataFrame columns to NumPy arrays
    """
    stock_data: data group by symbol_id and time_id
    return:
    combined_sequences: np.array, shape:(len(stock_data), window size, number of features)
    targets: np.array, shape: (len(stock_data), )
    weights: np.array, shape: (len(stock_data), )
    """
    stock_data_num = stock_data[numerical_features].values
    stock_data_cat = stock_data[categorical_features].values

    # Pre-compute all sequences
    all_sequences_num = [stock_data_num[max(0, i - window_size + 1):i + 1] for i in range(len(stock_data))]
    all_sequences_cat = [stock_data_cat[max(0, i - window_size + 1):i + 1] for i in range(len(stock_data))]

    # Add padding 0 in front if len(seq)< window size
    padded_sequences_num = [np.pad(seq, ((window_size - len(seq), 0), (0, 0)), 'constant') for seq in all_sequences_num]
    padded_sequences_cat = [np.pad(seq, ((window_size - len(seq), 0), (0, 0)), 'constant') for seq in all_sequences_cat]

    # Combine numerical and categorical features, shape: (684,3,88)
    combined_sequences = np.array([np.concatenate([num, cat], axis=-1) for num, cat in zip(padded_sequences_num, padded_sequences_cat)])

    # Extract targets
    targets = stock_data[CONFIG.target_col].values
    weights = stock_data["weight"].values

    return combined_sequences, targets, weights




def create_batches(data, window_size, rnn_numerical_features, rnn_categorical_features):
    """
    return:
    all_batches: a list of np.array:(25141864, window_size, number of features)
    all_targets: a list, len=25141864
    all_weights: a list, len=25141864
    """
    grouped = data.groupby(['symbol_id', 'time_id'])
    all_batches = []
    all_targets = []
    all_weights= []
    for _, group in tqdm(grouped, desc="Processing groups"):
        # Precompute sequences for the current group
        combined_sequences, targets, weights = precompute_sequences(group, window_size, rnn_numerical_features, rnn_categorical_features)
        # Extend the main batches with the group's sequences and targets
        all_batches.extend(combined_sequences) #combined_sequences: (len(group), window_size, 88)
        all_targets.extend(targets)
        all_weights.extend(weights)
        
    return all_batches, all_targets, all_weights


def precompute_sequences_wrapper(args):
    group, window_size, rnn_numerical_features, rnn_categorical_features = args
    return precompute_sequences(group, window_size, rnn_numerical_features, rnn_categorical_features)


def create_batches_parallel(data, window_size, rnn_numerical_features, rnn_categorical_features, num_workers=min(32, os.cpu_count() - 1)):
    """
    return:
    all_batches: a list of np.array:(25141864, window_size, number of features)
    all_targets: a list, len=25141864
    all_weights: a list, len=25141864
    """
    grouped = data.groupby(['symbol_id', 'time_id'])
    
    # Prepare arguments for parallel processing
    args = [(group, window_size, rnn_numerical_features, rnn_categorical_features) for _, group in grouped]

    all_batches = []
    all_targets = []
    all_weights = []

    with Pool(num_workers) as pool:
        results = list(tqdm(pool.imap(precompute_sequences_wrapper, args), total=len(args), desc="Processing groups"))

    for combined_sequences, targets, weights in results:
        all_batches.extend(combined_sequences) #combined_sequences: (len(group), window_size, 88)
        all_targets.extend(targets)
        all_weights.extend(weights)
        
    return all_batches, all_targets, all_weights




def compute_last_sequence(group, window_size, rnn_numerical_features, rnn_categorical_features):
    # Convert DataFrame columns to NumPy arrays
    stock_data_num = group[rnn_numerical_features].values
    stock_data_cat = group[rnn_categorical_features].values
    stock_data_target = group['target'].values

    # Find the index of the target second
    target_index = len(group) - 1

    # Extract the sequence for the target index
    sequence_num = stock_data_num[max(0, target_index - window_size + 1):target_index + 1]
    sequence_cat = stock_data_cat[max(0, target_index - window_size + 1):target_index + 1]

    # Add padding if necessary
    padded_sequence_num = np.pad(sequence_num, ((window_size - len(sequence_num), 0), (0, 0)), 'constant')
    padded_sequence_cat = np.pad(sequence_cat, ((window_size - len(sequence_cat), 0), (0, 0)), 'constant')

    # Combine numerical and categorical features
    combined_sequence = np.concatenate([padded_sequence_num, padded_sequence_cat], axis=-1)

    # Extract target
    target = stock_data_target[-1]
    return combined_sequence, target


def create_last_batches(data, window_size, rnn_numerical_features, rnn_categorical_features):

    grouped = data.groupby(['stock_id'])
    all_batches = []
    all_targets = []

    for _, group in grouped:
        # Compute the sequence for the last data point in the current group on inference mode
        last_sequence, last_target = compute_last_sequence(group, window_size, rnn_numerical_features, rnn_categorical_features)

        # Check if the sequence is valid (i.e., not empty)
        if last_sequence.size > 0:
            all_batches.append(last_sequence)
            all_targets.append(last_target)

    return all_batches, all_targets


def get_data(df, rnn_numerical_features, rnn_categorical_features, window_size, is_inference=False):
    """
    return:
    df_copy_batches: np.array, (num of samples, window size, num of features)
    df_copy_targets: np.array,  (num of samples,)
    df_copy_weights: np.array,  (num of samples,)
    """
    # Check if the DataFrame is empty
    global rnn_scaler,rnn_medians
    if df.empty:
        return None, None, None
    # Work on a copy of the DataFrame to avoid changing the original df
    df_copy = df.copy()
    # Standard scaling for numerical features
    if is_inference:
        df_copy.fillna(rnn_medians, inplace=True)
        df_copy[rnn_numerical_features] = rnn_scaler.transform(df_copy[rnn_numerical_features])
    # Preprocess Data
    if is_inference:   #only return the data point which is the last one for each symbol id, no need for multiprocessing
        df_copy_batches, df_copy_targets, df_copy_weights = create_last_batches(df_copy, window_size, rnn_numerical_features, rnn_categorical_features)
    else:
        df_copy_batches_ls, df_copy_targets_ls, df_copy_weights_ls = create_batches_parallel(df_copy, window_size, rnn_numerical_features, rnn_categorical_features)
    df_copy_batches = np.array(df_copy_batches_ls)  
    df_copy_targets = np.array(df_copy_targets_ls)  
    df_copy_weights=  np.array(df_copy_weights_ls)
    del df_copy_batches_ls, df_copy_targets_ls, df_copy_weights_ls
    gc.collect()
    return df_copy_batches, df_copy_targets, df_copy_weights




class CustomDataset(Dataset):
    """
    Characterizes a dataset for PyTorch
    """
    def __init__(self, df, T):
        #Initialization
        self.T = T
        xs, ys, ws = get_data(df, rnn_numerical_features, rnn_categorical_features, T)
        logger.info(f'fetching data: , {xs.shape}, {ys.shape}, {ws.shape}') 
        self.length = len(xs)
        self.x = torch.from_numpy(xs)
        self.y = torch.from_numpy(ys)
        self.w = torch.from_numpy(ws)
        del xs, ys, ws
        gc.collect()

    def __len__(self):
        #Denotes the total number of samples
        return self.length

    def __getitem__(self, index):
        #Generates samples of data
        return self.x[index], self.y[index], self.w[index]


    
# Custom R2 metric for validation
def r2_val(y_true, y_pred, sample_weight):
    r2 = 1 - np.average((y_pred - y_true) ** 2, weights=sample_weight) / (np.average((y_true) ** 2, weights=sample_weight) + 1e-38)
    return r2


class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_sizes, do_ratio=0.5):
        """
        in_channels: number of features
        out_channels: number of filters
        kernel_sizes: list, a list of kernel size
        do_ratio: float
        """
        super(ConvBlock, self).__init__()
        self.conv_layers = nn.ModuleList()
        self.conv_layers1 = nn.ModuleList()
        for kernel_size in kernel_sizes:
            self.conv_layers.append(
                nn.Sequential(
                    nn.Conv1d(in_channels, out_channels, kernel_size, padding="same"),
                    nn.BatchNorm1d(out_channels),
                    nn.ReLU(),
                    nn.Dropout(do_ratio),
                )
            )
            self.conv_layers1.append(
                nn.Sequential(
                    nn.Conv1d(out_channels, out_channels, kernel_size, padding="same"),
                    nn.BatchNorm1d(out_channels),
                    nn.ReLU(),
                )
            )
        
    def forward(self, x): #input tensor with shape (batch_size, num_features, sequence_length) 
        conv_outputs = [] 
        for i in range(len(self.conv_layers)):
            conv_layer0 = self.conv_layers[i] #shape: (, out_channels, sequence_length)
            conv_layer1 = self.conv_layers1[i]
            conv_out = conv_layer0(x)
            shortcut = conv_out.clone()
            conv_out = conv_layer1(conv_out)
            conv_out = conv_out+shortcut #conv_out shape:(, out_channels, sequence_length)
            conv_outputs.append(conv_out)
        concatenated_conv = torch.cat(conv_outputs, dim=1) #(, out_channels*len(kernel_sizes), sequence_length)
        flattened_conv_output = concatenated_conv.view(concatenated_conv.size(0), -1) #(batch_size, out_channels * len(kernel_sizes)*sequence_length)
        return flattened_conv_output



class ResidualRNN(nn.Module): #total trainable parameters: ~660, 000
    def __init__(self, window_size, numerical_features, categorical_features, device):
        super(ResidualRNN, self).__init__()
        self.device = device
        self.window_size = window_size
        self.numerical_features = numerical_features
        self.categorical_features = categorical_features
        self.embedding_dim = 6
        # Embedding for categorical feature 09-11
        num_embeddings_list = list(CONFIG.rnn_categorical_features_dict.values())  #[22,9,30]
        self.embeddings = nn.ModuleList([
            nn.Embedding(num_embeddings, self.embedding_dim) for num_embeddings in num_embeddings_list
        ]).to(self.device)
        
        # Convolutional blocks
        self.conv_numerical = ConvBlock(len(numerical_features), 16, [2, 3], 0.4).to(self.device)
        self.conv_categorical = ConvBlock(self.embedding_dim*len(categorical_features), 16, [2, 3], 0.4).to(self.device)
        self.conv_diff = ConvBlock(len(numerical_features)*(self.window_size-1), 16, [2, 3], 0.4).to(self.device)
        
        # Dense layers
        self.dense_sizes = [512, 256, 128, 64, 32]
        self.dense_layers = None
        # Output layer
        self.output_layer = nn.Linear(self.dense_sizes[-1], 1).to(self.device)


    def _create_dense_layers(self, input_dim, hidden_dims, dropout_ratio):
        layers = []
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(input_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(hidden_dim))
            layers.append(nn.SiLU())  # swish activation
            layers.append(nn.Dropout(dropout_ratio))
            input_dim = hidden_dim
        return nn.Sequential(*layers).to(self.device)
    
    def set_dense_layers(self, input_dim, dropout_ratio):
        self.dense_layers = self._create_dense_layers(input_dim, self.dense_sizes, dropout_ratio)


    def forward(self, x):
        x = x.to(self.device)
        # Split the input into numerical and categorical parts
        numerical_input = x[:, :, :-3]  # (batch_size, window_size, 85)
        categorical_input = x[:, :, -3:].long() # (batch_size, window_size, num of cat features)  #can't have negative number
        
        # Compute difference layers
        difference_layers = []
        for lag in range(1, self.window_size):
            diff_layer = numerical_input[:, lag:, :] - numerical_input[:, :-lag, :]  # (batch_size, window_size-lag, num_numerical_features)
            padding = F.pad(diff_layer, (0, 0, lag, 0))  # (batch_size, window_size, num_numerical_features)
            difference_layers.append(padding)
        combined_diff_layer = torch.cat(difference_layers, dim=-1)  # (batch_size, window_size, num_numerical_features * (window_size-1)), [, 3, 170])
        
        # Embedding for categorical part
        embedded_features = []
        for i in range(3):
            feature = categorical_input[:, :, i]  # Extract the i-th feature
            embedded_feature = self.embeddings[i](feature)  # Apply embedding
            embedded_features.append(embedded_feature)
        
        # Concatenate the embedded features along the last dimension
        embedding = torch.cat(embedded_features, dim=-1) # (batch_size, window_size, embedding_dim*3)
        
        # Apply convolutional layers
        conv_numerical = self.conv_numerical(numerical_input.permute(0, 2, 1))  # (batch_size, num_features)
        conv_categorical = self.conv_categorical(embedding.permute(0, 2, 1))  # (batch_size, num_features)
        conv_diff = self.conv_diff(combined_diff_layer.permute(0, 2, 1))  # (batch_size, num_features)
        
        # Concatenate all features
        first_numerical = numerical_input[:, 0, :]  # (batch_size, num_numerical_features)
        first_embedding = embedding[:, 0, :]  # (batch_size, embedding_dim), original categorical embedding features
        combined_features = torch.cat([conv_numerical, conv_categorical, conv_diff, 
                                    combined_diff_layer.view(combined_diff_layer.size(0), -1), 
                                    first_numerical, first_embedding], dim=-1)  #(16384, 901)
        
        
        # Apply dense layers
        if not self.dense_layers:
            self.set_dense_layers(input_dim = combined_features.shape[1], dropout_ratio = 0.5)
        dense_output = self.dense_layers(combined_features)  #[16384, 32]
        
        # Output layer
        output = self.output_layer(dense_output)  #[16384, 1]
        
        return output.squeeze(-1)




# A function to encapsulate the training loop with early stopping and learning rate scheduler
def batch_gd(model, criterion, optimizer, scheduler, train_loader, test_loader, epochs, patience=10, save=True):

    train_losses = np.zeros(epochs)
    test_losses = np.zeros(epochs)
    best_test_loss = np.inf
    best_test_epoch = 0
    patience_counter = 0

    for it in tqdm(range(epochs)):
        model.train()
        t0 = datetime.now()
        train_loss_it = []
        for inputs, targets, weights in train_loader:
            # logger.info ('\nrun again with anomaly detection ...')
            #with torch.autograd.detect_anomaly():
            optimizer.zero_grad() # zero the parameter gradients
            inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
            outputs = model(inputs)
            loss = criterion(outputs, targets) * weights #if reduction is none, it is a vector (w_i*(yi-yi_hat)**2, ..., ..., )
            loss = loss.mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1)
            optimizer.step()
            train_loss_it.append(loss.item()) 
        
        # Get train loss and test loss
        train_loss = np.mean(train_loss_it) 
        
        if epochs == 1: #no need to adjust lr
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4f}, Duration: {datetime.now() - t0}. ')

        else:
            model.eval()
            test_loss_it = []
            with torch.no_grad():
                for inputs, targets, weights in test_loader:
                    inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
                    outputs = model(inputs)
                    loss = criterion(outputs, targets) * weights
                    loss = loss.mean()
                    test_loss_it.append(loss.item())
            test_loss = np.mean(test_loss_it)

            # Save losses
            train_losses[it] = train_loss
            test_losses[it] = test_loss
            
            # Update the scheduler
            scheduler.step(test_loss)

            # Check for early stopping
            if test_loss < best_test_loss:
                patience_counter = 0
                best_test_loss = test_loss
                best_test_epoch = it
                if save:
                    torch.save(model.state_dict(), f'{CONFIG.model_path}/best_model_{CONFIG.model_version}_online_{CONFIG.online_train}')
                    logger.info('Model saved.')
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    logger.info('Early stopping.')
                    break

            dt = datetime.now() - t0
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4e}, \
                Validation Loss: {test_loss:.4e}, Duration: {dt}, Best Val Epoch: {best_test_epoch}')
    
    return train_losses, test_losses


def plot_train_valid_loss(data_path, save_path, save = True):
    train_temp, valid_temp =  load_pickle(data_path)
    loss_idx = np.where(train_temp>0)
    train_losses, valid_losses = train_temp[loss_idx], valid_temp[loss_idx]
    epochs = range(1, len(train_losses) + 1)
    plt.figure(figsize=(10, 6))
    plt.plot(epochs, train_losses, 'b-', label='Training Loss')
    plt.plot(epochs, valid_losses, 'r-', label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
    if save:
        plt.savefig(save_path)



def predict_in_batches(model, x_valid, batch_size, device):
    model.eval()
    predictions = []
    total_samples = len(x_valid)
    try:
        with torch.no_grad():
            for i in range(0, total_samples, batch_size):
                logger.info(f"Processing batch {i//batch_size + 1}/{(total_samples + batch_size - 1)//batch_size}")
                # Clear cache before each batch
                torch.cuda.empty_cache()
                gc.collect()
                batch_x = x_valid[i:i + batch_size]
                batch_tensor = torch.tensor(batch_x, dtype=torch.float32).to(device)
                model = model.to(device)
                batch_predictions = model(batch_tensor)
                predictions.append(batch_predictions.cpu().numpy())
                del batch_tensor, batch_predictions
                torch.cuda.empty_cache()
        y_pred_valid = np.concatenate(predictions, axis=0)
        return y_pred_valid
    except RuntimeError as e:
        logger.info(f"Error occurred: {e}")
        logger.info("Trying with smaller batch size...")
        if batch_size > 1:
            return predict_in_batches(
                model, x_valid, batch_size=batch_size//2, device=device
            )
        else:
            raise Exception("Cannot reduce batch size further")




rnn_categorical_features = (list(CONFIG.rnn_categorical_features_dict.keys())).copy()
rnn_numerical_features=  [fea for fea in CONFIG.feature_names if fea not in rnn_categorical_features]
data_pickle = load_pickle(f"{CONFIG.input_path}/data_pickle.pkl")

"""
Use date id 900-1600 to train a model and 1600-1698 for validation. 
"""
if CONFIG.local_train and not CONFIG.debug: 
    logger.info(f"Model version: {CONFIG.model_version}. ")
    rnn_categorical_features = (list(CONFIG.rnn_categorical_features_dict.keys())).copy()
    rnn_numerical_features=  [fea for fea in CONFIG.feature_names if fea not in rnn_categorical_features]
    rnn_scaler = StandardScaler() 
    rnn_medians = data_pickle["train_medians"]  
    df_train.fillna(rnn_medians, inplace=True) #in train mode, we fill train and validation na with train medians
    df_valid.fillna(rnn_medians, inplace=True)
    df_train[rnn_numerical_features] = rnn_scaler.fit_transform(df_train[rnn_numerical_features])
    df_valid[rnn_numerical_features]  = rnn_scaler.transform(df_valid[rnn_numerical_features])
    dataset_train = CustomDataset(df_train, args.window_size)  #(25141864, 3, 88), (25141864,)
    dataset_val = CustomDataset(df_valid, args.window_size) #(3644520, 3, 88), (3644520,)
    train_loader = torch.utils.data.DataLoader(dataset=dataset_train, batch_size=args.bs, shuffle=True, num_workers=min(32, os.cpu_count() - 1))
    val_loader = torch.utils.data.DataLoader(dataset=dataset_val, batch_size=args.bs, shuffle=False, num_workers=min(32, os.cpu_count() - 1))
    model = ResidualRNN(window_size=args.window_size, numerical_features=rnn_numerical_features, categorical_features = rnn_categorical_features, device = device)
    logger.info(f"{summary(model, input_size=(args.window_size, len(rnn_numerical_features)+len(rnn_categorical_features)))}")
    logger.info(f"{summary(model, input_size=(args.window_size, len(rnn_numerical_features)+len(rnn_categorical_features)))}")
    criterion = nn.MSELoss(reduction='none').to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=6, cooldown=0, min_lr=1e-8, verbose=True)
    train_losses, val_losses = batch_gd(model, criterion, optimizer, scheduler, train_loader, val_loader, epochs=50, patience=10, save=True)
    save_pickle([train_losses, val_losses], f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl')      

    # Get the validation score
    model = ResidualRNN(window_size=args.window_size, numerical_features=rnn_numerical_features, categorical_features = rnn_categorical_features, device = device)
    model.set_dense_layers(input_dim = 901, dropout_ratio = 0.5)  #set dense layers
    model_path = f'{CONFIG.model_path}/best_model_{CONFIG.model_version}'
    model.load_state_dict(torch.load(model_path, map_location=device))
    model = model.to(device)
    model.eval()
    with torch.no_grad():
        x_valid, y_valid, w_valid = get_data(df_valid, rnn_numerical_features, rnn_categorical_features, args.window_size)
        y_pred_valid = predict_in_batches(model, x_valid, batch_size=args.bs, device=device)
    valid_score = r2_score(y_valid, y_pred_valid, sample_weight=w_valid )
    logger.info(f"Model Version: {CONFIG.model_version}, Validation score is {valid_score:.4f}. ")
    plot_train_valid_loss(data_path = f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl', save_path = f'{CONFIG.model_path}/loss_curves.png')


"""
Use date id 900-1698 data to retrain a model for online inference. 
"""
if CONFIG.online_train and not CONFIG.debug:
    logger.info(f"Model version: {CONFIG.model_version}. Online Train: {CONFIG.online_train}")
    
    #find the best epoch number
    _, valid_temp =  load_pickle(f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl')
    valid_losses = valid_temp[valid_temp>0]
    best_epoch = np.argmin(valid_losses) + 1 #starts from index 1
    logger.info(f"Find the best epoch in local train, the best epoch is {best_epoch} with validation loss {valid_losses[best_epoch-1]}.")
    rnn_medians = data_pickle["in_sample_medians"]  
    df.fillna(rnn_medians, inplace=True)
    rnn_scaler = StandardScaler() 
    df[rnn_numerical_features] = rnn_scaler.fit_transform(df[rnn_numerical_features])
    data_pickle["in_sample_rnn_scaler"] = rnn_scaler
    save_pickle(data_pickle, f'{CONFIG.input_path}/data_pickle.pkl')
    
    dataset_insample = CustomDataset(df, args.window_size) 
    insample_loader = torch.utils.data.DataLoader(dataset=dataset_insample, batch_size=args.bs, shuffle=True, num_workers=min(32, os.cpu_count() - 1))
    online_model = ResidualRNN(window_size=args.window_size, numerical_features=rnn_numerical_features, categorical_features = rnn_categorical_features, device = device)
    criterion = nn.MSELoss(reduction='none').to(device)
    optimizer = torch.optim.Adam(online_model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=6, cooldown=0, min_lr=1e-8, verbose=True)

    ol_train_losses, _= batch_gd(online_model, criterion, optimizer, scheduler, insample_loader, insample_loader, epochs=best_epoch, patience=100, save=True)
    save_pickle([ol_train_losses], f'{CONFIG.model_path}/online_trainlosses_{CONFIG.model_version}.pkl')      



# if CONFIG.debug:
#     rnn_categorical_features = (list(CONFIG.rnn_categorical_features_dict.keys())).copy()
#     rnn_numerical_features=  [fea for fea in CONFIG.feature_names if fea not in rnn_categorical_features]
#     rnn_scaler = StandardScaler() 
#     data_pickle = load_pickle(f"{CONFIG.input_path}/data_pickle.pkl")
#     rnn_medians = data_pickle["train_medians"]  
#     df_train.fillna(rnn_medians, inplace=True) #in train mode, we fill train and validation na with train medians
#     df_valid.fillna(rnn_medians, inplace=True)
#     df_train[rnn_numerical_features] = rnn_scaler.fit_transform(df_train[rnn_numerical_features])
#     df_valid[rnn_numerical_features]  = rnn_scaler.transform(df_valid[rnn_numerical_features])
#     df_valid = df_valid[df_valid.date_id <= 1610].copy()  #for debug
#     dataset_val = CustomDataset(df_valid, args.window_size) #(3644520, 3, 88), (3644520,)
#     val_loader = torch.utils.data.DataLoader(dataset=dataset_val, batch_size=args.bs, shuffle=True, num_workers=min(32, os.cpu_count() - 1))
#     model = ResidualRNN(window_size=args.window_size, numerical_features=rnn_numerical_features, categorical_features = rnn_categorical_features, device = device)
#     logger.info(summary(model, input_size=(args.window_size, len(rnn_numerical_features)+len(rnn_categorical_features))))
#     criterion = nn.MSELoss(reduction='none').to(device)
#     optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
#     scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=5, cooldown=0, min_lr=1e-8, verbose=True)
#     train_losses, val_losses = batch_gd(model, criterion, optimizer, scheduler, val_loader, val_loader, epochs=2, patience=10, save=True)
#     save_pickle([train_losses, val_losses], f'{CONFIG.model_path}/losses_{CONFIG.model_version}.pkl')      

