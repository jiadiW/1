import pandas as pd
import polars as pl
import numpy as np
import os, gc
import pickle
import torch
import torch.nn as nn
import torch.nn.functional as F
import logging
from pytorch_lightning.loggers import WandbLogger
from torch.utils.data import Dataset
from sklearn.metrics import r2_score
from torchsummary import summary
from tqdm.auto import tqdm
from matplotlib import pyplot as plt
from sklearn.preprocessing import StandardScaler
from multiprocessing import Pool
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')
pd.options.display.max_columns = None
import sys
sys.path.append("/root")
import kaggle_evaluation.jane_street_inference_server


"""
Load Config and Args
"""
class CONFIG:
    seed = 42
    target_col = "responder_6"
    lag_cols_original = ["date_id", "symbol_id"] + [f"responder_{idx}" for idx in range(9)]
    lag_cols_rename = { f"responder_{idx}_lag_1" : f"responder_{idx}" for idx in range(9)}
    start_dt = 900
    gap = 1 # make sure there is no info overlap between train and validation, set it as 1 since we only use lag 1
    feature_names = [f"feature_{i:02d}" for i in range(79)] + [f"responder_{idx}_lag_1" for idx in range(9)]
    label_name = 'responder_6'
    features_label_name = feature_names + [label_name]
    weight_name = 'weight'
    features_label_weight_name = feature_names + [label_name] + [weight_name]
    model_version = "v3"
    model_path = f"models_{model_version}"
    input_path = 'autodl-tmp' if os.path.exists('autodl-tmp') else '/kaggle/input/jane-street-real-time-market-data-forecasting'
    split_date = 1600
    rnn_categorical_features_dict = {"feature_09": 23, "feature_10":10 , "feature_11":31} #{feature_name: dictionary size}
    rnn_categorical_features_dict = {"feature_09": 23, "feature_10":10 , "feature_11":31} #{feature_name: dictionary size}
    local_train = False
    online_train = False
    debug = False




class custom_args():
    def __init__(self):
        self.usegpu = True
        self.gpuid = 0
        self.seed = 42
        self.use_wandb = True
        self.project = 'js-rnn' 
        self.bs = 16384  # 8192
        self.lr = 1e-4   #1e-4
        self.weight_decay = 5e-4
        self.patience = 10 
        self.max_epochs = 50   
        self.window_size = 3

args = custom_args()

def setup_logger(path, name):
    path_ = f'{path}/'
    if not os.path.exists(path_):
        os.makedirs(path_)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    fhlr = logging.FileHandler(f'{path_}{name}.log')
    fhlr.setFormatter(formatter)
    chlr = logging.StreamHandler()
    chlr.setFormatter(formatter)
    logger.addHandler(chlr)
    logger.addHandler(fhlr)
    return logger, path_


logger_path = 'JSLog'
if not os.path.exists(logger_path):
    os.makedirs(logger_path)
now = datetime.now()-pd.Timedelta('13H')
crrt_time = now.strftime(f"%Y%m%d%H%M")
logger, logger_path = setup_logger(logger_path, name=f"{CONFIG.model_path}_inference_{crrt_time}")

# checking device
device = torch.device(f'cuda:{args.gpuid}' if torch.cuda.is_available() and args.usegpu else 'cpu')  #cuda:0
accelerator = 'gpu' if torch.cuda.is_available() and args.usegpu else 'cpu'  #gpu
logger.info(f"Device: {device}, Accelerator: {accelerator}")
# device = "cpu"
# accelerator=  "cpu"

def save_pickle(data, file_path):
    # Create the directory if it doesn't exist
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Save the pickle file
    with open(file_path, 'wb') as file:  #the file is opened for writing in binary mode.
        pickle.dump(data, file)
    logger.info(f"Data saved to {file_path}")


def load_pickle(file_path):
    # Load and return the data from the pickle file
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            data = pickle.load(file)
        return data
    else:
        raise FileNotFoundError(f"No such file: {file_path}")


"""
Create Sequence
"""
def precompute_sequences(stock_data, window_size, numerical_features, categorical_features):
    # Convert DataFrame columns to NumPy arrays
    """
    stock_data: data group by symbol_id and time_id
    return:
    combined_sequences: np.array, shape:(len(stock_data), window size, number of features)
    targets: np.array, shape: (len(stock_data), )
    weights: np.array, shape: (len(stock_data), )
    """
    stock_data_num = stock_data[numerical_features].values
    stock_data_cat = stock_data[categorical_features].values

    # Pre-compute all sequences
    all_sequences_num = [stock_data_num[max(0, i - window_size + 1):i + 1] for i in range(len(stock_data))]
    all_sequences_cat = [stock_data_cat[max(0, i - window_size + 1):i + 1] for i in range(len(stock_data))]

    # Add padding 0 in front if len(seq)< window size
    padded_sequences_num = [np.pad(seq, ((window_size - len(seq), 0), (0, 0)), 'constant') for seq in all_sequences_num]
    padded_sequences_cat = [np.pad(seq, ((window_size - len(seq), 0), (0, 0)), 'constant') for seq in all_sequences_cat]

    # Combine numerical and categorical features, shape: (684,3,88)
    combined_sequences = np.array([np.concatenate([num, cat], axis=-1) for num, cat in zip(padded_sequences_num, padded_sequences_cat)])

    # Extract targets
    targets = stock_data[CONFIG.target_col].values
    weights = stock_data["weight"].values

    return combined_sequences, targets, weights




def create_batches(data, window_size, rnn_numerical_features, rnn_categorical_features):
    """
    return:
    all_batches: a list of np.array:(25141864, window_size, number of features)
    all_targets: a list, len=25141864
    all_weights: a list, len=25141864
    """
    grouped = data.groupby(['symbol_id', 'time_id'])
    all_batches = []
    all_targets = []
    all_weights= []
    for _, group in tqdm(grouped, desc="Processing groups"):
        # Precompute sequences for the current group
        combined_sequences, targets, weights = precompute_sequences(group, window_size, rnn_numerical_features, rnn_categorical_features)
        # Extend the main batches with the group's sequences and targets
        all_batches.extend(combined_sequences) #combined_sequences: (len(group), window_size, 88)
        all_targets.extend(targets)
        all_weights.extend(weights)
        
    return all_batches, all_targets, all_weights


def precompute_sequences_wrapper(args):
    group, window_size, rnn_numerical_features, rnn_categorical_features = args
    return precompute_sequences(group, window_size, rnn_numerical_features, rnn_categorical_features)


def create_batches_parallel(data, window_size, rnn_numerical_features, rnn_categorical_features, num_workers=min(32, os.cpu_count() - 1)):
    """
    return:
    all_batches: a list of np.array:(25141864, window_size, number of features)
    all_targets: a list, len=25141864
    all_weights: a list, len=25141864
    """
    grouped = data.groupby(['symbol_id', 'time_id'])
    
    # Prepare arguments for parallel processing
    args = [(group, window_size, rnn_numerical_features, rnn_categorical_features) for _, group in grouped]

    all_batches = []
    all_targets = []
    all_weights = []

    with Pool(num_workers) as pool:
        results = list(tqdm(pool.imap(precompute_sequences_wrapper, args), total=len(args), desc="Processing groups"))

    for combined_sequences, targets, weights in results:
        all_batches.extend(combined_sequences) #combined_sequences: (len(group), window_size, 88)
        all_targets.extend(targets)
        all_weights.extend(weights)
        
    return all_batches, all_targets, all_weights


def compute_last_sequence(group, window_size, rnn_numerical_features, rnn_categorical_features):
    targets, weights = None, None
    # Convert DataFrame columns to NumPy arrays
    stock_data_num = group[rnn_numerical_features].values
    stock_data_cat = group[rnn_categorical_features].values

    # Find the index of the target second
    target_index = len(group) - 1

    # Extract the sequence for the target index
    sequence_num = stock_data_num[max(0, target_index - window_size + 1):target_index + 1]
    sequence_cat = stock_data_cat[max(0, target_index - window_size + 1):target_index + 1]

    # Add padding if necessary
    padded_sequence_num = np.pad(sequence_num, ((window_size - len(sequence_num), 0), (0, 0)), 'constant')
    padded_sequence_cat = np.pad(sequence_cat, ((window_size - len(sequence_cat), 0), (0, 0)), 'constant')

    # Combine numerical and categorical features
    combined_sequence = np.concatenate([padded_sequence_num, padded_sequence_cat], axis=-1)
    if CONFIG.target_col in group.columns:
        targets = group[CONFIG.target_col].values[target_index]
        weights = group["weight"].values[target_index]
    return combined_sequence, targets, weights


def create_last_batches(data, window_size, rnn_numerical_features, rnn_categorical_features):

    grouped = data.groupby(['symbol_id', "time_id"])
    all_batches = []
    all_targets = []
    all_weights = []

    for _, group in grouped:
        # Compute the sequence for the last data point in the current group on inference mode
        last_sequence, targets, weights= compute_last_sequence(group, window_size, rnn_numerical_features, rnn_categorical_features)

        # Check if the sequence is valid (i.e., not empty)
        if last_sequence.size > 0:
            all_batches.append(last_sequence)
            all_targets.append(targets)
            all_weights.append(weights)
    return all_batches, all_targets, all_weights




def get_data(df, rnn_numerical_features, rnn_categorical_features, window_size, is_inference=False):
    """
    return:
    df_copy_batches: np.array, (num of samples, window size, num of features)
    df_copy_targets: np.array,  (num of samples,)
    df_copy_weights: np.array,  (num of samples,)
    """
    # Check if the DataFrame is empty
    global rnn_scaler,rnn_medians
    if df.empty:
        return None, None, None
    # Work on a copy of the DataFrame to avoid changing the original df
    df_copy = df.copy()
    # Preprocess Data
    if is_inference:   #only return the data point which is the last one for each symbol id, no need for multiprocessing
        df_copy_batches_ls, _, _ = create_last_batches(df_copy, window_size, rnn_numerical_features, rnn_categorical_features)
        df_copy_batches = np.array(df_copy_batches_ls)  
        del df_copy_batches_ls
        gc.collect()
        return df_copy_batches
    elif CONFIG.local_train or CONFIG.online_train: #train local model or train online model
        df_copy_batches_ls, df_copy_targets_ls, df_copy_weights_ls = create_batches_parallel(df_copy, window_size, rnn_numerical_features, rnn_categorical_features)
        df_copy_batches = np.array(df_copy_batches_ls)  
        df_copy_targets = np.array(df_copy_targets_ls)  
        df_copy_weights=  np.array(df_copy_weights_ls)
        del df_copy_batches_ls, df_copy_targets_ls, df_copy_weights_ls
        gc.collect()
        return df_copy_batches, df_copy_targets, df_copy_weights
    else: #online learning, since online learning every day, only select the last point for (symbol_id, time_id) pair
        df_copy_batches_ls, df_copy_targets_ls, df_copy_weights_ls = create_last_batches(df_copy, window_size, rnn_numerical_features, rnn_categorical_features)
        df_copy_batches = np.array(df_copy_batches_ls)  
        df_copy_targets = np.array(df_copy_targets_ls)  
        df_copy_weights=  np.array(df_copy_weights_ls)
        del df_copy_batches_ls, df_copy_targets_ls, df_copy_weights_ls
        gc.collect()
        return df_copy_batches, df_copy_targets, df_copy_weights




class CustomDataset(Dataset):
    """
    Characterizes a dataset for PyTorch
    """
    def __init__(self, df, T):
        #Initialization
        self.T = T
        xs, ys, ws = get_data(df, rnn_numerical_features, rnn_categorical_features, T)
        logger.info(f'fetching data: , {xs.shape}, {ys.shape}, {ws.shape}') 
        self.length = len(xs)
        self.x = torch.from_numpy(xs)
        self.y = torch.from_numpy(ys)
        self.w = torch.from_numpy(ws)
        del xs, ys, ws
        gc.collect()

    def __len__(self):
        #Denotes the total number of samples
        return self.length

    def __getitem__(self, index):
        #Generates samples of data
        return self.x[index], self.y[index], self.w[index]


    
# Custom R2 metric for validation
def r2_val(y_true, y_pred, sample_weight):
    r2 = 1 - np.average((y_pred - y_true) ** 2, weights=sample_weight) / (np.average((y_true) ** 2, weights=sample_weight) + 1e-38)
    return r2


class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_sizes, do_ratio=0.5):
        """
        in_channels: number of features
        out_channels: number of filters
        kernel_sizes: list, a list of kernel size
        do_ratio: float
        """
        super(ConvBlock, self).__init__()
        self.conv_layers = nn.ModuleList()
        self.conv_layers1 = nn.ModuleList()
        for kernel_size in kernel_sizes:
            self.conv_layers.append(
                nn.Sequential(
                    nn.Conv1d(in_channels, out_channels, kernel_size, padding="same"),
                    nn.BatchNorm1d(out_channels),
                    nn.ReLU(),
                    nn.Dropout(do_ratio),
                )
            )
            self.conv_layers1.append(
                nn.Sequential(
                    nn.Conv1d(out_channels, out_channels, kernel_size, padding="same"),
                    nn.BatchNorm1d(out_channels),
                    nn.ReLU(),
                )
            )
        
    def forward(self, x): #input tensor with shape (batch_size, num_features, sequence_length) 
        conv_outputs = [] 
        for i in range(len(self.conv_layers)):
            conv_layer0 = self.conv_layers[i] #shape: (, out_channels, sequence_length)
            conv_layer1 = self.conv_layers1[i]
            conv_out = conv_layer0(x)
            shortcut = conv_out.clone()
            conv_out = conv_layer1(conv_out)
            conv_out = conv_out+shortcut #conv_out shape:(, out_channels, sequence_length)
            conv_outputs.append(conv_out)
        concatenated_conv = torch.cat(conv_outputs, dim=1) #(, out_channels*len(kernel_sizes), sequence_length)
        flattened_conv_output = concatenated_conv.view(concatenated_conv.size(0), -1) #(batch_size, out_channels * len(kernel_sizes)*sequence_length)
        return flattened_conv_output



class ResidualRNN(nn.Module): #total trainable parameters: ~660, 000
    def __init__(self, window_size, numerical_features, categorical_features, device):
        super(ResidualRNN, self).__init__()
        self.device = device
        self.window_size = window_size
        self.numerical_features = numerical_features
        self.categorical_features = categorical_features
        self.embedding_dim = 6
        # Embedding for categorical feature 09-11
        num_embeddings_list = list(CONFIG.rnn_categorical_features_dict.values())  #[22,9,30]
        self.embeddings = nn.ModuleList([
            nn.Embedding(num_embeddings, self.embedding_dim) for num_embeddings in num_embeddings_list
        ]).to(self.device)
        
        # Convolutional blocks
        self.conv_numerical = ConvBlock(len(numerical_features), 16, [2, 3], 0.4).to(self.device)
        self.conv_categorical = ConvBlock(self.embedding_dim*len(categorical_features), 16, [2, 3], 0.4).to(self.device)
        self.conv_diff = ConvBlock(len(numerical_features)*(self.window_size-1), 16, [2, 3], 0.4).to(self.device)
        
        # Dense layers
        self.dense_sizes = [512, 256, 128, 64, 32]
        self.dense_layers = None
        # Output layer
        self.output_layer = nn.Linear(self.dense_sizes[-1], 1).to(self.device)


    def _create_dense_layers(self, input_dim, hidden_dims, dropout_ratio):
        layers = []
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(input_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(hidden_dim))
            layers.append(nn.SiLU())  # swish activation
            layers.append(nn.Dropout(dropout_ratio))
            input_dim = hidden_dim
        return nn.Sequential(*layers).to(self.device)
    
    def set_dense_layers(self, input_dim, dropout_ratio):
        self.dense_layers = self._create_dense_layers(input_dim, self.dense_sizes, dropout_ratio)


    def forward(self, x):
        x = x.to(self.device)
        # Split the input into numerical and categorical parts
        numerical_input = x[:, :, :-3]  # (batch_size, window_size, 85)
        categorical_input = x[:, :, -3:].long() # (batch_size, window_size, num of cat features)  #can't have negative number
        
        # Compute difference layers
        difference_layers = []
        for lag in range(1, self.window_size):
            diff_layer = numerical_input[:, lag:, :] - numerical_input[:, :-lag, :]  # (batch_size, window_size-lag, num_numerical_features)
            padding = F.pad(diff_layer, (0, 0, lag, 0))  # (batch_size, window_size, num_numerical_features)
            difference_layers.append(padding)
        combined_diff_layer = torch.cat(difference_layers, dim=-1)  # (batch_size, window_size, num_numerical_features * (window_size-1)), [, 3, 170])
        
        # Embedding for categorical part
        embedded_features = []
        for i in range(3):
            feature = categorical_input[:, :, i]  # Extract the i-th feature
            embedded_feature = self.embeddings[i](feature)  # Apply embedding
            embedded_features.append(embedded_feature)
        
        # Concatenate the embedded features along the last dimension
        embedding = torch.cat(embedded_features, dim=-1) # (batch_size, window_size, embedding_dim*3)
        
        # Apply convolutional layers
        conv_numerical = self.conv_numerical(numerical_input.permute(0, 2, 1))  # (batch_size, num_features)
        conv_categorical = self.conv_categorical(embedding.permute(0, 2, 1))  # (batch_size, num_features)
        conv_diff = self.conv_diff(combined_diff_layer.permute(0, 2, 1))  # (batch_size, num_features)
        
        # Concatenate all features
        first_numerical = numerical_input[:, 0, :]  # (batch_size, num_numerical_features)
        first_embedding = embedding[:, 0, :]  # (batch_size, embedding_dim), original categorical embedding features
        combined_features = torch.cat([conv_numerical, conv_categorical, conv_diff, 
                                    combined_diff_layer.view(combined_diff_layer.size(0), -1), 
                                    first_numerical, first_embedding], dim=-1)  #(16384, 901)
        
        
        # Apply dense layers
        if not self.dense_layers:
            self.set_dense_layers(input_dim = combined_features.shape[1], dropout_ratio = 0.5)
        dense_output = self.dense_layers(combined_features)  #[16384, 32]
        
        # Output layer
        output = self.output_layer(dense_output)  #[16384, 1]
        
        return output.squeeze(-1)




# A function to encapsulate the training loop with early stopping and learning rate scheduler
def batch_gd(model, criterion, optimizer, scheduler, train_loader, test_loader, epochs, patience=10, save=True):

    train_losses = np.zeros(epochs)
    test_losses = np.zeros(epochs)
    best_test_loss = np.inf
    best_test_epoch = 0
    patience_counter = 0

    for it in tqdm(range(epochs)):
        model.train()
        t0 = datetime.now()
        train_loss_it = []
        for inputs, targets, weights in train_loader:
            # logger.info ('\nrun again with anomaly detection ...')
            #with torch.autograd.detect_anomaly():
            optimizer.zero_grad() # zero the parameter gradients
            inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
            outputs = model(inputs)
            loss = criterion(outputs, targets) * weights #if reduction is none, it is a vector (w_i*(yi-yi_hat)**2, ..., ..., )
            loss = loss.mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1)
            optimizer.step()
            train_loss_it.append(loss.item()) 
        
        # Get train loss and test loss
        train_loss = np.mean(train_loss_it) 
        
        if epochs == 1: #no need to adjust lr
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4f}, Duration: {datetime.now() - t0}. ')

        else:
            model.eval()
            test_loss_it = []
            with torch.no_grad():
                for inputs, targets, weights in test_loader:
                    inputs, targets, weights = inputs.to(device, dtype=torch.float), targets.to(device, dtype=torch.float), weights.to(device, dtype=torch.float)
                    outputs = model(inputs)
                    loss = criterion(outputs, targets) * weights
                    loss = loss.mean()
                    test_loss_it.append(loss.item())
            test_loss = np.mean(test_loss_it)

            # Save losses
            train_losses[it] = train_loss
            test_losses[it] = test_loss
            
            # Update the scheduler
            scheduler.step(test_loss)

            # Check for early stopping
            if test_loss < best_test_loss:
                patience_counter = 0
                best_test_loss = test_loss
                best_test_epoch = it
                if save:
                    torch.save(model.state_dict(), f'{CONFIG.model_path}/best_model_{CONFIG.model_version}_online_{CONFIG.online_train}')
                    logger.info('Model saved.')
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    logger.info('Early stopping.')
                    break

            dt = datetime.now() - t0
            logger.info(f'Epoch {it+1}/{epochs}, Train Loss: {train_loss:.4e}, \
                Validation Loss: {test_loss:.4e}, Duration: {dt}, Best Val Epoch: {best_test_epoch}')
    
    return train_losses, test_losses


def change_cat_features_to_indices(df: pd.DataFrame) -> pd.DataFrame:
    feature09_values = [11, 81,  4, 15, 42, 46, 70, 50, 44,  9, 64, 30, 34, 57, 26, 68,  2, 14, 12, 82, 49, 25]  #22
    feature10_values = [ 7,  2,  3,  1,  5,  6, 10,  4, 12]  #9
    feature11_values = [ 76,  59,  11,  62, 150, 261, 410, 522,  16,  25, 376,  50,  13, 214, 230, 158,  63, 336, 534, 388, 171,   
                        9,  40,  24,  48,  66, 539,  34, 297, 195]  #30
    value09_to_index = {value: idx for idx, value in enumerate(feature09_values)}
    value10_to_index = {value: idx for idx, value in enumerate(feature10_values)}
    value11_to_index = {value: idx for idx, value in enumerate(feature11_values)}

    df["feature_09"] = df["feature_09"].map(value09_to_index).fillna(22).astype(int)
    df["feature_10"] = df["feature_10"].map(value10_to_index).fillna(9).astype(int)
    df["feature_11"] = df["feature_11"].map(value11_to_index).fillna(30).astype(int)
    return df 



rnn_categorical_features = (list(CONFIG.rnn_categorical_features_dict.keys())).copy()
rnn_numerical_features=  [fea for fea in CONFIG.feature_names if fea not in rnn_categorical_features]
data_pickle = load_pickle(f"{CONFIG.input_path}/data_pickle.pkl")

# Get the validation score
nn_model = ResidualRNN(window_size=args.window_size, numerical_features=rnn_numerical_features, categorical_features = rnn_categorical_features, device = device)
nn_model.set_dense_layers(input_dim = 901, dropout_ratio = 0.5)  #set dense layers
model_path = f'{CONFIG.model_path}/best_model_{CONFIG.model_version}_online_True'
nn_model.load_state_dict(torch.load(model_path, map_location=device))
nn_model = nn_model.to(device)
nn_model.eval() 


"""
Model Inference
"""
lags_ : pl.DataFrame | None = None
cache_nn : pl.DataFrame | None = None
in_sample_medians = data_pickle["in_sample_medians"]
rnn_scaler = data_pickle["in_sample_rnn_scaler"] 


def predict(test: pl.DataFrame, lags: pl.DataFrame | None) -> pl.DataFrame | pd.DataFrame:
    global lags_, cache_nn, nn_model
    predictions = test.select('row_id', pl.lit(0.0).alias('responder_6'),) # 将 'responder_6' 列初始化为 0
    if lags is not None: #每天time_id==0
        if cache_nn is not None:  #if date_id != 0
            #online learning
            #left join yesterday's data with labels, labels come from lags
            time0 = datetime.now()
            last_date_label = lags.select(["date_id", "time_id", "symbol_id", "responder_6_lag_1"]).clone()
            # last_date_label = last_date_label.filter(pl.col("time_id")<10)  #only for debug
            last_date_label = (last_date_label.with_columns((pl.col("date_id")-1).alias("date_id"))).rename({"responder_6_lag_1":"responder_6"})
            cache_nn = cache_nn.merge(last_date_label.to_pandas(), on = ["date_id", "time_id", "symbol_id"], how = "left", suffixes=('', '_1'))  #(, 95)
            if "responder_6_1" in cache_nn.columns:
                cache_nn["responder_6"] = cache_nn["responder_6"].fillna(cache_nn["responder_6_1"])
                cache_nn = cache_nn.drop("responder_6_1", axis=1)
            cache_nn = cache_nn.groupby(["symbol_id", "time_id"]).tail(args.window_size).sort_values(by=['date_id', 'time_id', 'symbol_id']).reset_index(drop=True)
            print(f"Cache_nn shape: {cache_nn.shape}")
            cache_nn_dataset = CustomDataset(cache_nn, args.window_size)
            cache_dataloader = torch.utils.data.DataLoader(cache_nn_dataset, batch_size=int(args.bs), shuffle=True, num_workers = 16)
            criterion = nn.MSELoss(reduction='none').to(device)
            optimizer = torch.optim.Adam(nn_model.parameters(), lr=args.lr*0.1, weight_decay=args.weight_decay)
            scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.8, patience=6, cooldown=0, min_lr=1e-8, verbose=True)
            _, _ = batch_gd(nn_model, criterion, optimizer, scheduler, cache_dataloader, cache_dataloader, epochs=1, patience=100, save = False)
            nn_model.eval()
            print(f"Online learning for one days takes {datetime.now()-time0} seconds. ")
        gc.collect()
        lags = lags.group_by(["date_id", "symbol_id"], maintain_order=True).last() # pick up last record of previous date
        lags = lags.drop("time_id")
        test = test.join(lags, on=["date_id", "symbol_id"],  how="left") #pl.dataframe
        test_input = test.to_pandas()  #pd.Dataframe
        test_input = change_cat_features_to_indices(test_input)
        test_input[CONFIG.feature_names] = test_input[CONFIG.feature_names].fillna(in_sample_medians[CONFIG.feature_names])
        test_input[rnn_numerical_features] = rnn_scaler.transform(test_input[rnn_numerical_features])
        cache_nn = pd.concat([cache_nn, test_input], axis = 0) #pd.dataframe, all processed features
        lags_ = lags.clone()
    
    else:  #每天time_id>0, 把处理好的数据放到cache_nn里
        test = test.join(lags_, on=["date_id", "symbol_id"],  how="left")  #pl.dataframe
        test_input = test.to_pandas()  #pd.Dataframe
        test_input = change_cat_features_to_indices(test_input)
        test_input[CONFIG.feature_names] = test_input[CONFIG.feature_names].fillna(in_sample_medians[CONFIG.feature_names])
        test_input[rnn_numerical_features] = rnn_scaler.transform(test_input[rnn_numerical_features])
        cache_nn = pd.concat([cache_nn, test_input], axis = 0)

    if test_input.is_scored.iloc[0]== False:  #public test data, not scored
        preds = np.zeros(len(test))
    else:
        with torch.no_grad():   #online inference
            symbols = list(test_input.symbol_id)
            cache_remove_symbols = cache_nn.loc[(cache_nn["symbol_id"].isin(symbols))&(cache_nn.time_id==test_input.time_id.iloc[-1])]
            test_input_arry = get_data(cache_remove_symbols, rnn_numerical_features, rnn_categorical_features, args.window_size, is_inference = True)
            batch_tensor = torch.tensor(test_input_arry, dtype=torch.float32).to(device)  #torch.Size([39, 3, 88])
            nn_model = nn_model.to(device)
            preds = nn_model(batch_tensor).cpu().numpy()
    
    predictions = test.select('row_id').with_columns(pl.Series(
            name   = 'responder_6', 
            values = np.clip(preds, a_min = -5, a_max = 5), # 生成最终的预测结果 DataFrame，确保预测值在 -5 到 5 之间
            dtype  = pl.Float64,
        )
    )
    # The predict function must return a DataFrame
    assert isinstance(predictions, pl.DataFrame | pd.DataFrame)
    assert list(predictions.columns) == ['row_id', 'responder_6']
    assert len(predictions) == len(test)
    return predictions


alltraindata = pl.scan_parquet(f"{CONFIG.input_path}/train.parquet")
# train_5days = alltraindata.filter((pl.col("date_id")>1698-5)&(pl.col("time_id")<10)).collect()  #for debug
train_5days = alltraindata.filter((pl.col("date_id")>1698-5)).collect()
train_5days = train_5days.with_columns(pl.Series(range(len(train_5days))).alias("row_id"))
lag0 = pl.scan_parquet(f"{CONFIG.input_path}/lags.parquet")
temp = lag0.collect()
test_sample = pl.scan_parquet(f"{CONFIG.input_path}/test.parquet")
test_sample = test_sample.collect()
lag_sample = pl.read_parquet(f"{CONFIG.input_path}/lags.parquet/date_id=0/part-0.parquet")
responder_cols = [s for s in train_5days.columns if "responder" in s]

def makelag(date_id):
    """
    Making lag at the previout day

    Args:
    date_id (int): date_id at the previout day
    
    Returns:
    pl.dataframe, date_id == 同一个batch的test.date_id
    """
    
    lag = alltraindata.filter(pl.col("date_id")==date_id).select(["date_id","time_id","symbol_id"] + responder_cols).collect()
    lag.columns = lag_sample.columns
    lag = lag.with_columns((pl.col("date_id")+1).alias("date_id"))
    return lag   

all_submission_dataframe = []
cnt = 0

for num_days, df_per_day in train_5days.group_by("date_id",maintain_order=True): ## Step 1 The data is split by day using group_by.

    for time_id, test in df_per_day.group_by("time_id",maintain_order=True): ## Step 2 The data is split by time_id using group_by, and the lag is generated (for time_id == 0).
        
        if time_id[0] == 0: ## when time_id == 0, makelags
            lag = makelag(num_days[0] - 1)  #shape: (37_752, 12)
        else:
            lag = None
        test = test.with_columns(is_scored=True)
        test = test.select(test_sample.columns) #shape:(39, 85)
        submission_dataframe = predict(test, lag)
        all_submission_dataframe.append(submission_dataframe)
        print(f"Date id: {num_days[0]}, time id: {time_id[0]}, counter: {cnt}.")
        cnt += 1
        
all_submission_dataframe = pl.concat(all_submission_dataframe)
all_submission_dataframe
